MARLIN FOR BTT SKR PICO V1.0 — BUILD RECIPE (Honeybadger, 2026-07-10)
=====================================================================
WHAT THIS IS
  The exact configuration behind BOTH Marlin builds on honeybadger.software:
    Marlin-SKR-Pico-USB-bugfix21x-20260710.uf2     (this bundle, as-is)
    Marlin-SKR-Pico-UART0-bugfix21x-20260710.uf2   (ONE line different — below)

SOURCE
  Repo:    https://github.com/MarlinFirmware/Marlin
  Branch:  bugfix-2.1.x  (the SKR Pico is NOT in a stable release yet)
  Commit:  f44cb948c7480845826110fdab3000d0e2de4b91

EVERY LINE WE CHANGED FROM MARLIN'S DEFAULTS
  Configuration.h:
    MOTHERBOARD      BOARD_RAMPS_14_EFB  ->  BOARD_BTT_SKR_PICO
    SERIAL_PORT      0                   ->  -1   (USB build: the RP2040's USB-C)
                                              0   (UART0 build: the 5-wire P5 link,
                                                   gpio0/1 -- Klipper-UART0's twin)
    X_DRIVER_TYPE    A4988               ->  TMC2209   (soldered drivers, UART mode)
    Y_DRIVER_TYPE    A4988               ->  TMC2209
    Z_DRIVER_TYPE    A4988               ->  TMC2209
    E0_DRIVER_TYPE   A4988               ->  TMC2209
  Configuration_adv.h: untouched.
  Endstops + thermistors: Marlin DEFAULTS already match this board (pull-up endstops,
  EPCOS 100K sensors) -- verified against BTT's own Klipper config. Bed size, geometry,
  PID: Marlin defaults -- SET YOUR MACHINE'S VALUES, verify endstops with M119 first.

WHY NO SERIAL_PORT 1: UART1 (gpio8/9) is the TMC2209 driver bus on this board.
  Legal values here: -1 (USB) or 0 (UART0/P5). Marlin HAL enforces the -1..1 range.

BUILD IT YOURSELF
  git clone -b bugfix-2.1.x --depth 1 https://github.com/MarlinFirmware/Marlin.git
  (drop these two files into Marlin/)
  pio run -e SKR_Pico
  -> .pio/build/SKR_Pico/firmware.uf2   (flash: hold BOOT, plug USB, drop the file
     onto the RPI-RP2 drive -- no SD slot on this board)

HONEST STATUS
  Both builds compile-verified 2026-07-10 (SUCCESS ~101 s each). Bench-run on real
  hardware: PENDING -- the page says so until it happens. Baud for hosts: 250000.
