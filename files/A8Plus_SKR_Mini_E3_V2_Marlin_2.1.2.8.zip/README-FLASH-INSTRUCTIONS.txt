=====================================================================
 MARLIN 2.1.2.8 — ANET A8 PLUS on BTT SKR MINI E3 V2.0
 Custom build — no VS Code needed, just an SD card
=====================================================================

WHAT THIS IS
------------
firmware.bin = Marlin 2.1.2.8 compiled for the BigTreeTech SKR Mini
E3 V2.0 board installed in an Anet A8 Plus. Based on the official
Marlin example configs for both machines:
  - Board/drivers/screen base: "Creality Ender-3 / SKR Mini E3 2.0"
  - Printer geometry/temps:    "Anet/A8plus"

Baked-in settings:
  - Bed 300 x 300, Z max 370, A8+ home offsets (X -26, Y -6)
  - Steps/mm: X80 Y80 Z400 E95
  - Thermistor type 5 (Anet stock) on hotend + bed
  - TMC2209 drivers in quiet StealthChop (they will be nearly silent
    compared to the old Anet board - that's normal)
  - Bed PID enabled, thermal runaway protection ON everywhere
  - Display: works with BTT dual-mode TFT touchscreens (both touch
    mode AND Marlin mode) and with 12864-style knob screens wired
    to EXP1

HOW TO FLASH (5 minutes)
------------------------
1. Take the microSD card that came with the board (or any card 8GB
   or smaller, formatted FAT32).
2. Copy firmware.bin onto it. Nothing else on the card. The name
   must stay exactly "firmware.bin".
3. Printer OFF. Put the card in the SKR board's microSD slot
   (the slot on the BOARD, not the LCD).
4. Power on. Do nothing for 30 seconds.
5. Power off, pull the card, check it on a PC: if firmware.bin got
   renamed to FIRMWARE.CUR, the flash worked. If it did NOT rename,
   reformat the card FAT32 and try again with a smaller/older card.

FIRST BOOT CHECKLIST - DO THESE IN ORDER, BEFORE FIRST PRINT
------------------------------------------------------------
Board swaps ALWAYS need these three checks. Skipping them is how
nozzles get driven into beds.

[1] THERMISTORS (do this first - you know why, buddy)
    With everything at room temp, check the LCD: hotend and bed
    should both read roughly 20-30 C. If either reads 0, a crazy
    number, or "ERR", STOP - wrong thermistor plug/port. Do not
    heat anything until this reads sane.

[2] ENDSTOPS (before homing!)
    From the LCD or a connected PC, run M119 with nothing pressed:
    all three should say "open". Hold each switch closed by hand
    and run M119 again: that axis should say "TRIGGERED".
    If it's backwards (shows TRIGGERED when not pressed), tell me
    which one - it's a 1-line fix and a rebuild.

[3] MOTOR DIRECTIONS (hand near the power switch)
    Move each axis +10mm from the LCD (Motion > Move Axis), ONE
    axis at a time, starting from the middle of its travel:
      X+ must move the head RIGHT
      Y+ must move the bed FORWARD (nozzle moves toward the back
         of the bed, relative to the frame)
      Z+ must move the head UP
      E  must pull filament IN when extruding (test warm, 200 C)
    Any axis that moves backwards: either flip that motor's plug
    180 degrees at the board (printer OFF first!), or ask for a
    rebuild with that axis inverted in firmware. Both are normal
    fixes on a board swap - the old Anet wiring isn't guaranteed
    to match what the SKR expects.

    Only AFTER all three pass: home (G28) with your finger on the
    power switch the first time.

[4] TUNE IT (optional but worth it)
    - Hotend PID: M303 E0 C8 S200 U1   then M500 to save
    - Bed PID:    M303 E-1 C8 S60 U1   then M500 to save
    (the U1 on the end matters - it APPLIES the tuned values;
     without it M500 just re-saves the old ones)
    - The baked-in PID values are from the official Anet A8 configs,
      so they're sane starting points, not perfect for your hotend.

LCD NOTES
---------
- BTT TFT touchscreen (TFT35 etc.): connect the ribbon/serial cable
  to the board's TFT port for touch mode - it talks to Marlin over
  serial and works with this build as-is. The TFT itself has its
  OWN firmware (from the BIGTREETECH-TouchScreenFirmware repo on
  GitHub) - update it separately if the touch side acts weird.
  In touch mode use 115200 baud on the TFT settings.
- If you also connect the two EXP ribbon cables, you can long-press
  the knob to switch the TFT into "Marlin mode" (classic knob menu)
  - this build supports both.
- If your BTT screen is the little Mini 12864 (knob only, no touch),
  say so - that one needs a different define and a 2-minute rebuild.

WHAT'S IN THE ZIP
-----------------
firmware.bin        <- the only file the printer needs
Configuration.h     <- the exact config this was built from
Configuration_adv.h <- (so anyone can rebuild/modify it later)
this README

Built from official Marlin 2.1.2.8 release source, unmodified except
for the Configuration files included here.
