# HoneyBadger Bunker

Run your own Rust server without ever opening a command prompt.

The Deck installs the Rust dedicated server for you, starts it, stops it, backs it up, wipes it on schedule and shows you
what it is doing: players, FPS, memory, and every line of the console, all inside one window. It works the same on a
Windows PC and on a Linux box in a rack or a datacenter. SteamCMD and the game server run hidden in the background; their
output shows up in the Deck's console instead of in a black box.

It comes with the HoneyBadger DPS Meter plugin ready to go, and Carbon is the default mod framework (Oxide and plain
vanilla are one click away).

---

## Windows: one click

1. Download the zip, right-click it, Properties, tick **Unblock**, OK. (This skips the Windows warning later.)
2. Unzip it anywhere you like, for example `C:\HoneyBadger\Bunker`.
3. Double-click **HoneyBadger Bunker.bat**.

That is all. The zip carries its own copy of Python, so there is nothing else to install. A small box says the Deck is
starting and closes itself, and the Deck window opens. The setup wizard asks for a name, where the files should go, the map
and how many players, picks free ports, and installs the game. Friends can join once the Deck shows your server as running.

Closing the Deck window does **not** stop your server. The engine keeps running in the background; open the Deck again
and everything is where you left it.

Running from the source folder instead of the zip? You need Python 3.12. The first double-click builds a private `.venv`
and installs what the Deck needs (internet and a few minutes), after that it starts in a second.

Something wrong? Double-click **Bunker (console debug).bat** (in the zip it sits next to the launcher; in the source
folder it is in `packaging\windows`). It runs the engine in a visible window so you can read what it prints.

## Linux: one command

Debian and Ubuntu (64-bit) are what I test on. The same installer also has a Fedora / RHEL / Rocky / Alma path, which is newer. On the server, as root:

```
curl -sSL https://honeybadger.software/installer/install.sh | sudo bash -s -- --from https://honeybadger.software/installer/hbdeck-linux.tar.gz
```

Already have the source folder on the box? Run it from there:

```
sudo bash packaging/linux/install.sh
```

The installer is safe to run again. It will:

- install the 32-bit libraries SteamCMD needs (`lib32gcc-s1` on Debian/Ubuntu, `glibc.i686` on Fedora/RHEL), Python, curl,
  unzip and logrotate;
- create an unprivileged user `honeybadger` (home `/var/lib/honeybadger`). The game server never runs as root;
- install the Deck into `/opt/honeybadger` and start it as a systemd service named `hbdeck`;
- set up log rotation, 100000 open files for the game, and a restart-on-crash limit (3 tries in 5 minutes, 15 seconds apart,
  so a broken update cannot loop forever).

At the end it prints the panel address, the SSH command to reach it, and the firewall commands for your system. It does
**not** run the firewall commands for you.

The panel listens on the server's loopback address only. From your own PC:

```
ssh -L 27800:127.0.0.1:27800 you@your-server
```

Then open `http://127.0.0.1:27800/` in your browser. Useful commands:

```
systemctl status hbdeck        journalctl -u hbdeck -f        sudo systemctl restart hbdeck
sudo bash /opt/honeybadger/uninstall.sh            (removes the Deck, keeps your servers)
sudo bash /opt/honeybadger/uninstall.sh --purge    (removes everything, servers included)
```

Needs Python 3.12 or newer, which Ubuntu 24.04, Debian 13 and current Fedora have. On an older system, install
`python3.12` first and run the installer again.

## Where your files live

| | Windows (zip / launcher) | Linux (installer) |
|---|---|---|
| Deck settings, database, logs | `state\` next to the launcher | `/var/lib/honeybadger` |
| Game servers | the folder you pick in the wizard (shown before anything downloads) | `/srv/honeybadger/servers/<name>` |
| Engine settings (port, bind address) | chosen automatically | `/etc/honeybadger/engine.env` |
| Launcher/engine log | `state\logs\launcher.log` and `engine.log` | `journalctl -u hbdeck`, `/var/lib/honeybadger/logs` |

To move the Windows install to another PC, close the Deck, copy the whole folder, and start it there.

## Ports to forward

| Port | Protocol | Purpose | Open to the internet? |
|---|---|---|---|
| 28015 | UDP | game | yes |
| 28017 | UDP | server query (the server list needs it) | yes |
| 28016 | TCP | RCON | no, unless you manage the server from outside |
| Rust+ port | TCP | Rust+ companion app (the Deck shows the number) | only if you turned it on |
| 27800 | TCP | the Deck panel on Linux | **never** (use the SSH command above) |

These are the defaults. If you change a port in the wizard, forward the numbers the Deck shows. Playing from the same PC
or the same network needs no forwarding: press F1 in Rust and type `client.connect 127.0.0.1:28015`.

## Updates

Updates come from honeybadger.software. The Deck checks a signed list there, and every file it downloads must match a
signature and a checksum or it is refused. You get a plain notice in the Deck when there is a new version of the Deck, a
new plugin, or news; nothing installs until you click.

- Windows: the Deck downloads and verifies the new version, then swaps it in when you click and the engine has stopped.
  Or download the new zip and unzip it over the old folder; `state\` is not in the zip, so your servers and settings stay.
- Linux: run the installer again with the new package. Your settings and servers are kept.

Updating the Rust server itself is separate: it is one button (or a schedule) and it keeps your mod framework
in place afterwards.

## Troubleshooting

**Windows says "Windows protected your PC" (SmartScreen) or asks if you want to run the file.** The Deck is not code-signed
yet, so Windows does not know it. Click **More info**, then **Run anyway**. Unblocking the zip before you unzip it
(step 1 above) avoids the prompt.

**The Deck window does not open.** Open `state\logs\launcher.log`. If the log is empty or does not explain it, run
**Bunker (console debug).bat** and read what it says. The window needs the Microsoft Edge WebView2 runtime, which
Windows 11 has built in; on Windows 10 it is a free download from Microsoft.

**First start takes forever.** The first start is slow, and that is normal: the game downloads about 6 GB, and then
the server generates the map. Expect several minutes before the server shows as running. Later starts are much faster.

**Not enough memory.** A Rust server wants about 12 GB of RAM for itself and 15 GB of free disk. If the machine has less, pick a
smaller map and fewer players in the wizard.

**Players cannot join, but it works for me.** The ports above are not reachable from outside. Check the router forward,
the Windows or Linux firewall, and (on a cloud host) the provider's security group. Both UDP ports must be open.

**Linux service will not start.** `journalctl -u hbdeck -n 50` shows why. The service gives up after 3 failed starts in
5 minutes on purpose; fix the cause and run `sudo systemctl restart hbdeck`.

## Licence and what is not ours

The Deck's own code is MIT licensed (see `LICENSE`). Copyright HoneyBadger Software.

Things the Deck downloads for you are not part of it and keep their own licences and terms:

- **Rust Dedicated Server** belongs to Facepunch Studios. The Deck installs it through Valve's SteamCMD, anonymously, from
  Steam's own servers.
- **SteamCMD** belongs to Valve.
- **Carbon** and **Oxide (uMod)** are separate projects with their own licences. The Deck downloads them from their
  official releases into your server; it never bundles or modifies them.
- **Python** and the libraries inside the Windows zip carry their own open-source licences.

HoneyBadger Software is not affiliated with Facepunch Studios or Valve.
