#!/usr/bin/env bash
# ============================================================================
# HoneyBadger Bunker - Linux uninstaller
#
#   sudo bash /opt/honeybadger/uninstall.sh            remove the program + service, KEEP servers and data
#   sudo bash /opt/honeybadger/uninstall.sh --purge    ALSO delete servers, data, config and the service user
#
# Options (use the same values you gave install.sh if you changed them):
#   --prefix <dir> --user <name> --data <dir> --servers <dir> --etc <dir> --name <svc>
#   --yes            do not ask for confirmation on --purge
# ============================================================================
set -euo pipefail

PREFIX=/opt/honeybadger
HB_USER=honeybadger
HB_DATA=/var/lib/honeybadger
HB_SERVERS=/srv/honeybadger/servers
HB_ETC=/etc/honeybadger
SERVICE=hbdeck
PURGE=0
YES=0

die() { echo "ERROR: $*" >&2; exit 1; }

while [ $# -gt 0 ]; do
  case "$1" in
    --purge) PURGE=1; shift;;
    --yes|-y) YES=1; shift;;
    --prefix) PREFIX="${2:?}"; shift 2;;
    --user) HB_USER="${2:?}"; shift 2;;
    --data) HB_DATA="${2:?}"; shift 2;;
    --servers) HB_SERVERS="${2:?}"; shift 2;;
    --etc) HB_ETC="${2:?}"; shift 2;;
    --name) SERVICE="${2:?}"; shift 2;;
    -h|--help) sed -n '2,/^# =====*$/p' "$0" | sed 's/^# \{0,1\}//'; exit 0;;
    *) die "unknown option: $1";;
  esac
done
[ "$(id -u)" -eq 0 ] || die "run this as root:  sudo bash uninstall.sh"

# Refuse obviously dangerous paths before any rm -rf.
for p in "$PREFIX" "$HB_DATA" "$HB_SERVERS" "$HB_ETC"; do
  case "$p" in ''|/|/usr|/etc|/var|/srv|/opt|/home|/root|/var/lib) die "refusing to touch path '$p'";; esac
done

if [ "$PURGE" = 1 ] && [ "$YES" = 0 ]; then
  [ -t 0 ] || die "--purge needs a terminal to confirm; add --yes to run it unattended"
  echo "This will DELETE: $HB_SERVERS (all game servers, maps, saves), $HB_DATA, $HB_ETC and user $HB_USER."
  read -r -p "Type DELETE to continue: " ans
  [ "$ans" = "DELETE" ] || die "cancelled"
fi

echo "==> Stopping the service (it saves and stops every game server first; can take a minute or two)"
if [ -d /run/systemd/system ]; then
  systemctl stop "$SERVICE" 2>/dev/null || true
  systemctl disable "$SERVICE" 2>/dev/null || true
fi
rm -f "/etc/systemd/system/$SERVICE.service" "/etc/logrotate.d/$SERVICE"
[ -d /run/systemd/system ] && systemctl daemon-reload || true

echo "==> Removing the program ($PREFIX)"
rm -rf "$PREFIX"

if [ "$PURGE" = 1 ]; then
  echo "==> Purging servers, data, config and user"
  rm -rf "$HB_SERVERS" "$HB_DATA" "$HB_ETC"
  rmdir "$(dirname "$HB_SERVERS")" 2>/dev/null || true
  if id -u "$HB_USER" >/dev/null 2>&1; then userdel "$HB_USER" 2>/dev/null || true; fi
  echo "Done. Everything is gone."
else
  echo "Done. KEPT (use --purge to delete):"
  echo "   game servers  $HB_SERVERS"
  echo "   data/state    $HB_DATA"
  echo "   settings      $HB_ETC/engine.env"
  echo "   user          $HB_USER"
fi
