"""Mod frameworks: Carbon (our default), Oxide, or Vanilla (none).

Facts (docs/INSTALL_RECIPE.md sec 3, checked against the real archives 2026-10-27):
- Carbon: github.com/CarbonCommunity/Carbon/releases/download/production_build/
    Carbon.Windows.Release.zip   -> winhttp.dll, doorstop_config.ini, Carbon.targets, carbon/...
    Carbon.Linux.Release.tar.gz  -> libdoorstop.so, carbon.sh, Carbon.targets, carbon/...
  plus a small .info JSON next to each with {"Version": "2.0.262", ...}. Unpacked OVER the server folder.
  SteamCMD validate does not break Carbon (it adds files; it replaces nothing of the depot).
- Oxide: Windows https://umod.org/games/rust/download?tag=public (redirects to GitHub Oxide.Rust.zip);
  Linux https://github.com/OxideMod/Oxide.Rust/releases/latest/download/Oxide.Rust-linux.zip (asset verified in
  release 2.0.7839). Oxide REPLACES game files (RustDedicated_Data/Managed/Assembly-CSharp.dll ...), so every
  SteamCMD run undoes it: we re-apply Oxide after every install/update/validate.
- Never both loaders at once. Vanilla = remove the files our receipt says we installed. Files the framework
  overwrote (Oxide) are restored by a SteamCMD validate.

A *receipt* (saved in state.db) lists exactly which files an install created, so removal never touches anything
we did not put there (an unknown winhttp.dll is never deleted).
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from .archive import download, extract_any, plan_tar, plan_zip, sha256_file
from .models import Profile, iso, utcnow
from .operations import OpError, run_blocking, uncancellable

if TYPE_CHECKING:
    from .engine import Engine

CARBON_BASE = "https://github.com/CarbonCommunity/Carbon/releases/download/production_build/"
SOURCES: dict[str, dict[str, str]] = {
    "carbon": {"windows": CARBON_BASE + "Carbon.Windows.Release.zip",
               "linux": CARBON_BASE + "Carbon.Linux.Release.tar.gz"},
    "oxide": {"windows": "https://umod.org/games/rust/download?tag=public",
              "linux": "https://github.com/OxideMod/Oxide.Rust/releases/latest/download/Oxide.Rust-linux.zip"},
}
ARCHIVE_NAMES = {("carbon", "windows"): "Carbon.Windows.Release.zip", ("carbon", "linux"): "Carbon.Linux.Release.tar.gz",
                 ("oxide", "windows"): "Oxide.Rust.zip", ("oxide", "linux"): "Oxide.Rust-linux.zip"}
PLUGIN_DIRS = {"carbon": ("carbon/plugins", "carbon/plugins.disabled"),
               "oxide": ("oxide/plugins", "oxide/plugins.disabled")}
DATA_DIRS = {"carbon": ["carbon/configs", "carbon/data", "carbon/plugins", "carbon/plugins.disabled"],
             "oxide": ["oxide/config", "oxide/data", "oxide/plugins", "oxide/plugins.disabled"]}


# The files each loader needs to actually LOAD (names checked against the real archives in C:\rust_server_ref\downloads
# 2026-10-28). Carbon without its doorstop (winhttp.dll + doorstop_config.ini on Windows, libdoorstop.so on Linux)
# never starts, even with every Carbon DLL present - so "the DLL is there" is not health on its own.
KEY_FILES: dict[tuple[str, str], tuple[str, ...]] = {
    ("carbon", "windows"): ("carbon/managed/Carbon.Preloader.dll", "winhttp.dll", "doorstop_config.ini"),
    ("carbon", "linux"): ("carbon/managed/Carbon.Preloader.dll", "libdoorstop.so"),
    ("oxide", "windows"): ("RustDedicated_Data/Managed/Oxide.Rust.dll", "RustDedicated_Data/Managed/Oxide.Core.dll"),
    ("oxide", "linux"): ("RustDedicated_Data/Managed/Oxide.Rust.dll", "RustDedicated_Data/Managed/Oxide.Core.dll"),
}


def probe_files(root: Path, os_name: str) -> dict[str, bool] | None:
    """Which loader files are on disk: {"carbon:winhttp.dll": True, ...}. None if the folder cannot be read.
    server_updates.framework_health() turns this into ok / missing / mismatch."""
    root = Path(root)
    out: dict[str, bool] = {}
    try:
        for (fw, os_key), names in KEY_FILES.items():
            if os_key != os_name:
                continue
            for rel in names:
                out[f"{fw}:{rel}"] = (root / rel).is_file()
    except OSError:
        return None
    return out


def detect_framework(root: Path) -> str | None:
    """Which loader is actually on disk (by its key file, not just a folder name)."""
    root = Path(root)
    if (root / "carbon" / "managed" / "Carbon.Preloader.dll").is_file():
        return "carbon"
    if (root / "RustDedicated_Data" / "Managed" / "Oxide.Rust.dll").is_file():
        return "oxide"
    return None


class FrameworkManager:
    def __init__(self, engine: "Engine") -> None:
        self.engine = engine
        # Tests point these at local files (file:// URLs); production uses SOURCES.
        self.sources: dict[str, dict[str, str]] = {k: dict(v) for k, v in SOURCES.items()}

    @property
    def os_name(self) -> str:
        return self.engine.platform.os_name

    def detect(self, root: Path) -> str | None:
        return detect_framework(root)

    def plugin_dirs(self, framework: str, root: Path) -> tuple[Path, Path] | None:
        if framework not in PLUGIN_DIRS:
            return None
        a, b = PLUGIN_DIRS[framework]
        return Path(root) / a, Path(root) / b

    # ----- download --------------------------------------------------------------------------------------
    async def fetch(self, framework: str, pin: str, log: Callable[[str], None]) -> tuple[Path, str | None, str]:
        """Download the framework archive (or a manifest-pinned artifact). Returns (archive, version, source)."""
        cache = self.engine.data_dir / "cache" / "frameworks"
        cache.mkdir(parents=True, exist_ok=True)
        fname = ARCHIVE_NAMES[(framework, self.os_name)]
        if pin and pin not in ("upstream", "upstream-latest"):
            art = self.engine.updates.artifact(pin)
            if art is None:
                raise OpError(f"pinned artifact '{pin}' is not in the verified manifest", "unknown_artifact")
            dest = cache / f"{pin}-{fname}"
            await self.engine.updates.download_artifact(art, dest)
            return dest, art.get("version"), art["url"]
        url = self.sources[framework][self.os_name]
        dest = cache / fname
        log(f"Downloading {framework} from {url}")
        await asyncio.to_thread(download, url, dest, max_bytes=300 << 20, timeout=120)
        version = None
        if framework == "carbon":
            info_url = url.rsplit(".", 2)[0] + ".info" if url.endswith(".tar.gz") else url.rsplit(".", 1)[0] + ".info"
            try:
                info_path = cache / (fname + ".info")
                await asyncio.to_thread(download, info_url, info_path, max_bytes=1 << 20, timeout=30)
                version = json.loads(info_path.read_text(encoding="utf-8")).get("Version")
            except Exception:  # noqa: BLE001 - the version label is nice to have, not required
                version = None
        return dest, version, url

    # ----- install / remove ------------------------------------------------------------------------------
    async def install(self, profile: Profile, framework: str, pin: str, log: Callable[[str], None], *,
                      release: dict[str, Any] | None = None) -> dict[str, Any]:
        """Download + unpack + write the receipt. `release` = server_updates.framework_latest() identity (release id,
        tag, asset id, asset updated_at, digest) when the caller knows it; it is stored in the receipt so a later
        check can tell a re-published `production_build` apart from the one we installed. Without it, the archive's
        sha256 (always recorded) is compared with GitHub's asset digest instead."""
        if framework == "vanilla":
            return {}
        root = Path(profile.install_root)
        other = detect_framework(root)
        if other and other != framework:
            raise OpError(f"{other} is installed; remove it before installing {framework}", "framework_conflict")
        archive, version, source = await self.fetch(framework, pin, log)
        if archive.name.endswith(".zip"):
            plan = [rel.as_posix() for _n, rel in plan_zip(archive)]
        else:
            plan = [rel.as_posix() for _m, rel in plan_tar(archive)]
        old = self.engine.store.get_receipt(profile.id, "framework") or {}
        prev_created = set(old.get("files", [])) if old.get("framework") == framework else set()
        existed = {f for f in plan if (root / f).exists() and f not in prev_created}

        async def unpack_and_record() -> tuple[dict[str, Any], list[str]]:
            # Extraction and its receipt are ONE unit: if the operation is cancelled mid-way, we still finish
            # unpacking and record which files we laid down (so Remove can clean them up later).
            files = await run_blocking(extract_any, archive, root)
            receipt = {
                "framework": framework, "version": version, "source": source, "pin": pin,
                "archive_sha256": await run_blocking(sha256_file, archive),
                "files": sorted((set(files) - existed) | prev_created),
                "overwritten": sorted(existed | set(old.get("overwritten", []))),
                "installed_at": iso(utcnow()), "os": self.os_name,
            }
            if release:
                keep = ("release_id", "tag", "version", "asset_id", "asset_name", "asset_updated_at", "digest")
                receipt["release"] = {k: release.get(k) for k in keep}
                if release.get("digest") and not str(release["digest"]).lower().endswith(receipt["archive_sha256"]):
                    log("Note: the downloaded file does not match GitHub's digest for that release; it may have "
                        "been re-published while we downloaded. The next update check will compare again.")
            self.engine.store.save_receipt(profile.id, "framework", receipt)
            return receipt, files

        receipt, files = await uncancellable(unpack_and_record())
        if version:
            self.engine.store.update_runtime(profile.id, framework_version=version)
        log(f"{framework} {version or ''} unpacked ({len(files)} files)")
        if framework == "carbon":
            self.apply_carbon_policy(profile, log)
        return receipt

    def remove(self, profile: Profile, log: Callable[[str], None]) -> bool:
        """Remove the loader files OUR receipt lists. Returns True if a SteamCMD validate is needed afterwards."""
        root = Path(profile.install_root)
        rec = self.engine.store.get_receipt(profile.id, "framework")
        current = detect_framework(root)
        if rec is None:
            if current:
                raise OpError(f"{current} was not installed by the Deck (imported server). To switch frameworks "
                              "safely, remove it by hand or start from a clean server folder.", "not_owned")
            return False
        keep_prefixes = tuple(p + "/" for p in DATA_DIRS.get(rec["framework"], []))
        removed = 0
        dirs: set[Path] = set()
        for rel in rec.get("files", []):
            if rel.startswith(keep_prefixes):
                continue                              # user data/plugins/configs are never deleted here
            target = (root / rel).resolve()
            if root.resolve() not in target.parents:
                continue
            if target.is_file() and not target.is_symlink():
                target.unlink()
                removed += 1
                dirs.add(target.parent)
        for d in sorted(dirs, key=lambda p: len(p.parts), reverse=True):   # tidy now-empty folders we created
            while d != root.resolve() and root.resolve() in d.parents:
                try:
                    d.rmdir()
                except OSError:
                    break
                d = d.parent
        self.engine.store.delete_receipt(profile.id, "framework")
        log(f"Removed {removed} {rec['framework']} files")
        return bool(rec.get("overwritten"))

    # ----- policies --------------------------------------------------------------------------------------
    def apply_carbon_policy(self, profile: Profile, log: Callable[[str], None]) -> None:
        """Pinned build = turn Carbon's self-updater off so it cannot move past the pin (codex failure mode 7)."""
        cfg = Path(profile.install_root) / "carbon" / "config.json"
        if profile.framework_pin in ("upstream", "upstream-latest") or not cfg.exists():
            return
        try:
            data = json.loads(cfg.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            log("carbon/config.json could not be read; self-update policy not applied")
            return
        su = data.setdefault("SelfUpdating", {})
        if su.get("Enabled") is not False:
            su["Enabled"] = False
            tmp = cfg.with_suffix(".json.tmp")
            tmp.write_text(json.dumps(data, indent=2), encoding="utf-8")
            os.replace(tmp, cfg)
            log("Carbon self-update switched OFF (pinned build)")

    def pre_start_checks(self, profile: Profile, log: Callable[[str], None]) -> None:
        root = Path(profile.install_root)
        actual = detect_framework(root)
        want = profile.framework
        if want != "vanilla" and actual != want:
            log(f"Note: profile wants {want} but {actual or 'no framework'} is installed in the server folder.")
        if want == "vanilla" and actual:
            log(f"Note: profile is set to vanilla but {actual} files are present, so {actual} will load.")
        if actual == "carbon":
            self.apply_carbon_policy(profile, log)

    def preload_bundled_plugins(self, profile: Profile, log: Callable[[str], None]) -> list[str]:
        """Copy the bundled HoneyBadger DPS Meter into the plugins folder (only if not already there)."""
        fw = detect_framework(Path(profile.install_root))
        dirs = self.plugin_dirs(fw or "", Path(profile.install_root))
        if not profile.preload_plugins or dirs is None:
            return []
        bundled = Path(__file__).parent / "bundled" / "plugins"
        copied = []
        for src in sorted(bundled.glob("*.cs")):
            dest = dirs[0] / src.name
            disabled = dirs[1] / src.name
            if dest.exists() or disabled.exists():
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dest)
            copied.append(src.name)
            self.engine.store.save_plugin_record(profile.id, {
                "id": f"{profile.id}:{src.stem.lower()}", "filename": src.name, "source": "bundled",
                "sha256": sha256_file(dest), "installed_at": iso(utcnow())})
            log(f"Preloaded plugin {src.name}")
        return copied
