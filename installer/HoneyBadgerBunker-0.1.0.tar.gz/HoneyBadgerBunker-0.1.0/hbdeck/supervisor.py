"""The supervisor: starts, watches, stops and (if it crashes) restarts ONE game server process.

States (what the UI shows as `state`; the exact internal step is `phase`):
    stopped -> spawning -> starting -> running -> stopping -> stopped
    unexpected exit -> backoff (5 / 15 / 45 s) -> spawning ... or crash_loop (breaker tripped)
    conflict      a server we do NOT own is already running this world or these ports: we refuse to start
    stop_failed   we tried everything and could not verify that the process died
(`spawning` and `backoff` are shown to older screens as `starting`.)

Rules that came from real failures in other tools (docs/team/replies/codex_design_review, sec 4):
- "running" means the process is alive AND this run's log printed "Server startup complete". Never a timer.
- Map generation can take many minutes: RCON keeps reconnecting forever while the process lives.
- Graceful stop = server.save -> wait for a FRESH "Saving complete" in this run's log -> quit -> wait for exit.
  Only after stop_deadline_s do we force-kill, and we record that as unsafe (the world may not be saved).
  A fresh "Saving complete" proves A save happened after we asked; an autosave at the same moment would also count.
- Exit codes cannot tell a clean quit from a crash (Rust exits -1 after a clean quit on Windows), so we remember
  whether WE asked it to stop. Any other exit is a crash.
- Crash restarts back off (5/15/45 s) and a breaker trips after 3 crashes in 5 minutes. The breaker is saved in
  state.db, so restarting the engine cannot dodge it; the user must press Start again (resume) to clear it.

Process guards (28 Oct 2026, docs/team/guards/GUARD_PLAN_2026-10-28.md):
- desired ("run"/"stop") is what the user wants; phase is what we observe. A crash restart happens only while
  desired is "run" AND the engine is still running.
- Every run gets a unique id (`generation`, a UUID). Watchers, log lines and restarts carry the id of their run;
  a callback from an old run can never change a newer run.
- One lock (`_transition`) serialises start, stop and the crash-restart decision. The spawn itself re-checks
  "is the engine still allowed to start servers?" with no pause between the check and process creation.
- Stopping never waits forever: every wait is bounded, and death is checked by polling the pid + creation time,
  not by trusting the watcher task.
- Before a start: the server-folder lock, machine-wide identity/port reservations, the pid file, an exact-token
  scan of every process command line and port probes. A server we do not own = CONFLICT: we refuse, never adopt.
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any

import psutil

from . import guards
from .console import LineDecoder, LogTailer
from .games import get_game
from .models import CrashInfo, PlayerRow, ProcessStats, Profile, Status, Supervision, Telemetry, iso, utcnow
from .operations import OpError
from .platform import kill_and_reap, process_liveness
from .ports import find_collisions, probe_free
from .profiles import atomic_write, render_server_cfg, render_users_cfg, strip_cfg_keys
from .rcon import RconClient, RconUnavailable, parse_carbon_plugins

if TYPE_CHECKING:
    from .engine import Engine

log = logging.getLogger(__name__)

# phases (internal state machine)
STOPPED, SPAWNING, STARTING, RUNNING, BACKOFF = "stopped", "spawning", "starting", "running", "backoff"
STOPPING, CRASH_LOOP, FAILED, CONFLICT, STOP_FAILED = "stopping", "crash_loop", "failed", "conflict", "stop_failed"
RUN, STOP = "run", "stop"
# what older screens see for each phase (Status.state)
PUBLIC_STATE = {SPAWNING: "starting", BACKOFF: "starting"}


def mask_argv(argv: list[str]) -> list[str]:
    """Copy of argv with the RCON password replaced by ****** (for the console / logs)."""
    out = list(argv)
    for i, a in enumerate(out[:-1]):
        if a == "+rcon.password":
            out[i + 1] = "******"
    return out


class Supervisor:
    def __init__(self, engine: "Engine", profile_id: str) -> None:
        self.engine = engine
        self.profile_id = profile_id
        self.phase = STOPPED                         # exact internal state (see module docstring)
        self.state = "stopped"                       # what the UI shows (phase, with spawning/backoff = starting)
        self.desired = STOP                          # what the user wants: "run" or "stop"
        self.busy_state: str | None = None          # installing / updating / backing_up / wiping (set by operations)
        self.proc: asyncio.subprocess.Process | None = None
        self.pid: int | None = None
        self.create_time: float | None = None        # OS creation time of self.pid (pid + this = THIS process)
        self._ps: psutil.Process | None = None
        self.started_at: float | None = None        # time.time() of launch
        self._started_mono = 0.0
        self.run_id: str | None = None               # = generation (kept under the old name for status/logs)
        self.generation: str | None = None           # UUID of the current run
        self._finalized_gen: str | None = None       # the run whose exit was already handled
        self.run_log: Path | None = None
        self.rcon: RconClient | None = None
        self.telemetry: Telemetry | None = None
        self.process_stats: ProcessStats | None = None
        self.players: list[PlayerRow] | None = None
        self.last_error: str | None = None
        self.expected_exit = False
        self.loaded_plugins: dict[str, str] = {}
        self.framework_version_seen: str | None = None
        self.conflict: dict[str, Any] | None = None  # the server we do not own (CONFLICT), shown on the Deck
        self._startup_seen = asyncio.Event()
        self._exit_event = asyncio.Event()
        self._exit_event.set()                       # "not running" = already exited
        self._save_count = 0
        self._save_cond = asyncio.Condition()
        self._telemetry_ok_mono: float | None = None  # time.monotonic() of the last SUCCESSFUL serverinfo this run
        self._tasks: list[asyncio.Task[Any]] = []
        self._restart_task: asyncio.Task[None] | None = None
        self._transition = asyncio.Lock()            # start / stop / restart decision: one at a time
        self._lock = None
        self._reservations: guards.Reservations | None = None
        self._game = None  # type: ignore[assignment]

    # ----- small helpers ---------------------------------------------------------------------------------
    @property
    def profile(self) -> Profile:
        p = self.engine.store.get_profile(self.profile_id)
        if p is None:
            raise OpError("profile not found", "not_found")
        return p

    def console(self):  # noqa: ANN201 - returns ConsoleBuffer
        return self.engine.console(self.profile_id)

    def say(self, text: str, level: str | None = None) -> None:
        self.console().append("system", text, level)

    def set_phase(self, phase: str) -> None:
        public = PUBLIC_STATE.get(phase, phase)
        changed = phase != self.phase or public != self.state
        self.phase = phase
        self.state = public
        if changed:
            self.engine.publish_status(self.profile_id)

    def set_state(self, state: str) -> None:
        """Older name for set_phase (the public states are also phases)."""
        self.set_phase(state)

    @property
    def alive(self) -> bool:
        return not self._exit_event.is_set()

    def ensure_lock(self) -> None:
        """Cross-process lock on the install folder: two engines can never drive one server."""
        if self._lock is not None and self._lock.held:
            return
        from .platform import LockBusy
        root = Path(self.profile.install_root)
        root.mkdir(parents=True, exist_ok=True)
        lk = self.engine.platform.lock(root / "hbdeck.lock")
        try:
            lk.acquire()
        except LockBusy as exc:
            raise OpError("another HoneyBadger Bunker is already managing this server folder",
                          "locked") from exc
        self._lock = lk

    def release_lock(self) -> None:
        if self._lock is not None:
            self._lock.release()
            self._lock = None

    def reserve(self, prof: Profile) -> None:
        """Machine-wide reservations for this world's identity and every port (sorted order, all or nothing)."""
        if self._reservations is None:
            self._reservations = guards.Reservations(self.engine.platform, self.engine.reservations_dir)
        keys = guards.reservation_keys(prof.identity, [(proto, port) for proto, port, _r in prof.ports.binds()])
        owner = {"pid": os.getpid(), "engine_instance": self.engine.instance_id, "data_dir": str(self.engine.data_dir),
                 "profile_id": prof.id, "identity": prof.identity}
        try:
            self._reservations.acquire(keys, owner)
        except guards.ReservationBusy as exc:
            raise OpError(f"another HoneyBadger Bunker on this PC (pid {exc.holder.get('pid', 'unknown')}, data "
                          f"folder {exc.holder.get('data_dir', 'unknown')}) is starting or running a server with "
                          f"the same {'world identity' if exc.key.startswith('identity-') else 'port'} "
                          f"({exc.key})", "server_already_running",
                          {"reservation": exc.key, "holder": exc.holder}) from exc

    def release_reservations(self) -> None:
        if self._reservations is not None:
            self._reservations.release_all()

    # ----- status ------------------------------------------------------------------------------------------
    def status(self) -> Status:
        prof = self.engine.store.get_profile(self.profile_id)
        rt = self.engine.store.get_runtime(self.profile_id)
        installed = False
        fw_installed = None
        if prof is not None:
            game = get_game(prof.game)
            installed = game.is_installed(Path(prof.install_root), self.engine.platform.os_name)
            fw_installed = self.engine.frameworks.detect(Path(prof.install_root))
        state = self.state
        if self.busy_state and not self.alive and self.phase != CONFLICT:
            state = self.busy_state
        uptime = int(time.time() - self.started_at) if (self.started_at and self.alive) else None
        crash = self.crash_info(prof, rt)
        age = None
        if self.alive and self._telemetry_ok_mono is not None:
            age = round(time.monotonic() - self._telemetry_ok_mono, 1)
        last_wipe = rt.get("last_wipe") if isinstance(rt.get("last_wipe"), dict) else None
        return Status(
            profile_id=self.profile_id, state=state, installed=installed, build_id=rt.get("build_id"),  # type: ignore[arg-type]
            framework_installed=fw_installed,
            framework_version=self.framework_version_seen or rt.get("framework_version"),
            pid=self.pid if self.alive else None, started=iso_from_ts(self.started_at) if self.alive else None,
            uptime_s=uptime, rcon=(self.rcon.state if (self.rcon and self.alive) else "disconnected"),  # type: ignore[arg-type]
            telemetry=self.telemetry if self.alive else None, process=self.process_stats if self.alive else None,
            operation=self.engine.ops.brief(self.profile_id), last_error=self.last_error,
            crash_count=crash.count, crash=crash, telemetry_age_s=age, last_save_at=rt.get("last_save_at"),
            run_log=str(self.run_log) if self.run_log else rt.get("run_log"), last_update=rt.get("last_update"),
            last_wipe=last_wipe, phase=self.phase, desired=self.desired, run_id=self.run_id,
            conflict=dict(self.conflict) if self.conflict else None)  # type: ignore[arg-type]

    def crash_info(self, prof: Profile | None, rt: dict[str, Any]) -> CrashInfo:
        """The crash counter exactly as the breaker sees it (pinned by tests/test_supervisor_status.py)."""
        sup = prof.supervision if prof is not None else Supervision()
        healthy_for = None
        if self.alive and self.state == "running" and self._started_mono:
            healthy_for = time.monotonic() - self._started_mono
        count = crash_summary(rt.get("crash_times", []), time.time(), sup.breaker_window_s, sup.stable_reset_s,
                              healthy_for)
        return CrashInfo(count=count, window_s=sup.breaker_window_s, breaker_exits=sup.breaker_exits,
                         breaker_tripped=bool(rt.get("breaker_tripped")), last_exit_at=rt.get("last_crash_at"))

    # ----- conflict (a server we do not own) -------------------------------------------------------------------
    def enter_conflict(self, found: dict[str, Any]) -> None:
        """Refuse-and-surface: remember the survivor, stop wanting to run, never restart on our own."""
        self.desired = STOP
        self.cancel_restart()
        prev = self.conflict or {}
        same = prev.get("pid") == found.get("pid")
        self.conflict = {**found, "acknowledged": bool(prev.get("acknowledged")) if same else False,
                         "detected_at": prev.get("detected_at") if same else iso(utcnow())}
        port = found.get("port")
        self.last_error = (f"A server from a previous session may still be running (pid {found.get('pid')}"
                           f"{f', port {port}' if port else ''}, identity {found.get('identity')}). It is not "
                           "controlled by this Deck. Use 'Stop it' or 'Leave it' on the Deck.")
        self.release_reservations()
        self.set_phase(CONFLICT)

    def clear_conflict(self) -> None:
        self.conflict = None
        if self.phase == CONFLICT:
            self.last_error = None
            self.set_phase(STOPPED)

    def check_conflicts(self, prof: Profile) -> None:
        """Refuse (409 server_already_running) when anything else is running this world or these ports."""
        found = self.engine.detect_survivor(prof)
        if found is not None:
            self.enter_conflict(found)
            raise OpError(self.last_error or "a server is already running", "server_already_running",
                          {k: found.get(k) for k in ("pid", "port", "identity", "verified", "reasons")})
        if self.phase == CONFLICT:
            self.clear_conflict()          # the survivor is gone now

    # ----- start -------------------------------------------------------------------------------------------
    def _gate(self, automatic: bool) -> None:
        """The spawn guard. Called under _transition AND again directly before the process is created."""
        self.engine.check_spawn_allowed()
        if automatic and self.desired != RUN:
            raise OpError("the server was stopped; the automatic restart is cancelled", "cancelled")

    async def start(self, *, resume: bool = False, automatic: bool = False) -> None:
        """Launch the server hidden. Returns once the process exists (use wait_running() to wait for boot)."""
        if self.alive:
            raise OpError("the server is already running", "already_running")
        if not automatic:
            self.desired = RUN               # a person (or schedule/operation) wants it running
        async with self._transition:
            try:
                await self._start_locked(automatic)
            except BaseException:
                if not automatic and not self.alive:
                    self.desired = STOP
                raise

    async def _start_locked(self, automatic: bool) -> None:
        self._gate(automatic)
        if self.alive:
            raise OpError("the server is already running", "already_running")
        prof = self.profile
        game = get_game(prof.game)
        plat = self.engine.platform
        rt = self.engine.store.get_runtime(self.profile_id)
        if automatic and rt.get("breaker_tripped"):
            raise OpError("crash breaker is tripped; press Start to try again", "crash_loop")
        if not automatic:
            # A start pressed by a person (or a schedule) is the explicit "resume" that clears the breaker.
            if rt.get("breaker_tripped"):
                self.say("Crash breaker reset by the user.")
            self.engine.store.update_runtime(self.profile_id, breaker_tripped=False, crash_times=[])
        if not game.is_installed(Path(prof.install_root), plat.os_name):
            raise OpError("the server files are not installed yet - run Install first", "not_installed")
        self.ensure_lock()
        self.reserve(prof)
        try:
            await self._spawn_run(prof, game, automatic)
        except BaseException:
            if not self.alive:
                self.release_reservations()
            raise

    async def _spawn_run(self, prof: Profile, game: Any, automatic: bool) -> None:
        plat = self.engine.platform
        self.check_conflicts(prof)
        others = [p for p in self.engine.store.list_profiles() if p.id != prof.id]
        cols = find_collisions(prof.ports, others, exclude_id=prof.id, probe=lambda pr, po: probe_free(pr, po, "0.0.0.0"))
        if cols:
            c = cols[0]
            raise OpError(f"port {c.port}/{c.protocol} is already in use by {c.owner}", "port_in_use",
                          {"port": c.port, "owner": c.owner})
        self.engine.frameworks.pre_start_checks(prof, self.say)
        self.write_configs(prof)

        gen = guards.new_run_id()
        log_dir = self.engine.data_dir / "logs" / prof.identity
        log_dir.mkdir(parents=True, exist_ok=True)
        stamp = utcnow().strftime("%Y%m%d-%H%M%S")
        run_log = log_dir / f"{stamp}-{gen[:8]}.log"
        password = self.engine.rcon_password(prof)
        argv = game.build_argv(prof, plat.os_name, run_log, password)
        env = game.launch_env(prof, plat.os_name, dict(os.environ))
        install = Path(prof.install_root)
        base_record = {"run_id": gen, "engine_instance": self.engine.instance_id, "engine_pid": os.getpid(),
                       "data_dir": str(self.engine.data_dir), "profile_id": prof.id, "identity": prof.identity,
                       "ports": [port for _p, port, _r in prof.ports.binds()]}
        # The pid file is written BEFORE the spawn ("starting"), so a second start can never slip through the gap
        # between "process created" and "pid recorded" (Hermes).
        guards.write_pid_file(install, {**base_record, "state": "starting", "at": guards.now_iso()}, plat)

        self.say("Starting: " + " ".join(mask_argv(argv)))
        self._game = game
        self.generation = gen
        self.run_id = gen
        self.run_log = run_log
        self.expected_exit = False
        self.telemetry = None
        self._telemetry_ok_mono = None
        self.players = None
        self.process_stats = None
        self.loaded_plugins = {}
        self._startup_seen = asyncio.Event()
        self._exit_event = asyncio.Event()
        self.set_phase(SPAWNING)
        try:
            proc = await self._spawn_owned(argv, install, env, automatic)
        except BaseException as exc:
            self._exit_event.set()
            guards.remove_pid_file_if(install, gen)
            if isinstance(exc, OpError) and exc.code in ("engine_stopping", "cancelled"):
                self.set_phase(STOPPED)
                raise
            if isinstance(exc, OSError):
                self.set_phase(FAILED)
                self.last_error = f"could not start the server program: {exc}"
                raise OpError(self.last_error, "spawn_failed") from exc
            self.set_phase(STOPPED if isinstance(exc, asyncio.CancelledError) else FAILED)
            raise
        self.proc = proc
        self.pid = proc.pid
        self.create_time = guards.create_time_of(proc.pid)
        # Register ownership, then publish the pid record. If publishing fails the child is stopped and reaped:
        # a server whose pid nobody wrote down is exactly the orphan this guard exists to prevent.
        try:
            self.engine.registry.add("game", proc.pid, self.create_time, argv, install_root=install,
                                     data_dir=self.engine.data_dir, instance=self.engine.instance_id, run_id=gen,
                                     profile_id=prof.id, identity=prof.identity, containment=plat.containment(),
                                     started_at=guards.now_iso())
            guards.write_pid_file(install, {**base_record, "state": "running", "pid": proc.pid,
                                            "create_time": self.create_time, "exe": argv[0],
                                            "at": guards.now_iso()}, plat)
        except Exception as exc:  # noqa: BLE001
            await kill_and_reap(proc, plat)
            self.engine.registry.remove(proc.pid, self.create_time)
            guards.remove_pid_file_if(install, gen)
            self._exit_event.set()
            self.pid = None
            self.set_phase(FAILED)
            self.last_error = f"the server was stopped again because its process id could not be recorded: {exc}"
            raise OpError(self.last_error, "metadata_failed") from exc
        try:
            self._ps = psutil.Process(self.pid)
            self._ps.cpu_percent(None)
        except psutil.Error:
            self._ps = None
        self.started_at = time.time()
        self._started_mono = time.monotonic()
        self.engine.store.update_runtime(self.profile_id, last_pid=self.pid, last_create_time=self.create_time,
                                         run_id=gen, run_log=str(run_log))
        if not automatic:
            self.last_error = None
        self.set_phase(STARTING)

        tailer = LogTailer(run_log, lambda line, g=gen: self._on_log_line(line, g), interval=self.engine.tail_interval)
        host = "127.0.0.1" if prof.bind_ip in ("0.0.0.0", "::") else prof.bind_ip
        self.rcon = RconClient(host, prof.ports.rcon_tcp, password, on_state=lambda s: self.engine.publish_status(self.profile_id),
                               on_broadcast=self._on_rcon_broadcast, backoff_cap_s=self.engine.rcon_backoff_cap)
        self.rcon.start()
        pipe_log = log_dir / f"{stamp}-{gen[:8]}.pipe.log"
        self._tasks = [
            asyncio.create_task(tailer.run(), name="tail"),
            asyncio.create_task(self._telemetry_loop(), name="telemetry"),
        ]
        self._tasks.append(asyncio.create_task(self._watch(proc, tailer, pipe_log, gen), name="watch"))

    async def _spawn_owned(self, argv: list[str], cwd: Path, env: dict[str, str],
                           automatic: bool) -> asyncio.subprocess.Process:
        """Create the process. If we are cancelled while it is being created, the child is killed and reaped -
        ownership is never silently dropped."""
        plat = self.engine.platform
        task = asyncio.ensure_future(plat.spawn(argv, cwd=cwd, env=env, gate=lambda: self._gate(automatic)))
        try:
            return await asyncio.shield(task)
        except asyncio.CancelledError:
            try:
                proc = await task
            except BaseException:  # noqa: BLE001 - nothing was created
                raise asyncio.CancelledError() from None
            await kill_and_reap(proc, plat)
            raise

    def write_configs(self, prof: Profile, remove: "list[str] | tuple[str, ...]" = ()) -> None:
        """Render server.cfg and users.cfg (managed lines only; everything else kept) before every launch.

        remove = option names the user just removed (PUT /convars with null): exactly those lines are taken out
        of server.cfg first, so they are not kept as if the user had typed them by hand."""
        game = get_game(prof.game)
        cfg_dir = game.identity_dir(prof) / "cfg"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        server_cfg = cfg_dir / "server.cfg"
        existing = server_cfg.read_text(encoding="utf-8", errors="replace") if server_cfg.exists() else ""
        values = dict(game.server_cfg_values(prof))
        drop = {k.lower() for k in remove if values.get(k.lower()) is None}
        base = strip_cfg_keys(existing, drop) if drop else existing
        values["rcon.password"] = None        # the password lives only on the command line (see games/rust.py)
        new = render_server_cfg(base, values)
        if new != existing:
            atomic_write(server_cfg, new, self.engine.platform)
        users_cfg = cfg_dir / "users.cfg"
        existing_u = users_cfg.read_text(encoding="utf-8", errors="replace") if users_cfg.exists() else ""
        new_u = render_users_cfg(existing_u, prof.admins)
        if new_u != existing_u:
            atomic_write(users_cfg, new_u, self.engine.platform)

    async def wait_running(self, timeout: float | None = None) -> bool:
        """Wait until 'Server startup complete' (True) or the process exits (False)."""
        waiters = [asyncio.create_task(self._startup_seen.wait()), asyncio.create_task(self._exit_event.wait())]
        try:
            done, _ = await asyncio.wait(waiters, timeout=timeout, return_when=asyncio.FIRST_COMPLETED)
        finally:
            for w in waiters:
                w.cancel()
        return self._startup_seen.is_set() and self.alive

    # ----- output handling ---------------------------------------------------------------------------------
    def _on_log_line(self, line: str, gen: str | None = None) -> None:
        if gen is not None and gen != self.generation:
            return                                   # a line from an older run: never let it change this one
        self.console().append("stdout", line)
        ev = self._game.parse_log_line(line) if line else None
        if ev is None:
            return
        if ev.kind == "startup_complete":
            self._startup_seen.set()
            if self.phase == STARTING and self.alive:
                self.set_phase(RUNNING)
                self.say("Server startup complete - players can join now.")
        elif ev.kind == "save_complete":
            self._save_count += 1
            # "last confirmed save" for the Deck: one small write per save (every save_interval, >= 60 s)
            self.engine.store.update_runtime(self.profile_id, last_save_at=iso(utcnow()))
            asyncio.get_running_loop().create_task(self._notify_save())
        elif ev.kind == "framework_version":
            self.framework_version_seen = ev.data.get("version")
            self.engine.store.update_runtime(self.profile_id, framework_version=self.framework_version_seen)
        elif ev.kind == "plugin_loaded":
            self.loaded_plugins[ev.data.get("title", "")] = ev.data.get("version", "")
        elif ev.kind == "plugin_unloaded":
            self.loaded_plugins.pop(ev.data.get("title", ""), None)
        elif ev.kind == "bind_error":
            self.last_error = f"a network port seems to be taken: {line}"

    async def _notify_save(self) -> None:
        async with self._save_cond:
            self._save_cond.notify_all()

    def _on_rcon_broadcast(self, msg: dict[str, Any]) -> None:
        # Generic broadcasts repeat the log file (already shown); chat is worth showing.
        if msg.get("Type") == "Chat":
            text = str(msg.get("Message", ""))
            try:
                import json
                d = json.loads(text)
                text = f"[CHAT] {d.get('Username', '?')}: {d.get('Message', '')}"
            except ValueError:
                pass
            self.console().append("rcon", text, "info")

    async def _pump(self, stream: asyncio.StreamReader | None, fh: Any) -> None:
        if stream is None:
            return
        dec = LineDecoder()
        while True:
            chunk = await stream.read(65536)
            if not chunk:
                break
            for ln in dec.feed(chunk):
                fh.write(ln + "\n")
                self.console().append("stdout", ln)
            fh.flush()
        for ln in dec.flush():
            fh.write(ln + "\n")
            self.console().append("stdout", ln)

    async def _watch(self, proc: asyncio.subprocess.Process, tailer: LogTailer, pipe_log: Path, gen: str) -> None:
        code: int | None = None
        try:
            with open(pipe_log, "a", encoding="utf-8") as fh:
                pumps = asyncio.gather(self._pump(proc.stdout, fh), self._pump(proc.stderr, fh))
                code = await proc.wait()
                try:
                    await asyncio.wait_for(pumps, 5)
                except asyncio.TimeoutError:
                    pass
        except asyncio.CancelledError:
            raise
        except Exception:  # noqa: BLE001 - a broken pipe log must not hide the exit
            log.exception("watcher for %s failed; waiting for the exit without the pipe log", self.profile_id)
            code = await proc.wait()
        tailer.stop()
        await asyncio.sleep(self.engine.tail_interval * 2)
        await self._on_exit(code, gen)

    async def _on_exit(self, code: int | None, gen: str | None = None) -> None:
        if gen is not None and gen != self.generation:
            log.info("ignoring the exit of an older run %s of %s", gen[:8], self.profile_id)
            return
        if gen is not None and self._finalized_gen == gen:
            return                                   # already handled (stop() may have finished it for the watcher)
        if gen is not None:
            self._finalized_gen = gen
        ran_s = time.monotonic() - self._started_mono
        if self.rcon is not None:
            await self.rcon.stop()
        for t in self._tasks:
            if t is not asyncio.current_task() and not t.done():
                t.cancel()
        self._exit_event.set()
        dead_pid, dead_ct = self.pid, self.create_time
        self.pid = None
        if dead_pid and process_liveness(dead_pid, dead_ct) == "dead":
            self.engine.registry.remove(dead_pid, dead_ct)
        prof = self.engine.store.get_profile(self.profile_id)
        if prof is not None and gen is not None:
            guards.remove_pid_file_if(Path(prof.install_root), gen)
        if prof is None:
            self.release_reservations()
            self.set_phase(STOPPED)
            return
        if self.expected_exit:
            self.say(f"Server stopped (exit code {code}).")
            self.release_reservations()
            self.set_phase(STOPPED)
            return
        # ---- unexpected exit = crash ----
        sup = prof.supervision
        now = time.time()
        rt = self.engine.store.get_runtime(self.profile_id)
        crashes = [t for t in rt.get("crash_times", []) if now - t <= sup.breaker_window_s]
        if ran_s >= sup.stable_reset_s:
            crashes = []                             # it ran healthy long enough: forgive older crashes
        crashes.append(now)
        self.engine.store.update_runtime(self.profile_id, last_crash_at=iso(utcnow()))
        self.last_error = f"the server exited unexpectedly (exit code {code}) after {int(ran_s)} s"
        self.say(self.last_error, "error")
        if len(crashes) >= sup.breaker_exits:
            self.engine.store.update_runtime(self.profile_id, crash_times=crashes, breaker_tripped=True)
            self.say(f"Crash breaker tripped: {len(crashes)} crashes within {sup.breaker_window_s} s. "
                     "Not restarting automatically - check the console, then press Start.", "error")
            self.release_reservations()
            self.set_phase(CRASH_LOOP)
            return
        self.engine.store.update_runtime(self.profile_id, crash_times=crashes)
        if not sup.restart_on_crash:
            self.release_reservations()
            self.set_phase(FAILED)
            return
        delay = sup.backoff_s[min(len(crashes) - 1, len(sup.backoff_s) - 1)] if sup.backoff_s else 5
        delay = delay * self.engine.backoff_scale
        # The restart decision is taken under the same lock as every spawn, and only while the user still wants
        # the server and the engine is not shutting down (the shutdown sets its flag before its first await).
        async with self._transition:
            if (gen is not None and gen != self.generation) or self.alive:
                return
            if self.desired != RUN or not self.engine.spawn_allowed():
                self.say("Not restarting: the server was stopped or the Deck is shutting down.", "warn")
                self.release_reservations()
                self.set_phase(STOPPED)
                return
            self.say(f"Restarting in {delay:g} s (crash {len(crashes)} of {sup.breaker_exits} allowed in "
                     f"{sup.breaker_window_s} s).", "warn")
            self.set_phase(BACKOFF)
            self._restart_task = asyncio.create_task(self._delayed_restart(delay, self.generation))

    async def _delayed_restart(self, delay: float, gen: str | None) -> None:
        try:
            await asyncio.sleep(delay)
        except asyncio.CancelledError:
            return
        if gen != self.generation or self.alive or self.desired != RUN:
            return
        try:
            await self.start(automatic=True)
        except asyncio.CancelledError:
            return
        except OpError as exc:
            if exc.code in ("engine_stopping", "cancelled"):
                if not self.alive and self.phase in (BACKOFF, SPAWNING):
                    self.set_phase(STOPPED)
                return
            if self.phase == CONFLICT:
                return
            self.last_error = str(exc)
            self.say(f"Automatic restart failed: {exc}", "error")
            self.set_phase(FAILED)

    def cancel_restart(self) -> None:
        """Cancel a pending crash restart (synchronous: no await, so nothing can slip in between)."""
        if self._restart_task is not None and not self._restart_task.done():
            self._restart_task.cancel()
        self._restart_task = None
        if not self.alive and self.phase == BACKOFF:
            self.release_reservations()
            self.set_phase(STOPPED)

    def on_engine_stopping(self) -> None:
        """Called by the engine BEFORE its first await when shutdown begins: nothing may start again."""
        self.desired = STOP
        if self.alive:
            self.expected_exit = True
        self.cancel_restart()

    # ----- stop --------------------------------------------------------------------------------------------
    async def stop(self, graceful: bool = True, deadline_s: float | None = None) -> bool:
        """Stop the server. Returns True if it stopped gracefully, False if it had to be killed (or could not be)."""
        self.desired = STOP
        if self.alive:
            self.expected_exit = True
        self.cancel_restart()
        async with self._transition:
            return await self._stop_locked(graceful, deadline_s)

    def _is_dead(self) -> bool:
        """Verified death of the current process, from the OS - never from the watcher's event."""
        if self.proc is not None and self.proc.returncode is not None:
            return True
        if self.pid is None:
            return not self.alive or self.proc is None
        return process_liveness(self.pid, self.create_time) == "dead"

    async def _wait_dead(self, timeout: float) -> bool:
        loop = asyncio.get_running_loop()
        end = loop.time() + max(0.0, timeout)
        while True:
            if self._is_dead():
                return True
            if loop.time() >= end:
                return False
            await asyncio.sleep(0.05)

    async def _stop_locked(self, graceful: bool, deadline_s: float | None) -> bool:
        self.cancel_restart()
        if not self.alive:
            if self.phase not in (CONFLICT, CRASH_LOOP, FAILED, STOP_FAILED):
                self.set_phase(STOPPED)
            self.release_reservations()
            return True
        prof = self.profile
        self.expected_exit = True
        self.set_phase(STOPPING)
        deadline = float(deadline_s if deadline_s is not None else prof.supervision.stop_deadline_s)
        loop = asyncio.get_running_loop()
        t_end = loop.time() + deadline

        def left() -> float:
            return max(0.0, t_end - loop.time())

        # Part of the budget is kept back for "quit" and the wait for the exit, so a server that never confirms
        # its save still gets asked to quit (which also saves) before we have to force it (Codex).
        quit_reserve = min(10.0, deadline * 0.25)

        def save_left() -> float:
            return max(0.0, left() - quit_reserve)

        exited = False
        if graceful and self.rcon is not None:
            if await self.rcon.wait_ready(save_left()):
                before = self._save_count
                self.say("Saving the world (server.save)...")
                if save_left() > 0.5:
                    try:
                        await self.rcon.command("server.save", timeout=min(30.0, save_left()))
                    except (RconUnavailable, asyncio.TimeoutError):
                        pass
                saved = await self._wait_save_after(before, save_left())
                self.say("Save confirmed (Saving complete)." if saved else
                         "No save confirmation before the deadline; sending quit anyway (quit also saves).",
                         None if saved else "warn")
                try:
                    await self.rcon.command("quit", timeout=max(0.5, min(5.0, left())), quiet_s=0.1)
                except (RconUnavailable, asyncio.TimeoutError, Exception):  # noqa: BLE001 - the socket closes on quit
                    pass
                exited = await self._wait_dead(left())
            else:
                self.say("RCON never became reachable, so the server cannot be asked to save and quit.", "warn")
        if not exited and not self._is_dead():
            self.say(f"Forcing the server to stop after {deadline:g} s - the world may NOT have been saved.", "error")
            self.last_error = f"forced stop after {deadline:g} s (unsafe: the world may not have been saved)"
            pid = self.pid
            if pid:
                plat = self.engine.platform
                await asyncio.to_thread(plat.terminate_tree, pid)
                if not await self._wait_dead(10):
                    await asyncio.to_thread(plat.kill_tree, pid)
                    await self._wait_dead(10)
        elif not exited:
            exited = True                            # it was already gone (e.g. quit landed as we gave up)
        if not self._is_dead():
            self.last_error = (f"could not verify that the server process (pid {self.pid}) ended; it may still be "
                               "running. Use Stop everything, or end it in Task Manager.")
            self.say(self.last_error, "error")
            self.set_phase(STOP_FAILED)
            return False
        # Dead for sure. Give the watcher a moment to finish its bookkeeping; if it is stuck, do it ourselves.
        if not await self._wait_exit(5):
            log.warning("watcher of %s did not report the exit; finishing it from stop()", self.profile_id)
            await self._on_exit(self.proc.returncode if self.proc else None, self.generation)
        self.release_reservations()
        if self.phase != STOPPED:
            self.set_phase(STOPPED)
        return exited

    async def _wait_save_after(self, before: int, timeout: float) -> bool:
        if self._save_count > before:
            return True
        try:
            async with self._save_cond:
                await asyncio.wait_for(self._save_cond.wait_for(lambda: self._save_count > before), timeout)
            return True
        except asyncio.TimeoutError:
            return False

    async def _wait_exit(self, timeout: float) -> bool:
        try:
            await asyncio.wait_for(self._exit_event.wait(), timeout)
            return True
        except asyncio.TimeoutError:
            return False

    # ----- telemetry ---------------------------------------------------------------------------------------
    async def _telemetry_loop(self) -> None:
        failures = 0
        tick = 0
        ncpu = psutil.cpu_count() or 1
        while True:
            await asyncio.sleep(self.engine.telemetry_interval)
            tick += 1
            if self._ps is not None:
                try:
                    with self._ps.oneshot():
                        cpu = self._ps.cpu_percent(None) / ncpu
                        rss = self._ps.memory_info().rss // (1024 * 1024)
                    self.process_stats = ProcessStats(cpu_pct=round(cpu, 1), rss_mb=int(rss))
                except psutil.Error:
                    self.process_stats = None
            if self.rcon is None or self.rcon.state != "ready":
                continue
            try:
                info = await self.rcon.serverinfo(timeout=5)
                if info is not None:
                    self.telemetry = info.to_telemetry()
                    self._telemetry_ok_mono = time.monotonic()   # freshness clock for Status.telemetry_age_s
                    failures = 0
                else:
                    failures += 1
                if tick % 2 == 0:
                    players = await self.rcon.playerlist(timeout=5)
                    if players is not None and (self.players is None or players != self.players):
                        self.players = players
                        self.engine.events.publish({"type": "players", "profile_id": self.profile_id,
                                                    "players": [p.model_dump() for p in players]})
            except (RconUnavailable, asyncio.TimeoutError):
                failures += 1
            except Exception:  # noqa: BLE001
                failures += 1
            if failures >= 3:
                failures = 0
                await self.rcon.force_reconnect()

    async def loaded_plugins_via_rcon(self) -> list[dict[str, str]] | None:
        """Ask Carbon which plugins are loaded (c.plugins). None if RCON is not available."""
        if self.rcon is None or self.rcon.state != "ready":
            return None
        try:
            reply = await self.rcon.command("c.plugins", timeout=5)
        except (RconUnavailable, asyncio.TimeoutError):
            return None
        return parse_carbon_plugins(reply.text)

    async def shutdown(self, deadline_s: float | None = None) -> dict[str, Any]:
        """Engine is exiting: stop gracefully if running (bounded), release the folder lock and reservations."""
        self.on_engine_stopping()
        result = "not_running"
        pid = self.pid
        try:
            if self.alive or self._transition.locked():
                clean = await self.stop(graceful=True, deadline_s=deadline_s)
                result = "stopped" if clean else ("stop_failed" if self.phase == STOP_FAILED else "forced")
        finally:
            self.release_reservations()
            self.release_lock()
        return {"profile_id": self.profile_id, "result": result, "pid": pid}


def crash_summary(crash_times: list[float], now: float, window_s: int, stable_reset_s: int,
                  healthy_for_s: float | None) -> int:
    """How many crashes count right now - the same rule the breaker uses.

    crash_times     the stored unix times of unexpected exits (a manual Start empties this list)
    window_s        only crashes inside the last window_s seconds count (supervision.breaker_window_s)
    healthy_for_s   how long the CURRENT run has been up and running (None when it is not running). Once it
                    reaches stable_reset_s every earlier crash is forgiven, exactly as _on_exit forgives them.
    """
    if healthy_for_s is not None and healthy_for_s >= stable_reset_s:
        return 0
    return sum(1 for t in crash_times if 0 <= now - t <= window_s)


def iso_from_ts(ts: float | None) -> str | None:
    if ts is None:
        return None
    import datetime as dt
    return iso(dt.datetime.fromtimestamp(ts, dt.timezone.utc))
