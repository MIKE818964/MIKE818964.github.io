"""Data shapes shared by the engine and the API (pydantic v2 models).

Every object the UI sees is defined here once, so the API, the database and the tests all agree on field names.
The field names follow docs/API_CONTRACT.md exactly.

Plain-English notes:
- A *Profile* is one server you manage ("Honey Badger Home"): where it is installed, its ports, map, admins...
- A *Status* is what we actually OBSERVED about that server right now (running? players? fps?). It is never stored
  as settings and never invented: unknown values stay None.
- An *Operation* is a background job (install, start, stop, wipe...) with named steps the UI can show.
"""
from __future__ import annotations

import datetime as dt
import re
import uuid
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_serializer, field_validator, model_validator

# ---------------------------------------------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------------------------------------------

IDENTITY_RE = re.compile(r"^[A-Za-z0-9_\-]{1,40}$")          # becomes a folder name: no slashes, dots or spaces
STEAMID64_RE = re.compile(r"^7656\d{13}$")                   # every Steam account id is 17 digits starting 7656
CONVAR_NAME_RE = re.compile(r"^[a-z0-9_]+(\.[a-z0-9_]+)*$")  # e.g. decay.scale, server.pve
EXTRA_ARG_RE = re.compile(r"^[^\x00\r\n]{1,512}$")


def utcnow() -> dt.datetime:
    """The current time in UTC (always timezone-aware so comparisons never mix local and UTC)."""
    return dt.datetime.now(dt.timezone.utc)


def iso(t: dt.datetime | None) -> str | None:
    """Format a time as ISO-8601 UTC text like 2026-10-27T14:00:00Z (what the API promises)."""
    if t is None:
        return None
    return t.astimezone(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def new_id() -> str:
    return str(uuid.uuid4())


def no_newlines(value: str, field: str) -> str:
    """Server config files are line based: a newline inside a value would let it inject a second setting."""
    if "\n" in value or "\r" in value or "\x00" in value:
        raise ValueError(f"{field} cannot contain line breaks")
    if '"' in value:
        raise ValueError(f'{field} cannot contain double quotes (")')
    return value


# ---------------------------------------------------------------------------------------------------------------
# Profile blocks
# ---------------------------------------------------------------------------------------------------------------

class Ports(BaseModel):
    """The network ports one server uses. game/query are UDP, rcon/app are TCP. app_tcp None = Rust+ off."""
    game_udp: int = Field(ge=1024, le=65535)
    query_udp: int = Field(ge=1024, le=65535)
    rcon_tcp: int = Field(ge=1024, le=65535)
    app_tcp: int | None = Field(default=None, ge=1024, le=65535)

    @model_validator(mode="after")
    def _distinct(self) -> "Ports":
        # Rust refuses a query port equal to the game port (both UDP); RCON and Rust+ are both TCP.
        if self.query_udp == self.game_udp:
            raise ValueError("query port must be different from the game port")
        if self.app_tcp is not None and self.app_tcp == self.rcon_tcp:
            raise ValueError("Rust+ port must be different from the RCON port")
        return self

    def binds(self) -> list[tuple[str, int, str]]:
        """Every (protocol, port, role) this server will open. Used by the collision checker."""
        out = [("udp", self.game_udp, "game"), ("udp", self.query_udp, "query"), ("tcp", self.rcon_tcp, "rcon")]
        if self.app_tcp is not None:
            out.append(("tcp", self.app_tcp, "app"))
        return out


class MapSettings(BaseModel):
    kind: Literal["procedural", "barren", "custom"] = "procedural"
    seed: int = Field(default=1, ge=0, le=2147483647)
    size: int = Field(default=3000, ge=1000, le=6000)
    custom_url: str | None = None

    @model_validator(mode="after")
    def _custom_needs_url(self) -> "MapSettings":
        if self.kind == "custom":
            if not self.custom_url or not self.custom_url.startswith(("https://", "http://")):
                raise ValueError("a custom map needs an http(s) download link")
            no_newlines(self.custom_url, "custom map link")
        return self


class Admin(BaseModel):
    steamid64: str
    role: Literal["owner", "moderator"] = "owner"
    name: str = ""

    @field_validator("steamid64")
    @classmethod
    def _steamid(cls, v: str) -> str:
        v = v.strip()
        if not STEAMID64_RE.match(v):
            raise ValueError("a SteamID64 is 17 digits and starts with 7656")
        return v

    @field_validator("name")
    @classmethod
    def _name(cls, v: str) -> str:
        return no_newlines(v, "admin name")


class Supervision(BaseModel):
    """How the engine babysits the server process."""
    restart_on_crash: bool = True
    backoff_s: list[int] = Field(default_factory=lambda: [5, 15, 45])
    breaker_exits: int = Field(default=3, ge=1, le=50)        # this many unexpected exits...
    breaker_window_s: int = Field(default=300, ge=10)          # ...inside this window = stop retrying (crash_loop)
    stop_deadline_s: int = Field(default=90, ge=5, le=3600)    # graceful stop budget before a forced kill
    stable_reset_s: int = Field(default=600, ge=10)            # healthy this long = crash counter resets


ServerState = Literal["stopped", "installing", "starting", "running", "stopping", "backing_up", "wiping",
                      "updating", "crash_loop", "failed", "conflict", "stop_failed"]
Framework = Literal["carbon", "oxide", "vanilla"]


class ProfileFields(BaseModel):
    """Everything a user may set on a profile (shared by create and update)."""
    model_config = ConfigDict(extra="ignore")

    name: str = Field(default="HoneyBadger Server", min_length=1, max_length=80)
    game: str = "rust"
    identity: str | None = None
    install_root: str | None = None
    steamcmd_root: str | None = None
    branch: str = Field(default="public", pattern=r"^[A-Za-z0-9_\-]{1,32}$")
    validate_on_update: bool = True
    framework: Framework = "carbon"
    framework_pin: str = "upstream"
    bind_ip: str = "0.0.0.0"
    hostname: str = Field(default="HoneyBadger Server", min_length=1, max_length=120)
    description: str = Field(default="", max_length=1000)
    url: str = Field(default="", max_length=300)
    header_image: str = Field(default="", max_length=300)
    max_players: int = Field(default=8, ge=1, le=1000)
    tickrate: int = Field(default=30, ge=10, le=100)
    save_interval: int = Field(default=600, ge=60, le=7200)
    map: MapSettings = Field(default_factory=MapSettings)
    gamemode: str = Field(default="vanilla", pattern=r"^[a-z0-9_]{1,32}$")
    pve: bool = False
    managed_convars: dict[str, str] = Field(default_factory=dict)
    extra_args: list[str] = Field(default_factory=list)
    admins: list[Admin] = Field(default_factory=list)
    supervision: Supervision = Field(default_factory=Supervision)
    autostart: bool = False
    preload_plugins: bool = True     # copy the bundled HoneyBadger DPS Meter on install (the funnel)

    @field_validator("identity")
    @classmethod
    def _identity(cls, v: str | None) -> str | None:
        if v is not None and not IDENTITY_RE.match(v):
            raise ValueError("identity may only use letters, digits, - and _ (it becomes a folder name)")
        return v

    @field_validator("hostname", "description", "url", "header_image", "name")
    @classmethod
    def _text(cls, v: str, info: Any) -> str:
        return no_newlines(v, info.field_name)

    @field_validator("bind_ip")
    @classmethod
    def _ip(cls, v: str) -> str:
        import ipaddress
        ipaddress.ip_address(v)          # raises ValueError for anything that is not an IP address
        return v

    @field_validator("managed_convars")
    @classmethod
    def _convars(cls, v: dict[str, str]) -> dict[str, str]:
        out: dict[str, str] = {}
        for k, val in v.items():
            k2 = k.strip().lower()
            if not CONVAR_NAME_RE.match(k2):
                raise ValueError(f"'{k}' is not a valid setting name")
            out[k2] = no_newlines(str(val), k2)
        return out

    @field_validator("extra_args")
    @classmethod
    def _extra(cls, v: list[str]) -> list[str]:
        for a in v:
            if not EXTRA_ARG_RE.match(a):
                raise ValueError("extra launch arguments cannot be empty or contain line breaks")
        return v


class ProfileCreate(ProfileFields):
    """POST /profiles body. ports may be the word "auto" (engine picks free ones)."""
    ports: Ports | Literal["auto"] = "auto"
    existing_install: bool = False   # True = adopt the server already in install_root (do not install)


class Profile(ProfileFields):
    id: str = Field(default_factory=new_id)
    identity: str = "hbserver"
    install_root: str = ""
    ports: Ports
    imported: bool = False          # True = adopted an existing install (we did not lay down its files)
    created: str | None = None
    updated: str | None = None
    # The address friends type when the looked-up public address is wrong (VPN, odd routing, dynamic DNS name).
    # None = use the detected one. network.py prefers this over its own cache; PUT /connect keeps both in step.
    public_address_override: str | None = None

    @field_validator("public_address_override")
    @classmethod
    def _override(cls, v: str | None) -> str | None:
        from .network import validate_public_override    # imported here: network.py is a bigger module
        return validate_public_override(v)


# ---------------------------------------------------------------------------------------------------------------
# Observed state
# ---------------------------------------------------------------------------------------------------------------

class Telemetry(BaseModel):
    """One serverinfo reading. Every field is what Rust reported; None = Rust did not say (never a made-up 0)."""
    at: str | None = None
    players: int | None = None
    max_players: int | None = None
    queued: int | None = None
    joining: int | None = None
    reserved_slots: int | None = None       # serverinfo "ReservedSlots"
    entities: int | None = None
    fps: float | None = None
    memory_mb: int | None = None            # the game's managed memory (serverinfo "Memory")
    memory_system_mb: int | None = None     # the game's own view of system memory use ("MemoryUsageSystem")
    collections: int | None = None          # garbage-collection counter since boot ("Collections"), not a pause time
    net_in: int | None = None               # bytes in during the last second
    net_out: int | None = None
    game_time: str | None = None
    map: str | None = None
    protocol: str | None = None
    version: int | None = None              # Rust's own version number ("Version", e.g. 2635), not the Steam build
    restarting: bool | None = None          # Rust's "a restart is pending" flag ("Restarting")
    hostname: str | None = None
    uptime_s: int | None = None
    save_created: str | None = None         # when the world save was CREATED (wipe date), not the last autosave


class ProcessStats(BaseModel):
    cpu_pct: float | None = None
    rss_mb: int | None = None


class CrashInfo(BaseModel):
    """The crash counter with its rules attached, so the UI can label it truthfully.

    count          unexpected exits inside the last window_s seconds. A manual Start clears it, and a run that stays
                   up for supervision.stable_reset_s forgives older crashes (see crash_summary in supervisor.py).
    last_exit_at   the most recent unexpected exit ever seen (NOT cleared by a manual Start); None = never.
    """
    count: int = 0
    window_s: int = 300
    breaker_exits: int = 3
    breaker_tripped: bool = False
    last_exit_at: str | None = None


class LastWipe(BaseModel):
    """The last wipe the Bunker itself did (wipes done by hand outside the Bunker are not seen)."""
    scope: str
    at: str
    seed: int | None = None


class OperationBrief(BaseModel):
    id: str
    kind: str
    step: str | None = None
    percent: float | None = None


class Status(BaseModel):
    profile_id: str
    state: ServerState = "stopped"
    installed: bool = False
    build_id: str | None = None
    framework_installed: str | None = None
    framework_version: str | None = None
    pid: int | None = None
    started: str | None = None
    uptime_s: int | None = None
    rcon: Literal["disconnected", "connecting", "ready"] = "disconnected"
    telemetry: Telemetry | None = None
    process: ProcessStats | None = None
    operation: OperationBrief | None = None
    last_error: str | None = None
    crash_count: int = 0                     # same number as crash.count (kept for older screens)
    telemetry_age_s: float | None = None     # seconds since the last SUCCESSFUL serverinfo; None = no reading this run
    last_save_at: str | None = None          # last "Saving complete" seen in the server log (ISO UTC); None = never
    run_log: str | None = None               # this run's server log file
    last_update: str | None = None           # last successful install/update by the Bunker
    last_wipe: LastWipe | None = None
    crash: CrashInfo = Field(default_factory=CrashInfo)
    # ---- process guards (2026-10-28) ----
    phase: str | None = None                 # exact supervisor step: stopped/spawning/starting/running/backoff/...
    desired: Literal["run", "stop"] | None = None   # what the user asked for (crash restarts only while "run")
    run_id: str | None = None                # UUID of the current/last run
    conflict: dict[str, Any] | None = None   # a server we do NOT own holds this world/port: {pid, port, identity, ...}


class Step(BaseModel):
    name: str
    state: Literal["pending", "running", "done", "failed", "skipped", "cancelled"] = "pending"
    started: str | None = None
    finished: str | None = None
    detail: str | None = None


OperationKind = Literal["install", "update", "start", "stop", "restart", "wipe", "backup", "restore", "framework",
                        "plugin", "app_update", "convars", "conflict_stop", "kill_all", "verify"]


class Operation(BaseModel):
    id: str = Field(default_factory=new_id)
    profile_id: str | None = None
    kind: OperationKind
    state: Literal["queued", "running", "done", "failed", "cancelled"] = "queued"
    steps: list[Step] = Field(default_factory=list)
    percent: float | None = None
    started: str | None = None
    finished: str | None = None
    error: str | None = None
    params: dict[str, Any] = Field(default_factory=dict)
    # basics bundle (contract.OperationExtras). All optional, so frames saved before these existed still parse.
    error_code: str | None = None            # machine code of a failure (the OpError code), None while it runs
    progress: dict[str, Any] | None = None   # MEASURED progress {kind, done, total, rate, label}; None = not measured
    cancellable: bool = False                # True only while the current step can honour Cancel safely
    log_id: str | None = None                # the log file that holds the detail (e.g. this run's SteamCMD log)


class ConsoleLine(BaseModel):
    seq: int
    at: str
    source: Literal["stdout", "rcon", "system"]
    level: Literal["info", "warn", "error", "debug"] = "info"
    text: str


class PlayerRow(BaseModel):
    steamid64: str
    name: str
    ping: int | None = None
    address: str | None = None
    connected_s: int | None = None
    health: float | None = None
    violation: float | None = None


class ScheduleRule(BaseModel):
    """When a schedule fires, in the schedule's own time zone.

    kind:
      daily          -> every day at time (HH:MM)
      weekly         -> every week on dow (0=Monday..6=Sunday) at time
      monthly_first_thursday -> the first Thursday of each month at time (Facepunch's forced-wipe day)
      every_hours    -> every N hours counted from midnight local time
    """
    kind: Literal["daily", "weekly", "monthly_first_thursday", "every_hours"] = "daily"
    time: str = Field(default="04:00", pattern=r"^([01]\d|2[0-3]):[0-5]\d$")
    dow: int | None = Field(default=None, ge=0, le=6)
    hours: int | None = Field(default=None, ge=1, le=168)

    @model_validator(mode="after")
    def _needs(self) -> "ScheduleRule":
        if self.kind == "weekly" and self.dow is None:
            raise ValueError("a weekly schedule needs a day of the week")
        if self.kind == "every_hours" and not self.hours:
            raise ValueError("an every-N-hours schedule needs hours")
        return self


DOW_NAMES = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
RULE_RE = re.compile(r"^\s*(?:(?P<daily>daily)\s+(?P<t1>\d{1,2}:\d{2})"
                     r"|(?P<weekly>weekly)\s+(?P<dow>[a-z]{3})[a-z]*\s+(?P<t2>\d{1,2}:\d{2})"
                     r"|(?P<monthly>monthly)\s+first-thursday\s+(?P<t3>\d{1,2}:\d{2})"
                     r"|(?P<every>every)\s+(?P<hours>\d{1,3})\s*h)\s*$", re.IGNORECASE)


def parse_rule(text: str) -> ScheduleRule:
    """'daily 04:00' | 'weekly thu 19:00' | 'monthly first-thursday 14:00' | 'every 6h' -> ScheduleRule."""
    m = RULE_RE.match(text or "")
    if not m:
        raise ValueError("rule must look like 'daily 04:00', 'weekly thu 04:00', "
                         "'monthly first-thursday 14:00' or 'every 6h'")
    def hhmm(t: str) -> str:
        h, mi = t.split(":")
        return f"{int(h):02d}:{mi}"
    if m.group("daily"):
        return ScheduleRule(kind="daily", time=hhmm(m.group("t1")))
    if m.group("weekly"):
        dow = m.group("dow").lower()
        if dow not in DOW_NAMES:
            raise ValueError(f"unknown day '{dow}' (use mon, tue, wed, thu, fri, sat, sun)")
        return ScheduleRule(kind="weekly", dow=DOW_NAMES.index(dow), time=hhmm(m.group("t2")))
    if m.group("monthly"):
        return ScheduleRule(kind="monthly_first_thursday", time=hhmm(m.group("t3")))
    return ScheduleRule(kind="every_hours", hours=int(m.group("hours")))


def format_rule(rule: ScheduleRule) -> str:
    if rule.kind == "daily":
        return f"daily {rule.time}"
    if rule.kind == "weekly":
        return f"weekly {DOW_NAMES[rule.dow or 0]} {rule.time}"
    if rule.kind == "monthly_first_thursday":
        return f"monthly first-thursday {rule.time}"
    return f"every {rule.hours}h"


class ScheduleIn(BaseModel):
    action: Literal["restart", "wipe_map", "wipe_full", "wipe_blueprints", "update", "backup"] = "restart"
    # Backup schedules only: how many of THIS schedule's backups to keep (manual / pre-wipe / pre-restore backups
    # are never pruned by a schedule). Other actions ignore it.
    keep_newest: int = 10
    enabled: bool = True
    tz: str = "UTC"
    rule: ScheduleRule = Field(default_factory=ScheduleRule)
    warnings: list[int] = Field(default_factory=lambda: [900, 300, 60])
    seed_rotation: bool = False
    missed_policy: Literal["skip", "run_once"] = "skip"
    label: str = ""

    @field_validator("rule", mode="before")
    @classmethod
    def _rule_text(cls, v: Any) -> Any:
        return parse_rule(v) if isinstance(v, str) else v

    @field_serializer("rule")
    def _rule_out(self, rule: ScheduleRule) -> str:
        return format_rule(rule)

    @field_validator("tz")
    @classmethod
    def _tz(cls, v: str) -> str:
        from zoneinfo import ZoneInfo
        try:
            ZoneInfo(v)
        except Exception as exc:  # noqa: BLE001 - any failure means "not a real IANA zone"
            raise ValueError(f"'{v}' is not a known time zone (use names like America/New_York)") from exc
        return v

    @field_validator("warnings")
    @classmethod
    def _warn(cls, v: list[int]) -> list[int]:
        return sorted({int(x) for x in v if 0 < int(x) <= 7200}, reverse=True)

    @field_validator("keep_newest", mode="before")
    @classmethod
    def _keep(cls, v: Any) -> int:
        from .backups import validate_keep_newest    # imported here: backups.py imports this module
        from .operations import OpError
        if v is None:
            return 10                                # schedules saved before the field existed
        try:
            return validate_keep_newest(v)
        except OpError as exc:
            raise ValueError(str(exc)) from None


class Schedule(ScheduleIn):
    id: str = Field(default_factory=new_id)
    profile_id: str
    next_utc: str | None = None
    next_local: str | None = None


class BackupInfo(BaseModel):
    id: str
    label: str
    created: str
    size: int
    sha256: str
    contents: list[str]


class PluginInfo(BaseModel):
    id: str
    filename: str
    title: str
    version: str | None = None
    source: str = "user"
    enabled: bool = True
    loaded: bool | None = None
    framework: str = "carbon"
