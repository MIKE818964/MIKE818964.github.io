"""The game-module interface: what the engine needs to know about ANY game to install and run its server.

The engine (supervisor, steamcmd, backups) never says "Rust" anywhere; it asks the GameModule. Rust is the first
module (games/rust.py). Arma or others later only need a new module, not a new engine.
"""
from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

from ..models import Profile


@dataclass(frozen=True)
class ConvarSpec:
    """One server option shown in plain English in the config editor."""
    name: str                      # the real console name, e.g. "decay.scale"
    label: str                     # what the UI shows, e.g. "Decay speed"
    help: str                      # one or two sentences a non-coder understands
    category: str                  # Server, Map, Players, Gameplay, Events, Decay, PvE, Performance
    kind: Literal["bool", "int", "float", "string"] = "string"
    default: str = ""
    live: bool = True              # True = can be changed while the server runs (sent over RCON right away)
    minimum: float | None = None
    maximum: float | None = None
    profile_field: str | None = None   # set when this option is stored as a first-class Profile field instead
    options: tuple[str, ...] = ()      # fixed choices (shown as a drop-down)
    # Plain-English words for each choice, same order as `options` (e.g. "0" -> "Nobody"). The value written to
    # server.cfg stays the option itself; the words are only what the drop-down shows.
    option_labels: tuple[str, ...] = ()
    # A switch whose real convar is a NUMBER (e.g. server.idlekickadmins: 0 = off, anything else = on).
    # (text written when on, text written when off). The UI still sees "true"/"false"; the server gets the numbers.
    bool_values: tuple[str, str] | None = None

    @property
    def server_type(self) -> str:
        """The convar's real type inside Rust (int for a number-backed switch), for checks against the catalog."""
        return "int" if self.bool_values else self.kind

    def ui_value(self, value: str) -> str:
        """The value as the UI control expects it (number-backed switches become "true"/"false")."""
        if self.kind == "bool" and self.bool_values:
            try:
                return "false" if float(value.strip()) == 0 else "true"
            except ValueError:
                return "true" if value.strip().lower() in ("true", "on", "yes") else "false"
        return value

    @property
    def ui_type(self) -> str:
        """What control the UI draws: toggle, number, select or text."""
        if self.options:
            return "select"
        return {"bool": "toggle", "int": "number", "float": "number"}.get(self.kind, "text")

    def describe(self, value: str | None = None) -> dict[str, Any]:
        shown = self.ui_value(self.default if value is None else value)
        default = self.ui_value(self.default) if self.default else ""     # "" = no fixed default
        out: dict[str, Any] = {"name": self.name, "label": self.label, "value": shown,
                               "default": default, "help": self.help, "live": self.live,
                               "category": self.category, "type": self.ui_type, "min": self.minimum,
                               "max": self.maximum}
        if self.options:
            out["options"] = list(self.options)
            if self.option_labels:
                out["option_labels"] = dict(zip(self.options, self.option_labels))
        return out

    def validate(self, value: Any) -> str:
        """Turn a UI value into the exact text Rust expects, or raise ValueError with a plain message."""
        text = str(value).strip()
        if self.options and text not in self.options:
            raise ValueError(f"{self.label}: choose one of {', '.join(self.options)}")
        if "\n" in text or "\r" in text or '"' in text:
            raise ValueError(f"{self.label}: line breaks and double quotes are not allowed")
        if self.kind == "bool":
            low = text.lower()
            on_text, off_text = self.bool_values or ("true", "false")
            if low in ("1", "true", "yes", "on"):
                return on_text
            if low in ("0", "false", "no", "off"):
                return off_text
            raise ValueError(f"{self.label}: expected on/off")
        if self.kind in ("int", "float"):
            try:
                num = float(text.replace(",", "."))
            except ValueError as exc:
                raise ValueError(f"{self.label}: expected a number") from exc
            if self.kind == "int" and num != int(num):
                raise ValueError(f"{self.label}: expected a whole number")
            if self.minimum is not None and num < self.minimum:
                raise ValueError(f"{self.label}: must be at least {self.minimum:g}")
            if self.maximum is not None and num > self.maximum:
                raise ValueError(f"{self.label}: must be at most {self.maximum:g}")
            return str(int(num)) if self.kind == "int" else f"{num:g}"
        return text


@dataclass
class LogEvent:
    """Something meaningful recognised in a server log line."""
    kind: Literal["startup_complete", "save_complete", "shutdown", "rcon_started", "plugin_loaded",
                  "plugin_unloaded", "framework_version", "map_generating", "bind_error"]
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class WipePlan:
    """An explicit list of files a wipe will remove - computed first, shown, then executed."""
    scope: str
    identity_dir: Path
    files: list[Path]
    keep: list[str]                                        # names inside the identity folder that stay
    keep_rules: list[str] = field(default_factory=list)   # the RULES that decide what stays, even when a file is not there yet (companion.id before first pairing)
    notes: list[str] = field(default_factory=list)         # plain-English reasons for the dialog

    def as_dict(self) -> dict[str, Any]:
        """What GET /profiles/{id}/wipe-plan returns (names only; folders end with "/")."""
        return {"scope": self.scope, "identity_dir": str(self.identity_dir), "keep_rules": list(self.keep_rules),
                "remove": [f.name + ("/" if f.is_dir() else "") for f in self.files],
                "keep": list(self.keep), "notes": list(self.notes)}


class GameModule(ABC):
    id: str = "game"
    title: str = "Game"
    app_id: int = 0
    exe_names: dict[str, str] = {}
    default_game_port: int = 28015

    def executable_path(self, install_root: Path, os_name: str) -> Path:
        return Path(install_root) / self.exe_names[os_name]

    def is_installed(self, install_root: Path, os_name: str) -> bool:
        return self.executable_path(install_root, os_name).is_file()

    def launch_prefix(self, install_root: Path, os_name: str) -> list[str]:
        """The program part of the command line. Test doubles override this to run a Python script instead."""
        return [str(self.executable_path(install_root, os_name))]

    @abstractmethod
    def build_argv(self, profile: Profile, os_name: str, logfile: Path, rcon_password: str) -> list[str]: ...

    @abstractmethod
    def launch_env(self, profile: Profile, os_name: str, base_env: dict[str, str]) -> dict[str, str]: ...

    @abstractmethod
    def parse_log_line(self, line: str) -> LogEvent | None: ...

    @abstractmethod
    def convar_catalog(self) -> list[ConvarSpec]: ...

    @abstractmethod
    def server_cfg_values(self, profile: Profile) -> dict[str, str]: ...

    @abstractmethod
    def identity_dir(self, profile: Profile) -> Path: ...

    @abstractmethod
    def wipe_plan(self, profile: Profile, scope: str) -> WipePlan: ...

    # Optional: a picture of the map. Games without one keep these defaults (the API then answers 404).
    map_render_command: str | None = None

    def map_render_path(self, profile: Profile) -> Path | None:
        return None

    def parse_map_render_reply(self, text: str) -> str | None:
        return None


def compile_patterns(patterns: dict[str, str]) -> dict[str, re.Pattern[str]]:
    return {k: re.compile(v) for k, v in patterns.items()}
