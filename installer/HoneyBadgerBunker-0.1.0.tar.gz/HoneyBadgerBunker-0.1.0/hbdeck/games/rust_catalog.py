"""The plain-English Rust server option catalog shown in the Deck's config editor.

Help texts are written in our own words. Every name was checked against the real server: the decompiled ConVar
classes of RustDedicated 2635 (ConVar.Server, Decay, Env, Spawn, Craft, FPS, RelationshipManager) and the convar
dump printed in eval/servers/epic/output.log. Console names are lower-case (server.pvebulletdamagemultiplier).
live=False means the server must restart for the change to apply.

2026-10-27 audit: every row below was re-checked against the decompiled build 2635 code. The audited truth ships
beside this file in rust_convars_audited.json (730 rows) and tests/test_rust_game.py::test_catalog_matches_audited_rows
keeps the two in step. Sixteen rows were wrong and are corrected here: for example server.idlekickadmins is an on/off
switch (not minutes), the weather chances are relative weights (not 0-1 probabilities) with no fixed default, and
halloween.enabled is gone because the server never reads it.
"""
from __future__ import annotations

from .base import ConvarSpec

C = ConvarSpec
CATALOG: list[ConvarSpec] = [
    # Server
    C("server.hostname", "Server name", "The name players see in the server browser.", "Server", "string",
      "HoneyBadger Server", profile_field="hostname"),
    C("server.description", "Description", "A few lines about your server shown on its browser page. Use \\n for a new line.",
      "Server", "string", "", profile_field="description"),
    C("server.url", "Website link", "A web address shown on your server's browser page. Leave empty for none.",
      "Server", "string", "", profile_field="url"),
    C("server.headerimage", "Banner image link", "Link to a 512x256 image shown at the top of your server's page.",
      "Server", "string", "", profile_field="header_image"),
    C("server.logoimage", "Logo image link", "Link to a small square logo shown next to your server in the browser.",
      "Server", "string", ""),
    C("server.tags", "Browser tags", "Comma-separated tags that help players filter for your server (for example weekly,vanilla).",
      "Server", "string", ""),
    C("server.motd", "Message of the day", "A message shown to players when they join.", "Server", "string", ""),
    C("chat.globalchat", "Global chat",
      "When off, global chat messages are thrown away. The game mode resets this at startup, so changes only last "
      "until restart.", "Server", "bool", "true"),
    # Map
    C("server.level", "Map type", "Procedural Map builds a random island from the seed; Barren is an empty test map.",
      "Map", "string", "Procedural Map", live=False, options=("Procedural Map", "Barren")),
    C("server.seed", "Map seed", "The number that decides the island's shape. Same seed + size = same map.",
      "Map", "int", "1", live=False, minimum=0, maximum=2147483647),
    C("server.worldsize", "Map size", "Island width in metres. 3000 suits a small group; 4500 is the official size.",
      "Map", "int", "3000", live=False, minimum=1000, maximum=6000),
    C("server.levelurl", "Custom map link", "Direct download link to a custom .map file. When set, seed and size are ignored.",
      "Map", "string", "", live=False),
    # Players
    C("server.maxplayers", "Player slots", "How many players can be on the server at once.", "Players", "int", "8",
      minimum=1, maximum=1000, profile_field="max_players"),
    C("relationshipmanager.maxteamsize", "Max team size",
      "Largest team allowed. 0 turns teams off. Default 8. A game mode without teams forces 0 at startup.", "Players",
      "int", "8", minimum=0, maximum=128),
    C("server.idlekick", "Idle kick (minutes)",
      "Kick players who do nothing for this many minutes. 0 = never. With the default idle kick mode this only "
      "happens when the server is full.", "Players", "int", "30", minimum=0, maximum=1440),
    # A picker, not a bare number: the three values and their meanings come from the audited help sentence.
    C("server.idlekickmode", "Idle kick applies to", "0 = nobody, 1 = only when the server is full, 2 = always.",
      "Players", "int", "1", minimum=0, maximum=2, options=("0", "1", "2"),
      option_labels=("Nobody", "Only when the server is full", "Always")),
    # A number inside Rust, but it only means yes/no: 0 = admins exempt, anything else = admins kicked too.
    C("server.idlekickadmins", "Idle kick includes admins",
      "0 = admins are never idle-kicked. Any other number = admins are idle-kicked like normal players (using the "
      "normal idle kick time).", "Players", "bool", "0", bool_values=("1", "0")),
    C("server.max_sleeping_bags", "Sleeping bags per player",
      "How many sleeping bags or beds one player may own. A game mode can overwrite this at startup.",
      "Players", "int", "15", minimum=0, maximum=1000),
    C("server.respawnresetrange", "Bag reset range (m)", "Sleeping bags within this distance of each other share a respawn timer.",
      "Players", "float", "50", minimum=0, maximum=1000),
    C("server.woundingenabled", "Wounded state", "When on, a fatal hit first knocks players down so a friend can help them up.",
      "Players", "bool", "true"),
    C("server.crawlingenabled", "Crawling when wounded",
      "When on, downed players can crawl. Overwritten at startup if a game mode is set.", "Players", "bool", "true"),
    C("server.maximummapmarkers", "Map markers per player", "How many markers each player can place on the map.",
      "Players", "int", "5", minimum=0, maximum=100),
    # Gameplay
    C("server.radiation", "Radiation", "When on, monuments have radiation that needs protective clothing.",
      "Gameplay", "bool", "true"),
    C("server.stability", "Building stability", "When on, badly supported buildings collapse. Off = build anywhere.",
      "Gameplay", "bool", "true"),
    C("craft.instant", "Instant crafting",
      "When on, crafting by admins finishes in about 1 second. Normal players are not affected.", "Gameplay", "bool",
      "false"),
    C("server.itemdespawn", "Dropped item lifetime (s)",
      "Base seconds before dropped items disappear. Valuable items last several times longer (up to 24x).",
      "Gameplay", "float", "300", minimum=10, maximum=86400),
    C("server.corpsedespawn", "Body lifetime (s)", "Seconds before a dead player's body disappears.", "Gameplay",
      "float", "300", minimum=10, maximum=86400),
    C("server.bulletdamage", "Bullet damage", "Multiplier for all gun damage. 1 = normal, 2 = double.", "Gameplay",
      "float", "1", minimum=0, maximum=10),
    C("server.meleedamage", "Melee damage", "Multiplier for melee weapon damage. 1 = normal.", "Gameplay", "float",
      "1", minimum=0, maximum=10),
    C("server.arrowdamage", "Arrow damage", "Multiplier for bow and crossbow damage. 1 = normal.", "Gameplay",
      "float", "1", minimum=0, maximum=10),
    C("server.bleedingdamage", "Bleeding damage", "Multiplier for damage from bleeding. 1 = normal.", "Gameplay",
      "float", "1", minimum=0, maximum=10),
    C("env.progresstime", "Day and night cycle", "When on, time of day moves forward. Off = time stands still.",
      "Gameplay", "bool", "true"),
    # Env.daylength (decompiled 2635). Label and help are the audited row's own words; the audit has no fixed
    # default for it (""), so "Use default" takes the line out and Rust's own value applies.
    C("env.daylength", "Day length (min)", "Real minutes one in-game day lasts on the server.", "Gameplay", "float",
      "", minimum=1, maximum=240),
    # Events
    C("server.events", "Random events", "Master switch for automatic events like the patrol helicopter and airdrops.",
      "Events", "bool", "true"),
    C("cargoship.event_enabled", "Cargo ship", "When on, the cargo ship event sails around the island.", "Events",
      "bool", "true"),
    C("bradley.enabled", "Bradley tank", "When on, the Bradley APC patrols Launch Site.", "Events", "bool", "true"),
    # halloween.enabled was removed: the 2635 server never reads it (it does nothing).
    C("xmas.enabled", "Christmas event",
      "Turns on the Christmas event. New spawns get 3 snowballs and xmas.refill can hand out gifts. Takes effect "
      "right away.", "Events", "bool", "false"),
    # The three weather chances are relative WEIGHTS shared against each other, and the map's climate sets their
    # starting values, so there is no fixed default to show (default "").
    C("weather.rain_chance", "Rain chance",
      "Weight for rain when the weather changes. It is shared out against the other weather chances, so 1 is not "
      "always. The starting value comes from the map's climate.", "Events", "float", "", minimum=0, maximum=1),
    C("weather.fog_chance", "Fog chance",
      "Weight for fog when the weather changes. It is shared out against the other weather chances (0 to 1 each). "
      "The starting value comes from the map's climate.", "Events", "float", "", minimum=0, maximum=1),
    C("weather.storm_chance", "Storm chance",
      "Weight for storms when the weather changes. It is shared out against the other weather chances (0 to 1 "
      "each). The starting value comes from the map's climate.", "Events", "float", "", minimum=0, maximum=1),
    # Decay
    C("decay.scale", "Decay speed", "How fast unprotected buildings rot. 1 = normal, 0 = no decay, 2 = twice as fast.",
      "Decay", "float", "1", minimum=0, maximum=10),
    C("decay.upkeep", "Upkeep", "When on, bases need resources in the tool cupboard to avoid decaying.", "Decay",
      "bool", "true"),
    C("decay.high_wall_upkeep", "High wall upkeep", "Upkeep cost multiplier for external walls and gates.", "Decay",
      "float", "0.2", minimum=0, maximum=10),
    C("decay.build_twig_cost_multiplier", "Twig build cost", "Cost multiplier for placing twig building parts.",
      "Decay", "float", "1", minimum=0, maximum=10),
    # PvE
    C("server.pve", "PvE mode",
      "When on, players cannot hurt other players or their building blocks. The damage is reflected back onto the "
      "attacker. Animals and NPCs can still hurt players.", "PvE", "bool", "false", profile_field="pve"),
    C("server.pvebulletdamagemultiplier", "Bullet damage vs NPCs",
      "Bullet damage multiplier when a player shoots a human NPC such as a scientist. It does not affect animals. "
      "1 means normal.", "PvE", "float", "1", minimum=0, maximum=10),
    C("ai.npc_enable", "NPCs", "When on, scientists and other NPCs spawn at monuments.", "PvE", "bool", "true"),
    C("ai.think", "NPC brains", "When off, animals and NPCs stand still (handy for building tests).", "PvE", "bool",
      "true"),
    C("ai.ignoreplayers", "NPCs ignore players", "When on, NPCs and animals will not attack players.", "PvE", "bool",
      "false"),
    # Performance
    C("server.tickrate", "Server tick rate",
      "How many times per second the server updates. 30 is the standard. (The Bunker uses 30; the game's own "
      "built-in default is 10.)",
      "Performance", "int", "30", live=False, minimum=10, maximum=100, profile_field="tickrate"),
    C("server.saveinterval", "Autosave every (s)", "Seconds between automatic world saves.", "Performance", "int",
      "600", minimum=60, maximum=7200, profile_field="save_interval"),
    C("fps.limit", "Server FPS limit", "Caps the server's frame (tick) rate to save CPU. Default 240.",
      "Performance", "int", "240", minimum=10, maximum=1000),
    C("spawn.max_rate", "Resource respawn speed", "Upper limit for how fast trees, ore and animals come back.",
      "Performance", "float", "1", minimum=0, maximum=10),
    C("spawn.min_rate", "Minimum respawn speed", "Lower limit for how fast trees, ore and animals come back.",
      "Performance", "float", "0.5", minimum=0, maximum=10),
]

CATALOG_BY_NAME: dict[str, ConvarSpec] = {c.name: c for c in CATALOG}
