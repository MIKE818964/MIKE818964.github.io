"""Game module registry. v1 ships Rust; tests register a fake module under another id."""
from __future__ import annotations

from .base import ConvarSpec, GameModule, LogEvent, WipePlan
from .rust import RustGame

REGISTRY: dict[str, GameModule] = {"rust": RustGame()}


def get_game(game_id: str) -> GameModule:
    try:
        return REGISTRY[game_id]
    except KeyError as exc:
        raise ValueError(f"unknown game '{game_id}'") from exc


__all__ = ["ConvarSpec", "GameModule", "LogEvent", "WipePlan", "RustGame", "REGISTRY", "get_game"]
