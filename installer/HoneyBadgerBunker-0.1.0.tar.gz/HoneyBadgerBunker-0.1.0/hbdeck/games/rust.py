"""Rust (Facepunch) game module: everything the engine needs to know about RustDedicated.

All facts here were checked against the real server on this PC (2026-10-27), not remembered:
- Steam app id 258550; RustDedicated.exe (Windows) / RustDedicated (Linux)              docs/INSTALL_RECIPE.md sec 1
- "-noconsole" turns off Rust's own console window/input thread (decompiled ServerConsole.consoleEnabled checks
  CommandLine.HasSwitch("-noconsole")); with it the server opened no window at all under CREATE_NO_WINDOW.
- With -logfile <file>, almost everything goes into that file; stdout only carries ~55 early Unity lines.
- WebRCON only starts when rcon.password is on the COMMAND LINE: a password only in server.cfg left RCON off
  (probe run 2026-10-27, no "WebSocket RCON Started" line). Rust masks it as ****** in its own log.
- server/<identity>/cfg/server.cfg is loaded after the command line and OVERRIDES it, so every value we manage is
  written to both places.
- Markers: "Server startup complete", "Saving complete" (also printed after server.save), "[Raknet] Server
  Shutting Down (quit)". On Windows the process exit code after a clean `quit` is -1 (4294967295), so exit codes
  can NOT tell a clean stop from a crash - the supervisor tracks "we asked it to stop" instead.
- serverinfo returns PascalCase JSON; Memory and MemoryUsageSystem are megabytes (760 / 2859 seen live).
"""
from __future__ import annotations

import os
import re
from pathlib import Path

from ..models import Profile
from .base import ConvarSpec, GameModule, LogEvent, WipePlan

PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("startup_complete", re.compile(r"^Server startup complete\b")),
    ("save_complete", re.compile(r"^Saving complete\b")),
    ("shutdown", re.compile(r"^\[Raknet\] Server Shutting Down")),
    ("rcon_started", re.compile(r"^WebSocket RCON Started on :(?P<port>\d+)")),
    ("plugin_loaded", re.compile(
        r"^Loaded plugin (?P<title>.+?) v(?P<version>[0-9][0-9.]*) by (?P<author>.+?)(?: \[(?P<ms>\d+)ms\])?$")),
    ("plugin_unloaded", re.compile(r"^Unloaded plugin (?P<title>.+?) v(?P<version>[0-9][0-9.]*) by (?P<author>.+)$")),
    ("framework_version", re.compile(r"^Carbon (?P<version>\d+\.\d+\.\d+)(?:\.\d+)? \[")),
    ("framework_version", re.compile(r"Carbon .*up to date.*?(?P<version>\d+\.\d+\.\d+)")),
    ("framework_version", re.compile(r"^Loading Oxide Core v(?P<version>\d+\.\d+\.\d+)")),
    ("map_generating", re.compile(r"^Generating procedural map of size (?P<size>\d+) with seed (?P<seed>\d+)")),
    # Heuristic (not yet seen live): the usual socket error texts when a port is taken.
    ("bind_error", re.compile(r"(?i)address already in use|only one usage of each socket address")),
]

# Wipe file rules (INSTALL_RECIPE sec 6 + the real identity folder listing in eval/servers/epic/server/hbeval):
#   proceduralmap.1000.1.289.map / .sav / .navmesh / _occlusion_3.dat, player.blueprints.18.db(-wal/-shm)
MAP_FILE_RE = re.compile(r"^.+\.(map|sav|sav\.\d+|navmesh)$|^.+_occlusion_\d+\.dat$", re.IGNORECASE)
BLUEPRINT_FILE_RE = re.compile(r"^player\.blueprints\.\d+\.db(-wal|-shm)?$", re.IGNORECASE)
# Rust+ (companion app) identity. Facepunch's companion-server wiki: companion.id is the server's Rust+ identity;
# deleting it makes a new one that cannot be recovered and every player has to pair their phone again.
# player.tokens.db holds the players' Rust+ pairing tokens. A FULL wipe therefore keeps both (plus SQLite's
# -wal/-shm side files, which belong to the same database).
RUST_PLUS_KEEP_RE = re.compile(r"^(companion\.id|player\.tokens\.db(-wal|-shm)?)$", re.IGNORECASE)
RUST_PLUS_NOTE = ("Rust+ pairing is kept: companion.id (this server's Rust+ identity) and player.tokens.db "
                  "(players' paired phones) are not deleted, so nobody has to pair the Rust+ app again.")
# Rendered island picture: `world.rendermap` writes <install>/map_<size>_<seed>.png and answers with this line
# (captured live 2026-10-27: "Saved map render to: C:\...\map_1000_1.png", about 5 s on a 1000 m map).
RENDERMAP_REPLY_RE = re.compile(r"Saved map render to:\s*(?P<path>.+?\.png)\s*$", re.IGNORECASE | re.MULTILINE)


def parse_rendermap_reply(text: str) -> str | None:
    """The file path from a `world.rendermap` reply, or None when the reply does not name one."""
    m = RENDERMAP_REPLY_RE.search(text or "")
    return m.group("path").strip().strip('"') if m else None


def _b(v: bool) -> str:
    return "true" if v else "false"


class RustGame(GameModule):
    id = "rust"
    title = "Rust"
    app_id = 258550
    exe_names = {"windows": "RustDedicated.exe", "linux": "RustDedicated"}
    default_game_port = 28015

    # ----- launch ------------------------------------------------------------------------------------------
    def map_args(self, profile: Profile) -> list[str]:
        m = profile.map
        if m.kind == "custom" and m.custom_url:
            return ["+server.levelurl", m.custom_url]
        level = "Barren" if m.kind == "barren" else "Procedural Map"
        return ["+server.level", level, "+server.seed", str(m.seed), "+server.worldsize", str(m.size)]

    def build_argv(self, profile: Profile, os_name: str, logfile: Path, rcon_password: str) -> list[str]:
        """The exact command line, one list item per argument (never joined into a shell string)."""
        p = profile.ports
        argv = self.launch_prefix(Path(profile.install_root), os_name) + [
            "-batchmode", "-nographics", "-noconsole",
            "-logfile", str(logfile),
            "+server.identity", profile.identity,
            "+server.ip", profile.bind_ip,
            "+server.port", str(p.game_udp),
            "+server.queryport", str(p.query_udp),
            "+rcon.port", str(p.rcon_tcp),
            "+rcon.password", rcon_password,
            "+rcon.web", "1",
            "+app.port", str(p.app_tcp) if p.app_tcp else "1-",
            "+server.hostname", profile.hostname,
            "+server.maxplayers", str(profile.max_players),
            "+server.tickrate", str(profile.tickrate),
            "+server.saveinterval", str(profile.save_interval),
            *self.map_args(profile),
        ]
        argv += list(profile.extra_args)
        return argv

    def launch_env(self, profile: Profile, os_name: str, base_env: dict[str, str]) -> dict[str, str]:
        """Environment variables for the server process.

        Linux + Carbon reproduces carbon/tools/environment.sh EXACTLY (read from the real Linux release):
            TERM=xterm, DOORSTOP_ENABLED=1, DOORSTOP_TARGET_ASSEMBLY=<root>/carbon/managed/Carbon.Preloader.dll,
            LD_PRELOAD=<root>/libdoorstop.so, LD_LIBRARY_PATH=<root>:<root>/RustDedicated_Data/Plugins/x86_64
        (environment.sh REPLACES LD_LIBRARY_PATH, it does not append.) Without these, Carbon silently does not load.
        Linux vanilla/Oxide follows Facepunch's runds.sh: LD_LIBRARY_PATH = the two RustDedicated_Data/Plugins dirs.
        Windows needs nothing: Carbon loads through winhttp.dll next to RustDedicated.exe.
        """
        env = dict(base_env)
        if os_name != "linux":
            return env
        root = os.path.realpath(profile.install_root).replace("\\", "/")
        env["TERM"] = "xterm"
        if profile.framework == "carbon" and Path(profile.install_root, "libdoorstop.so").exists():
            env["DOORSTOP_ENABLED"] = "1"
            env["DOORSTOP_TARGET_ASSEMBLY"] = f"{root}/carbon/managed/Carbon.Preloader.dll"
            env["LD_PRELOAD"] = f"{root}/libdoorstop.so"
            env["LD_LIBRARY_PATH"] = f"{root}:{root}/RustDedicated_Data/Plugins/x86_64"
        else:
            env["LD_LIBRARY_PATH"] = f"{root}/RustDedicated_Data/Plugins:{root}/RustDedicated_Data/Plugins/x86_64"
            env.pop("LD_PRELOAD", None)
        return env

    # ----- logs --------------------------------------------------------------------------------------------
    def parse_log_line(self, line: str) -> LogEvent | None:
        text = line.strip()
        for kind, rx in PATTERNS:
            m = rx.search(text)
            if m:
                data = {k: v for k, v in m.groupdict().items() if v is not None}
                return LogEvent(kind=kind, data=data)  # type: ignore[arg-type]
        return None

    # ----- config ------------------------------------------------------------------------------------------
    def server_cfg_values(self, profile: Profile) -> dict[str, str | None]:  # type: ignore[override]
        """Every setting the Deck owns in server.cfg. None = remove that line (e.g. Rust+ switched off)."""
        p = profile.ports
        values: dict[str, str | None] = {
            "server.hostname": profile.hostname,
            "server.description": profile.description,
            "server.url": profile.url,
            "server.headerimage": profile.header_image,
            "server.maxplayers": str(profile.max_players),
            "server.tickrate": str(profile.tickrate),
            "server.saveinterval": str(profile.save_interval),
            "server.ip": profile.bind_ip,
            "server.port": str(p.game_udp),
            "server.queryport": str(p.query_udp),
            "rcon.port": str(p.rcon_tcp),
            "rcon.web": "1",
            "app.port": str(p.app_tcp) if p.app_tcp else None,
            "server.gamemode": profile.gamemode,
            "server.pve": _b(profile.pve),
        }
        m = profile.map
        if m.kind == "custom":
            values.update({"server.levelurl": m.custom_url, "server.level": None, "server.seed": None,
                           "server.worldsize": None})
        else:
            values.update({"server.levelurl": None,
                           "server.level": "Barren" if m.kind == "barren" else "Procedural Map",
                           "server.seed": str(m.seed), "server.worldsize": str(m.size)})
        for k, v in profile.managed_convars.items():
            values.setdefault(k, v)
        return values

    def identity_dir(self, profile: Profile) -> Path:
        return Path(profile.install_root) / "server" / profile.identity

    # ----- wipes -------------------------------------------------------------------------------------------
    def wipe_plan(self, profile: Profile, scope: str) -> WipePlan:
        """List exactly which files a wipe removes. Raises ValueError if anything looks unsafe."""
        root = Path(os.path.realpath(profile.install_root))
        ident = self.identity_dir(profile)
        check_safe_identity_dir(root, ident)
        files: list[Path] = []
        keep: list[str] = []          # names that stay, shown in the wipe dialog ("cfg/" = a folder)
        notes: list[str] = []
        for entry in sorted(ident.iterdir()):
            if entry.is_symlink() or _is_junction(entry):
                raise ValueError(f"refusing to wipe: {entry.name} is a link to somewhere else")
            name = entry.name
            if scope == "map":
                if entry.is_file() and MAP_FILE_RE.match(name):
                    files.append(entry)
            elif scope == "blueprints":
                if entry.is_file() and BLUEPRINT_FILE_RE.match(name):
                    files.append(entry)
            elif scope == "full":
                if name.lower() != "cfg" and not RUST_PLUS_KEEP_RE.match(name):
                    files.append(entry)
            else:
                raise ValueError(f"unknown wipe scope '{scope}'")
        removed = set(files)
        keep = [e.name + ("/" if e.is_dir() else "") for e in sorted(ident.iterdir()) if e not in removed]
        if any(RUST_PLUS_KEEP_RE.match(k) for k in keep):
            notes.append(RUST_PLUS_NOTE)
        if "cfg/" in keep:
            notes.append("Your settings are kept: the cfg/ folder (server.cfg, users.cfg) is never wiped.")
        # Rules first, files second: the dialog must say companion.id is safe even before Rust+ ever created it.
        if scope == "full":
            keep_rules = ["cfg/", "companion.id", "player.tokens.db", "player.tokens.db-wal", "player.tokens.db-shm"]
            if not any(RUST_PLUS_KEEP_RE.match(k) for k in keep):
                notes.append("No Rust+ pairing files exist yet; when they appear they are kept by the same rule.")
        elif scope == "map":
            keep_rules = ["everything except the map files (proceduralmap.*.map/.sav/.navmesh/_occlusion)"]
        else:
            keep_rules = ["everything except player.blueprints.*.db"]
        return WipePlan(scope=scope, identity_dir=ident, files=files, keep=keep, keep_rules=keep_rules, notes=notes)

    map_render_command = "world.rendermap"

    def parse_map_render_reply(self, text: str) -> str | None:
        return parse_rendermap_reply(text)

    def map_render_path(self, profile: Profile) -> Path | None:
        """Where `world.rendermap` puts the island picture for this map, or None when the name is not known
        in advance (custom maps: then the path is read from the command's reply)."""
        m = profile.map
        if m.kind == "custom":
            return None
        return Path(profile.install_root) / f"map_{m.size}_{m.seed}.png"

    # ----- the plain-English option catalog ----------------------------------------------------------------
    def convar_catalog(self) -> list[ConvarSpec]:
        return CATALOG


def _is_junction(p: Path) -> bool:
    try:
        return p.is_junction()            # Python 3.12+: Windows directory junctions
    except AttributeError:
        return False


def check_safe_identity_dir(root: Path, ident: Path) -> None:
    """The identity folder must be a real folder, exactly <install_root>/server/<identity>, never a link."""
    if not ident.name or ident.name in (".", ".."):
        raise ValueError("refusing to wipe: empty identity")
    server_dir = Path(root) / "server"
    if not ident.exists():
        raise ValueError(f"refusing to wipe: {ident} does not exist")
    for p in (server_dir, ident):
        if p.is_symlink() or _is_junction(p):
            raise ValueError(f"refusing to wipe: {p} is a link")
    real = Path(os.path.realpath(ident))
    if real.parent != Path(os.path.realpath(server_dir)):
        raise ValueError(f"refusing to wipe: {ident} is not directly inside {server_dir}")
    if real == Path(os.path.realpath(root)) or len(real.parts) < 3:
        raise ValueError("refusing to wipe: path is too close to a drive root")


from .rust_catalog import CATALOG, CATALOG_BY_NAME  # noqa: E402  (catalog lives in its own file for readability)


