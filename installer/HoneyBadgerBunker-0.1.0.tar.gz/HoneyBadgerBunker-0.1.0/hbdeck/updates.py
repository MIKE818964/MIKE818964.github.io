"""The signed update channel: app updates, the plugin catalog, pinned frameworks and news.

How trust works (plain English):
1. honeybadger.software/installer/manifest.json is an "envelope": {envelope_version: 1, payload_encoding: "base64",
   payload: <base64 bytes>, signatures: [{key_id, algorithm: "Ed25519", signature}]}.
2. We decode the payload BYTES and check the Ed25519 signature over exactly those bytes with a public key baked into
   the app (hbdeck/trust/public_key.txt, one "<key_id> <base64 key>" per line). We never re-serialise JSON before
   checking (that is how signature checks go wrong). The signer is tools/publish_manifest.py.
3. Only a correctly signed payload is parsed and validated: schema, channel, not expired, and its `sequence` is
   not LOWER than the last one we accepted (an attacker replaying an old manifest is refused).
4. Downloads named by the manifest must match its exact size and sha256 before they are used. An artifact without
   a sha256 is never downloaded.
5. If the website is down or the manifest is bad, nothing breaks: installed servers keep running, the catalog is
   shown as "stale" from the last good copy, and new downloads are refused.
"""
from __future__ import annotations

import asyncio
import base64
import binascii
import datetime as dt
import hashlib
import json
import re
import urllib.request
from pathlib import Path
from typing import TYPE_CHECKING, Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from . import __version__
from .archive import USER_AGENT, download
from .models import iso, utcnow

if TYPE_CHECKING:
    from .profiles import Store

MANIFEST_URL = "https://honeybadger.software/installer/manifest.json"
TRUST_FILE = Path(__file__).parent / "trust" / "public_key.txt"
MAX_MANIFEST_BYTES = 1 << 20
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


class ManifestError(ValueError):
    """The manifest is not trustworthy or not valid. The message says why in plain English."""


def load_trusted_keys(path: Path = TRUST_FILE) -> dict[str, Ed25519PublicKey]:
    keys: dict[str, Ed25519PublicKey] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key_id, b64 = line.split()
        keys[key_id] = Ed25519PublicKey.from_public_bytes(base64.b64decode(b64, validate=True))
    return keys


def verify_envelope(raw: bytes, keys: dict[str, Ed25519PublicKey]) -> tuple[bytes, dict[str, Any], str]:
    """Check the signature. Returns (payload bytes, payload dict, key id) or raises ManifestError."""
    if len(raw) > MAX_MANIFEST_BYTES:
        raise ManifestError("manifest is too large")
    try:
        env = json.loads(raw)
    except ValueError as exc:
        raise ManifestError("manifest is not valid JSON") from exc
    if not isinstance(env, dict) or env.get("envelope_version") != 1:
        raise ManifestError("unsupported manifest envelope version")
    if env.get("payload_encoding", "base64") != "base64":
        raise ManifestError("unsupported payload encoding")
    try:
        payload_bytes = base64.b64decode(env.get("payload", ""), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ManifestError("payload is not valid base64") from exc
    sigs = env.get("signatures")
    if not isinstance(sigs, list) or not sigs:
        raise ManifestError("manifest is not signed")
    for sig in sigs:
        if not isinstance(sig, dict) or sig.get("algorithm") != "Ed25519":
            continue
        key = keys.get(str(sig.get("key_id")))
        if key is None:
            continue                                 # a key we do not trust: ignore, never "learn" it
        try:
            key.verify(base64.b64decode(sig.get("signature", ""), validate=True), payload_bytes)
        except (InvalidSignature, binascii.Error, ValueError):
            raise ManifestError("signature does not match: the manifest was changed or signed by someone else")
        try:
            payload = json.loads(payload_bytes)
        except ValueError as exc:
            raise ManifestError("signed payload is not valid JSON") from exc
        if not isinstance(payload, dict):
            raise ManifestError("signed payload is not an object")
        return payload_bytes, payload, str(sig["key_id"])
    raise ManifestError("no signature from a trusted key")


def _ts(value: Any, field: str) -> dt.datetime:
    try:
        return dt.datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(dt.timezone.utc)
    except ValueError as exc:
        raise ManifestError(f"{field} is not a valid time") from exc


def version_tuple(v: str) -> tuple[int, ...]:
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4]) or (0,)


# ----- app update hand-off to the Windows launcher -------------------------------------------------------------
# The engine cannot replace its own code while it runs. So an app update is: download + verify (here), then a
# small JSON note, <data>/updates/pending.json, that packaging/windows/hb_launch.pyw reads on the NEXT start:
# it checks the sha256 again, unpacks into <app>/versions/<version>/ and points <app>/current.txt at it.
# The launcher sets this environment variable for the engine it starts, so the engine knows that hand-off exists.
LAUNCHER_ENV = "HB_LAUNCHER_ACTIVATES"


def launcher_can_activate() -> bool:
    """True when this engine was started by the Windows launcher, which applies a pending update on next start."""
    import os
    return os.environ.get(LAUNCHER_ENV) == "1"


def write_pending_update(data_dir: Path, version: str, archive: Path, sha256: str) -> Path:
    """Write <data>/updates/pending.json {version, archive, sha256, written_at} atomically. Returns its path."""
    from .profiles import atomic_write
    path = Path(data_dir) / "updates" / "pending.json"
    note = {"version": str(version), "archive": str(Path(archive).resolve()), "sha256": sha256.lower(),
            "written_at": iso(utcnow())}
    atomic_write(path, json.dumps(note, indent=2) + "\n")
    return path


def validate_payload(p: dict[str, Any], *, now: dt.datetime, channel: str = "stable",
                     last_sequence: int | None = None, last_hash: str | None = None,
                     payload_hash: str | None = None, allow_expired: bool = False) -> list[str]:
    """Check the signed payload's content. Returns warnings; raises ManifestError for hard failures."""
    warnings: list[str] = []
    if p.get("schema_version") != 1:
        raise ManifestError("unsupported manifest schema version")
    seq = p.get("sequence")
    if not isinstance(seq, int) or seq < 1:
        raise ManifestError("sequence must be a positive whole number")
    if p.get("channel") != channel:
        raise ManifestError(f"manifest is for channel '{p.get('channel')}', not '{channel}'")
    issued, expires = _ts(p.get("issued_at"), "issued_at"), _ts(p.get("expires_at"), "expires_at")
    if expires <= issued:
        raise ManifestError("expires_at is before issued_at")
    if issued > now + dt.timedelta(hours=24):
        raise ManifestError("manifest is issued in the future: check this computer's clock")
    if expires < now:
        if not allow_expired:
            raise ManifestError("manifest has expired")
        warnings.append("manifest has expired")
    if last_sequence is not None:
        if seq < last_sequence:
            raise ManifestError(f"sequence {seq} is older than the last accepted {last_sequence} (replay refused)")
        if seq == last_sequence and last_hash and payload_hash and payload_hash != last_hash:
            raise ManifestError("a different manifest reuses an already accepted sequence number")
    ids: set[str] = set()
    for a in p.get("artifacts", []) or []:
        if not isinstance(a, dict) or not a.get("id"):
            raise ManifestError("artifact without an id")
        if a["id"] in ids:
            raise ManifestError(f"duplicate artifact id {a['id']}")
        ids.add(a["id"])
        if not str(a.get("url", "")).startswith("https://"):
            raise ManifestError(f"artifact {a['id']} must use https")
        sha = str(a.get("sha256", ""))
        if sha and not SHA256_RE.match(sha):
            raise ManifestError(f"artifact {a['id']} has a malformed sha256")
        if not sha:
            warnings.append(f"artifact {a['id']} has no sha256 and cannot be downloaded")
        if not isinstance(a.get("size", 0), int) or a.get("size", 0) < 0:
            raise ManifestError(f"artifact {a['id']} has a bad size")
    for pl in p.get("plugins", []) or []:
        if pl.get("artifact") and pl["artifact"] not in ids:
            raise ManifestError(f"plugin {pl.get('id')} names unknown artifact {pl['artifact']}")
        fn = str(pl.get("filename", ""))
        if not re.fullmatch(r"[A-Za-z0-9_]+\.cs", fn):
            raise ManifestError(f"plugin {pl.get('id')} has an unsafe filename")
    for n in p.get("news", []) or []:
        if "<" in str(n.get("text", "")) or "<" in str(n.get("title", "")):
            raise ManifestError("news must be plain text")
    mcv = p.get("min_client_version")
    if mcv and version_tuple(__version__) < version_tuple(str(mcv)):
        warnings.append(f"this app ({__version__}) is older than the manifest's minimum ({mcv}); please update")
    return warnings


class UpdateService:
    """Fetches, verifies and caches the manifest; serves catalog/app-update/news answers to the API."""

    def __init__(self, store: "Store", cache_dir: Path, url: str = MANIFEST_URL, channel: str = "stable",
                 keys: dict[str, Ed25519PublicKey] | None = None) -> None:
        self.store = store
        self.cache_dir = Path(cache_dir)
        self.url = url
        self.channel = channel
        self.keys = keys if keys is not None else load_trusted_keys()
        self.payload: dict[str, Any] | None = None
        self.fetched_at: str | None = None
        self.stale = True
        self.last_error: str | None = None
        self.warnings: list[str] = []
        self._load_cache()

    @property
    def cache_file(self) -> Path:
        return self.cache_dir / "manifest.json"

    def _load_cache(self) -> None:
        if not self.cache_file.exists():
            return
        try:
            _b, payload, _k = verify_envelope(self.cache_file.read_bytes(), self.keys)
            validate_payload(payload, now=dt.datetime.now(dt.timezone.utc), channel=self.channel, allow_expired=True)
            self.payload = payload
            self.fetched_at = self.store.get_kv("manifest_fetched_at")
            self.stale = True
        except ManifestError as exc:
            self.last_error = f"cached manifest rejected: {exc}"

    def accept(self, raw: bytes, now: dt.datetime | None = None) -> dict[str, Any]:
        """Verify + validate raw manifest bytes and make them current. Raises ManifestError."""
        now = now or dt.datetime.now(dt.timezone.utc)
        payload_bytes, payload, _key = verify_envelope(raw, self.keys)
        phash = hashlib.sha256(payload_bytes).hexdigest()
        state = self.store.get_kv(f"manifest_state:{self.channel}", {}) or {}
        self.warnings = validate_payload(payload, now=now, channel=self.channel, last_sequence=state.get("sequence"),
                                         last_hash=state.get("hash"), payload_hash=phash)
        self.store.set_kv(f"manifest_state:{self.channel}", {"sequence": payload["sequence"], "hash": phash})
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        tmp = self.cache_file.with_suffix(".tmp")
        tmp.write_bytes(raw)
        tmp.replace(self.cache_file)
        self.payload = payload
        self.fetched_at = iso(now)
        self.store.set_kv("manifest_fetched_at", self.fetched_at)
        self.stale = False
        self.last_error = None
        return payload

    def _fetch_bytes(self) -> bytes:
        req = urllib.request.Request(self.url, headers={"User-Agent": USER_AGENT, "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            final = resp.geturl()
            if not final.startswith("https://") and not self.url.startswith(("http://127.0.0.1", "file:")):
                raise ManifestError("manifest was redirected away from https")
            data = resp.read(MAX_MANIFEST_BYTES + 1)
        return data

    async def check(self) -> dict[str, Any] | None:
        """Fetch and accept the latest manifest. Never raises: failures are kept in last_error."""
        try:
            raw = await asyncio.to_thread(self._fetch_bytes)
            return self.accept(raw)
        except ManifestError as exc:
            self.last_error = str(exc)
        except Exception as exc:  # noqa: BLE001 - offline, DNS, TLS inspection...: stay calm, show stale
            self.last_error = f"could not reach the update server: {exc}"
        self.stale = True
        return None

    # ----- answers for the API -----------------------------------------------------------------------------
    def artifact(self, artifact_id: str) -> dict[str, Any] | None:
        for a in (self.payload or {}).get("artifacts", []) or []:
            if a.get("id") == artifact_id:
                return a
        return None

    def revoked(self, sha256: str) -> bool:
        for r in (self.payload or {}).get("revocations", []) or []:
            if isinstance(r, dict) and r.get("sha256") == sha256:
                return True
            if r == sha256:
                return True
        return False

    def app_update(self) -> dict[str, Any] | None:
        app = (self.payload or {}).get("app")
        if not app or not app.get("version"):
            return None
        available = version_tuple(app["version"]) > version_tuple(__version__)
        return {"available": available, "version": app["version"], "notes_url": app.get("notes_url")}

    def news(self) -> list[dict[str, Any]]:
        return list((self.payload or {}).get("news", []) or [])

    def catalog(self) -> dict[str, Any]:
        p = self.payload or {}
        return {"plugins": p.get("plugins", []) or [], "frameworks": p.get("frameworks", []) or [],
                "fetched_at": self.fetched_at, "signed": self.payload is not None, "stale": self.stale,
                "error": self.last_error}

    async def download_artifact(self, art: dict[str, Any], dest: Path) -> Path:
        """Download a manifest artifact, verifying exact size and sha256. Refuses stale/unsigned/revoked ones."""
        if self.payload is None:
            raise ManifestError("no verified manifest: downloads are disabled")
        if self.stale and self.last_error and "expired" in self.last_error:
            raise ManifestError("the manifest has expired: new downloads are refused until it is refreshed")
        sha = str(art.get("sha256", ""))
        if not SHA256_RE.match(sha):
            raise ManifestError(f"artifact {art.get('id')} has no sha256, refusing to download it")
        if self.revoked(sha):
            raise ManifestError(f"artifact {art.get('id')} has been revoked")
        size = art.get("size") or None
        return await asyncio.to_thread(download, art["url"], dest, expected_size=size, expected_sha256=sha,
                                       max_bytes=(size or (500 << 20)) + 1)
