"""WebRCON client for Rust (rcon.web 1): a WebSocket at ws://host:port/<password> speaking small JSON packets.

Protocol (verified live 2026-10-27, see tests/fixtures/rcon_replies.json):
    we send   {"Identifier": 1001, "Message": "serverinfo", "Name": "HoneyBadgerDeck"}
    it sends  {"Message": "...", "Identifier": 1001, "Type": "Generic", "Stacktrace": ""}
- A reply can be SEVERAL packets with the same Identifier (e.g. `quit` streamed 9 lines). We collect packets for a
  short quiet window after the first one.
- Packets with Identifier 0 or -1 are the server's own console/chat broadcast: those go to the Deck console.
- serverinfo's Message is itself JSON text with PascalCase keys (Hostname, MaxPlayers, EntityCount, Framerate...).
  Epic Rust read snake_case keys and showed zeros forever; we map the real names explicitly.

Why "reconnect forever": RCON only opens after the map is generated, which can take many minutes on first boot.
Epic Rust gave up after 60 seconds and never retried. This client keeps trying (capped, jittered backoff) for as
long as the supervisor says the server process is alive.

The password goes raw in the URL path (Rust's WebSocket server does not percent-decode; encoding it causes failed
logins). The Deck generates URL-safe passwords so this is never a problem.
"""
from __future__ import annotations

import asyncio
import itertools
import json
import logging
import random
import re
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from pydantic import AliasChoices, BaseModel, ConfigDict, Field

from .models import PlayerRow, Telemetry, iso, utcnow

log = logging.getLogger(__name__)


class RconUnavailable(RuntimeError):
    """No connection right now (server starting, stopped, or wrong password)."""


class RconBusy(RuntimeError):
    """Too many commands waiting for replies."""


# ------------------------------------------------------------------------------------------------------------
# Typed replies
# ------------------------------------------------------------------------------------------------------------

def _alias(*names: str) -> Any:
    return Field(default=None, validation_alias=AliasChoices(*names))


class ServerInfo(BaseModel):
    """The `serverinfo` reply. Field names = Rust's real PascalCase keys (snake_case accepted too)."""
    model_config = ConfigDict(extra="ignore", populate_by_name=True)

    hostname: str | None = _alias("Hostname", "hostname")
    max_players: int | None = _alias("MaxPlayers", "max_players")
    players: int | None = _alias("Players", "players")
    queued: int | None = _alias("Queued", "queued")
    joining: int | None = _alias("Joining", "joining")
    reserved_slots: int | None = _alias("ReservedSlots", "reserved_slots")
    entity_count: int | None = _alias("EntityCount", "entity_count")
    game_time: str | None = _alias("GameTime", "game_time")
    uptime: int | None = _alias("Uptime", "uptime")
    map: str | None = _alias("Map", "map")
    framerate: float | None = _alias("Framerate", "framerate")
    memory: int | None = _alias("Memory", "memory")                                   # MB, managed heap
    memory_usage_system: int | None = _alias("MemoryUsageSystem", "memory_usage_system")  # MB
    collections: int | None = _alias("Collections", "collections")
    network_in: int | None = _alias("NetworkIn", "network_in")
    network_out: int | None = _alias("NetworkOut", "network_out")
    restarting: bool | None = _alias("Restarting", "restarting")
    save_created_time: str | None = _alias("SaveCreatedTime", "save_created_time")
    version: int | None = _alias("Version", "version")
    protocol: str | None = _alias("Protocol", "protocol")

    def to_telemetry(self, at: str | None = None) -> Telemetry:
        # Every serverinfo field we parse reaches the Status (codex gap audit A: four used to be dropped here).
        return Telemetry(at=at or iso(utcnow()), players=self.players, max_players=self.max_players,
                         queued=self.queued, joining=self.joining, reserved_slots=self.reserved_slots,
                         entities=self.entity_count, fps=self.framerate,
                         memory_mb=self.memory, memory_system_mb=self.memory_usage_system,
                         collections=self.collections, net_in=self.network_in,
                         net_out=self.network_out, game_time=self.game_time, map=self.map, protocol=self.protocol,
                         version=self.version, restarting=self.restarting,
                         hostname=self.hostname, uptime_s=self.uptime, save_created=self.save_created_time)


def parse_serverinfo(message: str) -> ServerInfo | None:
    """Parse the inner JSON text of a serverinfo reply. Returns None (not zeros!) when it is not valid JSON."""
    try:
        data = json.loads(message)
    except (TypeError, ValueError):
        return None
    if not isinstance(data, dict):
        return None
    try:
        return ServerInfo.model_validate(data)
    except Exception:  # noqa: BLE001 - a type surprise in one field must not kill telemetry
        cleaned = {k: v for k, v in data.items() if isinstance(v, (str, int, float, bool))}
        try:
            return ServerInfo.model_validate(cleaned)
        except Exception:  # noqa: BLE001
            return None


def parse_playerlist(message: str) -> list[PlayerRow] | None:
    """`playerlist` returns a JSON array of {SteamID, DisplayName, Ping, Address, ConnectedSeconds, ViolationLevel,
    Health, ...} (field names from the decompiled ConVar.Admin.PlayerInfo struct)."""
    try:
        data = json.loads(message)
    except (TypeError, ValueError):
        return None
    if not isinstance(data, list):
        return None
    rows: list[PlayerRow] = []
    for p in data:
        if not isinstance(p, dict) or not p.get("SteamID"):
            continue
        rows.append(PlayerRow(steamid64=str(p.get("SteamID")), name=str(p.get("DisplayName") or ""),
                              ping=_int(p.get("Ping")), address=p.get("Address"),
                              connected_s=_int(p.get("ConnectedSeconds")), health=_float(p.get("Health")),
                              violation=_float(p.get("ViolationLevel"))))
    return rows


CARBON_PLUGIN_ROW = re.compile(r"^\s{2,}(?P<title>\S.*?)\s{2,}(?P<author>\S.*?)\s{2,}v(?P<version>\d[\w.\-]*)")


def parse_carbon_plugins(message: str) -> list[dict[str, str]]:
    """Read the table `c.plugins` prints (captured live) into [{title, author, version}]. Skips Carbon's own Core."""
    out: list[dict[str, str]] = []
    for line in message.splitlines():
        m = CARBON_PLUGIN_ROW.match(line)
        if m and m.group("title") != "Core":
            out.append({"title": m.group("title"), "author": m.group("author"), "version": m.group("version")})
    return out


def _int(v: Any) -> int | None:
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _float(v: Any) -> float | None:
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


# ------------------------------------------------------------------------------------------------------------
# Client
# ------------------------------------------------------------------------------------------------------------

@dataclass
class RconReply:
    identifier: int
    command: str
    messages: list[str] = field(default_factory=list)
    at: str = ""

    @property
    def text(self) -> str:
        return "\n".join(m for m in self.messages)


@dataclass
class _Pending:
    reply: RconReply
    first: asyncio.Event
    last_seen: float = 0.0


class RconClient:
    """One persistent WebRCON connection per server, reconnecting forever until stop() is called."""

    def __init__(self, host: str, port: int, password: str, *,
                 on_state: Callable[[str], None] | None = None,
                 on_broadcast: Callable[[dict[str, Any]], None] | None = None,
                 name: str = "HoneyBadgerDeck", max_pending: int = 64,
                 backoff_cap_s: float = 10.0, connect_timeout_s: float = 5.0, probation_s: float = 1.5) -> None:
        self.host, self.port, self.password = host, port, password
        self.on_state = on_state
        self.on_broadcast = on_broadcast
        self.name = name
        self.max_pending = max_pending
        self.backoff_cap_s = backoff_cap_s
        self.connect_timeout_s = connect_timeout_s
        self.probation_s = probation_s
        self.state = "disconnected"
        self._ids = itertools.count(1000)
        self._pending: dict[int, _Pending] = {}
        self._ws: Any = None
        self._stop = asyncio.Event()
        self._task: asyncio.Task[None] | None = None
        self._ready = asyncio.Event()
        self.connects = 0                      # how many times we connected (tests use this)

    # ----- lifecycle -----------------------------------------------------------------------------------
    @property
    def url(self) -> str:
        return f"ws://{self.host}:{self.port}/{self.password}"

    def start(self) -> None:
        if self._task is None or self._task.done():
            self._stop.clear()
            self._task = asyncio.create_task(self._run(), name=f"rcon-{self.port}")

    async def stop(self) -> None:
        self._stop.set()
        ws = self._ws
        if ws is not None:
            try:
                await ws.close()
            except Exception:  # noqa: BLE001
                pass
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, 5)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._task.cancel()
        self._set_state("disconnected")

    async def wait_ready(self, timeout: float) -> bool:
        try:
            await asyncio.wait_for(self._ready.wait(), timeout)
            return True
        except asyncio.TimeoutError:
            return False

    def _set_state(self, s: str) -> None:
        if s != self.state:
            self.state = s
            if s == "ready":
                self._ready.set()
            else:
                self._ready.clear()
            if self.on_state:
                try:
                    self.on_state(s)
                except Exception:  # noqa: BLE001
                    pass

    async def force_reconnect(self) -> None:
        ws = self._ws
        if ws is not None:
            try:
                await ws.close()
            except Exception:  # noqa: BLE001
                pass

    async def _run(self) -> None:
        from websockets.asyncio.client import connect
        attempt = 0
        while not self._stop.is_set():
            self._set_state("connecting")
            try:
                async with connect(self.url, max_size=16_000_000, open_timeout=self.connect_timeout_s,
                                   ping_interval=None, close_timeout=2) as ws:
                    # Rust closes the socket at once when the password is wrong, so "ready" needs proof:
                    # either a first packet arrives, or the connection survives a short probation period.
                    try:
                        first = await asyncio.wait_for(ws.recv(), self.probation_s)
                    except asyncio.TimeoutError:
                        first = None
                    self._ws = ws
                    self.connects += 1
                    attempt = 0
                    self._set_state("ready")
                    if first is not None:
                        self._dispatch(first)
                    async for raw in ws:
                        self._dispatch(raw)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001 - refused, reset, bad password: all mean "try again later"
                log.debug("rcon %s:%s not available: %s", self.host, self.port, exc)
            finally:
                self._ws = None
                self._fail_pending()
            if self._stop.is_set():
                break
            self._set_state("connecting")
            attempt += 1
            delay = min(self.backoff_cap_s, 0.5 * (2 ** min(attempt, 6))) * random.uniform(0.7, 1.0)
            try:
                await asyncio.wait_for(self._stop.wait(), delay)
            except asyncio.TimeoutError:
                pass
        self._set_state("disconnected")

    def _fail_pending(self) -> None:
        for pend in self._pending.values():
            pend.first.set()                  # wake waiters; they see no messages and raise
        self._pending.clear()

    def _dispatch(self, raw: str | bytes) -> None:
        try:
            msg = json.loads(raw)
        except ValueError:
            return
        if not isinstance(msg, dict):
            return
        ident = msg.get("Identifier")
        pend = self._pending.get(ident) if isinstance(ident, int) else None
        if pend is not None:
            pend.reply.messages.append(str(msg.get("Message", "")))
            pend.last_seen = asyncio.get_running_loop().time()
            pend.first.set()
            return
        if self.on_broadcast:
            try:
                self.on_broadcast(msg)
            except Exception:  # noqa: BLE001
                pass

    # ----- commands ----------------------------------------------------------------------------------------
    async def command(self, command: str, timeout: float = 10.0, quiet_s: float = 0.3) -> RconReply:
        """Send one console command and collect its reply packets. Raises RconUnavailable / asyncio.TimeoutError."""
        if "\n" in command or "\r" in command:
            raise ValueError("one command at a time (no line breaks)")
        ws = self._ws
        if ws is None or self.state != "ready":
            raise RconUnavailable("RCON is not connected")
        if len(self._pending) >= self.max_pending:
            raise RconBusy("too many RCON commands waiting")
        ident = next(self._ids)
        if ident > 2_000_000_000:
            self._ids = itertools.count(1000)
        pend = _Pending(RconReply(identifier=ident, command=command, at=iso(utcnow()) or ""), asyncio.Event())
        self._pending[ident] = pend
        loop = asyncio.get_running_loop()
        try:
            await ws.send(json.dumps({"Identifier": ident, "Message": command, "Name": self.name}))
            await asyncio.wait_for(pend.first.wait(), timeout)
            if not pend.reply.messages:
                raise RconUnavailable("RCON disconnected before replying")
            deadline = loop.time() + timeout
            while loop.time() < deadline:                 # collect the rest of a multi-packet reply
                quiet_left = pend.last_seen + quiet_s - loop.time()
                if quiet_left <= 0 or ident not in self._pending:
                    break
                await asyncio.sleep(min(quiet_left, 0.05))
            return pend.reply
        except asyncio.TimeoutError:
            raise                      # (TimeoutError is an OSError in Python 3.11+, so it must come first)
        except (ConnectionError, OSError) as exc:
            raise RconUnavailable(str(exc)) from exc
        except Exception as exc:
            if exc.__class__.__module__.startswith("websockets"):
                raise RconUnavailable(str(exc)) from exc
            raise
        finally:
            self._pending.pop(ident, None)

    async def serverinfo(self, timeout: float = 5.0) -> ServerInfo | None:
        reply = await self.command("serverinfo", timeout=timeout, quiet_s=0.05)
        return parse_serverinfo(reply.messages[0] if reply.messages else "")

    async def playerlist(self, timeout: float = 5.0) -> list[PlayerRow] | None:
        reply = await self.command("playerlist", timeout=timeout, quiet_s=0.05)
        return parse_playerlist(reply.messages[0] if reply.messages else "")

    async def text(self, command: str, timeout: float = 10.0) -> str:
        """Send one command and return its whole reply text (the `send` the ban/admin helpers below expect)."""
        return (await self.command(command, timeout=timeout)).text


# ------------------------------------------------------------------------------------------------------------
# Bans and admins (typed helpers)
# ------------------------------------------------------------------------------------------------------------
# Reply formats come from the server's own code (Assembly-CSharp.dll of RustDedicated 2635.289.1, decompiled with
# ILSpy 9.1 on 2026-10-28: ConVar.Admin and ServerUsers). They were NOT captured from a live server yet, so the
# fixtures are named *_unverified. Facts from that code:
# - `bans` returns a JSON array of {steamid, group: "Banned", username, notes, expiry} ([] when nobody is banned).
# - `listid` prints "ID filter list: empty" or "ID filter list: N entries" + "1 <steamid> : permanent" lines.
# - `banlist` / `banlistex` print NOTHING when the list is empty, so an empty reply cannot be told apart from a
#   failure. We never use them for "nobody is banned".
# - `unban` does NOT save bans.cfg (no ServerUsers.Save() call): the caller must persist (edit bans.cfg).
#   ownerid / moderatorid / removeowner / removemoderator DO save users.cfg themselves.
# - Every command answers "This doesn't appear to be a 64bit steamid: N" for a bad id.

STEAMID64_RE = re.compile(r"^7656\d{13}$")
Send = Callable[[str], Any]                      # async (command) -> reply text


class RconParseError(ValueError):
    """The reply did not have a shape we know. Never treated as "empty list" or "done"."""

    def __init__(self, message: str, reply: str) -> None:
        super().__init__(message)
        self.reply = reply


def validate_steamid64(value: Any) -> str:
    """A SteamID64 is 17 digits starting with 7656. Returns it as a string; raises ValueError otherwise.
    (A valid-looking id still does not prove who the person is.)"""
    v = str(value if value is not None else "").strip()
    if not STEAMID64_RE.match(v):
        raise ValueError("a SteamID64 is 17 digits and starts with 7656")
    return v


@dataclass
class BanEntry:
    steamid64: str
    username: str | None = None
    notes: str | None = None
    expiry: int | None = None            # Unix seconds; None = permanent (Rust stores -1 or 0 for permanent)

    def to_dict(self) -> dict[str, Any]:
        return {"steamid64": self.steamid64, "username": self.username, "notes": self.notes,
                "expiry": self.expiry, "permanent": self.expiry is None}


@dataclass
class CommandResult:
    """What happened to one typed command.
    sent      - the command went out over RCON.
    confirmed - the reply proves the server state now matches what we asked (including "already so").
    state     - short code: done | already | not_found | refused | unknown_reply."""
    command: str
    sent: bool
    confirmed: bool
    state: str
    reply: str
    message: str

    def to_dict(self) -> dict[str, Any]:
        return {"command": self.command, "sent": self.sent, "confirmed": self.confirmed, "state": self.state,
                "reply": self.reply, "message": self.message}


def _expiry(v: Any) -> int | None:
    try:
        n = int(v)
    except (TypeError, ValueError):
        return None
    return n if n > 0 else None


def parse_bans_json(text: str) -> list[BanEntry]:
    """The `bans` reply. Raises RconParseError unless it is a JSON array of ban objects (`[]` = nobody banned)."""
    try:
        data = json.loads(text)
    except (TypeError, ValueError) as exc:
        raise RconParseError("the bans reply is not JSON", text or "") from exc
    if not isinstance(data, list):
        raise RconParseError("the bans reply is not a list", text)
    out: list[BanEntry] = []
    for row in data:
        if not isinstance(row, dict) or "steamid" not in row:
            raise RconParseError("a bans row has no steamid", text)
        group = row.get("group")
        if group not in (None, "Banned", 3):
            continue                                      # only Banned rows belong in a ban list
        out.append(BanEntry(steamid64=str(row["steamid"]), username=row.get("username"), notes=row.get("notes"),
                            expiry=_expiry(row.get("expiry"))))
    return out


LISTID_HEADER_RE = re.compile(r"^ID filter list: (?:(?P<empty>empty)|(?P<n>\d+) entr(?:y|ies))\s*$")
LISTID_ROW_RE = re.compile(r"^\d+ (?P<sid>\d{17}) : (?:(?P<perm>permanent)|(?P<min>-?[\d.]+) min)\s*$")


def parse_listid(text: str, now: float | None = None) -> list[BanEntry]:
    """The `listid` reply (header + one line per ban). Raises RconParseError on any surprise, including a count
    that does not match the rows."""
    lines = [ln for ln in (text or "").replace("\r", "").split("\n") if ln.strip()]
    if not lines:
        raise RconParseError("empty listid reply", text or "")
    m = LISTID_HEADER_RE.match(lines[0].strip())
    if not m:
        raise RconParseError("listid reply has no 'ID filter list' header", text)
    want = 0 if m.group("empty") else int(m.group("n"))
    out: list[BanEntry] = []
    now = time.time() if now is None else now
    for ln in lines[1:]:
        r = LISTID_ROW_RE.match(ln.strip())
        if not r:
            raise RconParseError(f"unexpected listid line: {ln!r}", text)
        exp = None if r.group("perm") else int(now + float(r.group("min")) * 60)
        out.append(BanEntry(steamid64=r.group("sid"), expiry=exp))
    if len(out) != want:
        raise RconParseError(f"listid said {want} entries but listed {len(out)}", text)
    return out


BANS_CFG_RE = re.compile(r'^\s*banid\s+(?P<sid>\d+)(?:\s+"(?P<name>(?:[^"\\]|\\.)*)")?'
                         r'(?:\s+"(?P<notes>(?:[^"\\]|\\.)*)")?(?:\s+(?P<exp>-?\d+))?')


def parse_bans_cfg(text: str) -> list[BanEntry]:
    """server/<identity>/cfg/bans.cfg as ServerUsers.Save() writes it: `banid <id> "<name>" "<notes>" <expiry>`."""
    out: list[BanEntry] = []
    for ln in (text or "").splitlines():
        m = BANS_CFG_RE.match(ln)
        if m:
            out.append(BanEntry(steamid64=m.group("sid"), username=m.group("name"), notes=m.group("notes"),
                                expiry=_expiry(m.group("exp"))))
    return out


def remove_from_bans_cfg(text: str, steamid64: str) -> tuple[str, bool]:
    """bans.cfg text without the banid lines for one SteamID. Returns (new text, whether anything was removed)."""
    kept, removed = [], False
    for ln in (text or "").splitlines():
        m = BANS_CFG_RE.match(ln)
        if m and m.group("sid") == steamid64:
            removed = True
            continue
        kept.append(ln)
    return ("\r\n".join(kept) + ("\r\n" if kept else "")), removed


def bans_cfg_line(steamid64: str, name: str = "", notes: str = "", expiry: int | None = None) -> str:
    """One bans.cfg line exactly as ServerUsers.Save() writes it (decompiled 2635):
    `banid <id> "<name>" "<notes>" <expiry>` where expiry is Unix seconds and -1 means permanent.
    When the server runs the file at start, `banid` reads that 4th value with Arg.GetTimestamp: a number above
    315360000 is taken as an absolute time and -1 as permanent, so the line means the same ban after a restart."""
    sid = validate_steamid64(steamid64)
    exp = int(expiry) if expiry and expiry > 0 else -1
    return f'banid {sid} "{_quote(name) or "unnamed"}" "{_quote(notes) or "Banned"}" {exp}'


def add_to_bans_cfg(text: str, steamid64: str, line: str, *, replace: bool = True) -> tuple[str, bool]:
    """bans.cfg text with `line` for this SteamID. replace=True drops any older banid line for the same id first;
    replace=False keeps an existing line untouched (used when the running server says the player was ALREADY
    banned, so the file keeps matching the ban the server really has). Returns (new text, whether it changed)."""
    kept: list[str] = []
    had = False
    for ln in (text or "").splitlines():
        m = BANS_CFG_RE.match(ln)
        if m and m.group("sid") == steamid64:
            had = True
            if replace:
                continue
        kept.append(ln)
    if had and not replace:
        return text, False
    kept.append(line)
    return "\r\n".join(kept) + "\r\n", True


def _bad_id(text: str) -> bool:
    return "doesn't appear to be a 64bit steamid" in text


def parse_unban_reply(steamid64: str, text: str) -> CommandResult:
    t = (text or "").strip()
    cmd = f"unban {steamid64}"
    if t == f"Unbanned User: {steamid64}":
        return CommandResult(cmd, True, True, "done", t, "unbanned")
    if t == f"User {steamid64} isn't banned":
        return CommandResult(cmd, True, True, "not_found", t, "was not banned")
    if _bad_id(t):
        return CommandResult(cmd, True, False, "refused", t, "the server refused the SteamID")
    return CommandResult(cmd, True, False, "unknown_reply", t, "sent, but the reply was not recognised")


def parse_ban_reply(steamid64: str, text: str) -> CommandResult:
    """banid reply: 'Banned User: <id> - "<name>" for "<reason>"' (optionally 'Banned User for <time>: ...')."""
    t = (text or "").strip()
    cmd = f"banid {steamid64}"
    if re.match(rf"^Banned User(?: for [^:]+)?: {steamid64} - ", t):
        return CommandResult(cmd, True, True, "done", t, "banned")
    if t == f"User {steamid64} is already banned":
        return CommandResult(cmd, True, True, "already", t, "was already banned")
    if _bad_id(t) or t == "Expiry time is in the past":
        return CommandResult(cmd, True, False, "refused", t, t)
    return CommandResult(cmd, True, False, "unknown_reply", t, "sent, but the reply was not recognised")


_ADMIN_REPLIES = {
    # command: (done pattern, already pattern)
    "ownerid": (r"^Added owner .*, steamid {sid}$", r"^User {sid} is already an Owner$"),
    "moderatorid": (r"^Added moderator .*, steamid {sid}$", r"^User {sid} is already a Moderator$"),
    "removeowner": (r"^Removed Owner: {sid}$", r"^User {sid} isn't an owner$"),
    "removemoderator": (r"^Removed Moderator: {sid}$", r"^User {sid} isn't a moderator$"),
}


def parse_admin_reply(command: str, steamid64: str, text: str) -> CommandResult:
    t = (text or "").strip()
    done_re, already_re = (p.format(sid=re.escape(steamid64)) for p in _ADMIN_REPLIES[command])
    cmd = f"{command} {steamid64}"
    if re.match(done_re, t, re.S):
        return CommandResult(cmd, True, True, "done", t, "done")
    if re.match(already_re, t):
        return CommandResult(cmd, True, True, "already" if command in ("ownerid", "moderatorid") else "not_found",
                             t, "already so")
    if _bad_id(t) or t == "Moderators cannot run ownerid":
        return CommandResult(cmd, True, False, "refused", t, t)
    return CommandResult(cmd, True, False, "unknown_reply", t, "sent, but the reply was not recognised")


def _quote(s: str) -> str:
    """A value for a quoted console argument: no quotes or line breaks (they would end the argument)."""
    return " ".join(str(s or "").replace('"', "'").split())


async def _send(send: Send, command: str) -> str:
    reply = send(command)
    if asyncio.iscoroutine(reply) or isinstance(reply, asyncio.Future):
        reply = await reply
    return reply if isinstance(reply, str) else str(reply or "")


async def banlist(send: Send) -> list[BanEntry]:
    """Everyone banned on the running server. Tries `bans` (JSON), then `listid` (header-counted text).
    Raises RconParseError when neither reply is recognised - an unknown reply is never "nobody is banned"."""
    first = await _send(send, "bans")
    try:
        return parse_bans_json(first)
    except RconParseError:
        pass
    second = await _send(send, "listid")
    try:
        return parse_listid(second)
    except RconParseError as exc:
        raise RconParseError("neither 'bans' nor 'listid' gave a reply we understand", f"{first}\n---\n{second}") \
            from exc


async def ban(send: Send, steamid64: str, name: str = "", reason: str = "", duration_s: int | None = None
              ) -> CommandResult:
    sid = validate_steamid64(steamid64)
    cmd = f'banid {sid} "{_quote(name) or "unnamed"}" "{_quote(reason) or "Banned"}"'
    if duration_s:
        cmd += f" {int(duration_s)}s"
    return parse_ban_reply(sid, await _send(send, cmd))


async def unban(send: Send, steamid64: str) -> CommandResult:
    sid = validate_steamid64(steamid64)
    return parse_unban_reply(sid, await _send(send, f"unban {sid}"))


async def ownerid(send: Send, steamid64: str, name: str = "", notes: str = "added by HoneyBadger Bunker"
                  ) -> CommandResult:
    sid = validate_steamid64(steamid64)
    return parse_admin_reply("ownerid", sid,
                             await _send(send, f'ownerid {sid} "{_quote(name) or "unnamed"}" "{_quote(notes)}"'))


async def moderatorid(send: Send, steamid64: str, name: str = "", notes: str = "added by HoneyBadger Bunker"
                      ) -> CommandResult:
    sid = validate_steamid64(steamid64)
    return parse_admin_reply("moderatorid", sid,
                             await _send(send, f'moderatorid {sid} "{_quote(name) or "unnamed"}" "{_quote(notes)}"'))


async def removeowner(send: Send, steamid64: str) -> CommandResult:
    sid = validate_steamid64(steamid64)
    return parse_admin_reply("removeowner", sid, await _send(send, f"removeowner {sid}"))


async def removemoderator(send: Send, steamid64: str) -> CommandResult:
    sid = validate_steamid64(steamid64)
    return parse_admin_reply("removemoderator", sid, await _send(send, f"removemoderator {sid}"))
