"""Housekeeping helpers for the basics bundle: disk space, "open this folder", the console copy, the per-user
"start when I sign in" shortcut and the Linux service status.

Every call that touches the operating system (disk usage, starting Explorer, PowerShell, systemctl) is passed in as
an argument with a sensible default, so tests can hand in a fake and nothing real is launched.

Plain-English rules this file follows (docs/team/basics/BASICS_PLAN_2026-10-28.md, section E):
- Unknown stays unknown: a failed disk reading is None with an error message, never 0 bytes free.
- "Open folder" only ever opens a folder the ENGINE owns for that server (install, logs, backups, install log).
  The browser sends a word from a fixed list, never a path, so it cannot ask us to open anything else.
- Windows opens the folder; on Linux (usually headless) we return the path and say opening is not available here.
- The console copy is the newest 200 lines, oldest first, with the RCON password blanked out.
- "Start HoneyBadger Bunker when I sign in" is a shortcut in THIS user's Startup folder. It is not "at boot"; it
  runs when this Windows user signs in.
- The Linux service check asks systemctl, with a short timeout, and says "unsupported" on Windows.
"""
from __future__ import annotations

import datetime as dt
import errno
import os
import re
import shutil
import subprocess
import sys
from collections.abc import Callable, Iterable, Mapping
from pathlib import Path, PureWindowsPath
from typing import Any

from .contract import DISK_LOW_BYTES, DISK_WARN_BYTES, disk_level

# ---------------------------------------------------------------------------------------------------------------
# small helpers
# ---------------------------------------------------------------------------------------------------------------


def _now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


#: A runner takes an argument list and a timeout and returns (exit code, stdout text, stderr text).
#: It raises subprocess.TimeoutExpired when the program does not finish in time.
Runner = Callable[[list[str], float], tuple[int, str, str]]


def default_runner(argv: list[str], timeout: float) -> tuple[int, str, str]:
    """Run a short program, wait for it (bounded by `timeout`) and return what it printed. No console window."""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    done = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False,
                          creationflags=flags)   # noqa: S603 - fixed argument lists only, never a shell string
    return done.returncode, done.stdout or "", done.stderr or ""


# ---------------------------------------------------------------------------------------------------------------
# disk space
# ---------------------------------------------------------------------------------------------------------------

DiskUsage = Callable[[str], Any]   # shutil.disk_usage shape: an object with .total, .used, .free


def nearest_existing_parent(path: str | os.PathLike[str], exists: Callable[[Path], bool] = Path.exists) -> Path | None:
    """The folder itself if it exists, else the closest parent that does (a new install folder is not made yet)."""
    p = Path(path)
    for candidate in (p, *p.parents):
        try:
            if exists(candidate):
                return candidate
        except OSError:
            continue
    return None


def volume_of(path: Path) -> str | None:
    """A short id for the volume that holds `path`: the drive ("C:\\") on Windows, the device number elsewhere."""
    try:
        if sys.platform.startswith("win"):
            anchor = PureWindowsPath(os.path.abspath(path)).anchor
            return anchor.upper() or None
        return f"dev:{os.stat(path).st_dev}"
    except OSError:
        return None


def disk_info(path: str | os.PathLike[str], usage: DiskUsage = shutil.disk_usage,
              exists: Callable[[Path], bool] = Path.exists,
              volume: Callable[[Path], str | None] = volume_of) -> dict[str, Any]:
    """Free space for `path` as a contract.DiskInfo dict. Measures the nearest existing parent folder.

    Any failure returns free_bytes/total_bytes None with a plain-English error; it never invents a number.
    """
    out: dict[str, Any] = {"path": str(path), "free_bytes": None, "total_bytes": None, "checked_at": _now_iso(),
                           "error": None, "probed_path": None, "volume": None, "level": None,
                           "warn_below_bytes": DISK_WARN_BYTES, "low_below_bytes": DISK_LOW_BYTES}
    if not str(path).strip():
        out["error"] = "No folder was given."
        return out
    probe = nearest_existing_parent(path, exists)
    if probe is None:
        out["error"] = "Neither this folder nor any folder above it exists (is the drive connected?)."
        return out
    out["probed_path"] = str(probe)
    try:
        u = usage(str(probe))
        out["free_bytes"] = int(u.free)
        out["total_bytes"] = int(u.total)
    except (OSError, ValueError, AttributeError, TypeError) as exc:
        out["error"] = f"Could not read the free space: {exc}"
        return out
    out["volume"] = volume(probe)
    out["level"] = disk_level(out["free_bytes"])
    return out


def disk_report(paths: Mapping[str, str | os.PathLike[str] | None], **kwargs: Any) -> dict[str, dict[str, Any]]:
    """disk_info for several named folders at once, e.g. {"install": ..., "backups": ...}. None = unknown path."""
    report: dict[str, dict[str, Any]] = {}
    for role, p in paths.items():
        if p is None or not str(p).strip():
            report[role] = {"path": None, "free_bytes": None, "total_bytes": None, "checked_at": _now_iso(),
                            "error": "This folder is not known yet.", "probed_path": None, "volume": None,
                            "level": None, "warn_below_bytes": DISK_WARN_BYTES, "low_below_bytes": DISK_LOW_BYTES}
        else:
            report[role] = disk_info(p, **kwargs)
    return report


#: Windows says "There is not enough space on the disk" with this error number (ERROR_DISK_FULL / HANDLE_DISK_FULL).
_WIN_DISK_FULL = {39, 112}
DISK_FULL_MESSAGE = ("The disk is full. Free some space on this drive (or move the server to another drive), "
                     "then try again. Nothing was finished, so the step can be retried.")


def is_disk_full(exc: BaseException) -> bool:
    """True when an error means "no space left on the device" (ENOSPC on Linux, ERROR_DISK_FULL on Windows)."""
    if isinstance(exc, OSError):
        if exc.errno == errno.ENOSPC:
            return True
        if getattr(exc, "winerror", None) in _WIN_DISK_FULL:
            return True
    return False


# ---------------------------------------------------------------------------------------------------------------
# open a folder ("reveal")
# ---------------------------------------------------------------------------------------------------------------

REVEAL_TARGETS = ("install", "logs", "backups", "install_log")


class RevealError(Exception):
    """A reveal request we refuse. `code` is the API error code, `status` the HTTP status."""

    def __init__(self, code: str, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.code, self.message, self.status = code, message, status


def _inside(child: Path, parent: Path) -> bool:
    """True when `child` is `parent` or somewhere below it (after resolving .. and links)."""
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def _safe_name(value: str, what: str) -> str:
    """A single folder name: no slashes, no dots-only, nothing that climbs out of its parent."""
    if not value or value in (".", "..") or re.search(r"[\\/:\x00]", value):
        raise RevealError("outside_owned", f"the {what} is not a plain folder name, so it is not opened")
    return value


def reveal_target(profile: Any, target: str, data_dir: str | os.PathLike[str]) -> Path:
    """Map an allowed target word to the engine-owned path for this server. Anything else is refused.

    install     -> the server's install folder (profile.install_root; must be an absolute path, not a drive root)
    logs        -> <data>/logs/<identity>                (where the engine writes SteamCMD logs for this server)
    backups     -> <data>/backups/<profile id>           (BackupManager.dir_for, backups.py:38)
    install_log -> the newest *-steamcmd.log in the logs folder
    """
    if target not in REVEAL_TARGETS:
        raise RevealError("bad_target", f"'{target}' is not something the Bunker opens "
                          f"(choose one of: {', '.join(REVEAL_TARGETS)})")
    data = Path(data_dir)
    if target == "install":
        root = str(getattr(profile, "install_root", "") or "")
        p = Path(root)
        if not root or not p.is_absolute():
            raise RevealError("outside_owned", "this server has no install folder recorded")
        if p.resolve() == Path(p.resolve().anchor):
            raise RevealError("outside_owned", "the install folder is a whole drive, so it is not opened")
        return p
    if target == "backups":
        pid = _safe_name(str(getattr(profile, "id", "") or ""), "server id")
        p = data / "backups" / pid
        if not _inside(p, data / "backups"):
            raise RevealError("outside_owned", "that backups folder is outside the Bunker's data folder")
        return p
    ident = _safe_name(str(getattr(profile, "identity", "") or ""), "server folder name")
    logs = data / "logs" / ident
    if not _inside(logs, data / "logs"):
        raise RevealError("outside_owned", "that logs folder is outside the Bunker's data folder")
    if target == "logs":
        return logs
    newest = sorted(logs.glob("*-steamcmd.log")) if logs.is_dir() else []
    if not newest:
        raise RevealError("no_install_log", "There is no install log for this server yet. One is written the "
                          "first time the Bunker installs or updates it.", status=404)
    return newest[-1]


def reveal(path: str | os.PathLike[str], platform: str = sys.platform,
           launch: Callable[[list[str]], Any] | None = None,
           startfile: Callable[[str], Any] | None = None,
           exists: Callable[[Path], bool] = Path.exists) -> dict[str, Any]:
    """Open `path` on this PC when that is possible here; always return the path so the UI can show it.

    Windows: a file is shown selected in Explorer (`explorer /select,<file>`); a folder is opened.
    Anything else (Linux servers are usually headless): nothing is opened, `available` is False.
    Returns {path, opened, available, message}.
    """
    p = Path(path)
    shown = str(p)
    if not platform.startswith("win"):
        return {"path": shown, "opened": False, "available": False,
                "message": "Opening folders is not available here. The path is shown so you can open it yourself."}
    if not exists(p):
        return {"path": shown, "opened": False, "available": True,
                "message": "That folder does not exist yet. It is created the first time the Bunker needs it."}
    try:
        if p.is_file():
            run = launch or (lambda argv: subprocess.Popen(argv, close_fds=True))  # noqa: S603 - fixed argv
            run(["explorer", f"/select,{shown}"])
        else:
            opener = startfile or getattr(os, "startfile")
            opener(shown)
    except (OSError, AttributeError) as exc:
        return {"path": shown, "opened": False, "available": True,
                "message": f"Windows did not open the folder: {exc}"}
    return {"path": shown, "opened": True, "available": True, "message": "Opened on this PC."}


# ---------------------------------------------------------------------------------------------------------------
# console copy
# ---------------------------------------------------------------------------------------------------------------

CONSOLE_TAIL_MAX = 200
REDACTED = "[hidden]"
_RCON_ARG_RE = re.compile(r"(rcon\.password\s*[= ]\s*)(\"[^\"]*\"|'[^']*'|\S+)", re.IGNORECASE)


def make_redactor(secrets: Iterable[str | None]) -> Callable[[str], str]:
    """Build a function that blanks every known secret, plus anything written as `rcon.password <value>`."""
    known = sorted({s for s in secrets if s and len(s) >= 4}, key=len, reverse=True)

    def redact(text: str) -> str:
        out = _RCON_ARG_RE.sub(lambda m: f'{m.group(1)}"{REDACTED}"', text)
        for s in known:
            out = out.replace(s, REDACTED)
        return out

    return redact


def _line_dict(line: Any) -> dict[str, Any]:
    if isinstance(line, dict):
        return dict(line)
    if hasattr(line, "model_dump"):
        return line.model_dump()
    raise TypeError(f"not a console line: {type(line).__name__}")


def console_tail(lines: Iterable[Any], n: int = CONSOLE_TAIL_MAX,
                 redact: Callable[[str], str] | None = None) -> dict[str, Any]:
    """The newest `n` console lines (at most 200), OLDEST FIRST, each line's text passed through `redact`.

    Returns a contract.ConsoleTail dict. When fewer lines exist, `note` says so honestly.
    """
    want = max(1, min(int(n), CONSOLE_TAIL_MAX))
    rows = sorted((_line_dict(x) for x in lines), key=lambda d: d.get("seq", 0))[-want:]
    if redact is not None:
        for r in rows:
            r["text"] = redact(str(r.get("text", "")))
    note = None
    if not rows:
        note = "No console lines are held for this server right now (it may not have run since the engine started)."
    elif len(rows) < want:
        note = f"Only {len(rows)} lines are held for this server right now."
    return {"lines": rows, "requested": want, "returned": len(rows), "redacted": redact is not None, "note": note}


# ---------------------------------------------------------------------------------------------------------------
# "Start HoneyBadger Bunker when I sign in" (Windows, per user)
# ---------------------------------------------------------------------------------------------------------------

LOGIN_STARTUP_LABEL = "Start HoneyBadger Bunker when I sign in"
SHORTCUT_NAME = "HoneyBadger Bunker.lnk"


def startup_folder(env: Mapping[str, str] | None = None) -> Path | None:
    """This user's Startup folder (%APPDATA%\\Microsoft\\Windows\\Start Menu\\Programs\\Startup), None if unknown."""
    appdata = (env if env is not None else os.environ).get("APPDATA")
    if not appdata:
        return None
    return Path(appdata) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def _ps_quote(text: str) -> str:
    """A PowerShell single-quoted string: nothing inside is expanded; a ' is written as ''."""
    return "'" + text.replace("'", "''") + "'"


def shortcut_script(lnk: Path, launcher: Path, arguments: str, workdir: Path) -> str:
    """The PowerShell one-liner that writes (or overwrites) the .lnk through the WScript.Shell COM object."""
    return ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut(" + _ps_quote(str(lnk)) + ");"
            "$s.TargetPath=" + _ps_quote(str(launcher)) + ";"
            "$s.Arguments=" + _ps_quote(arguments) + ";"
            "$s.WorkingDirectory=" + _ps_quote(str(workdir)) + ";"
            "$s.Description=" + _ps_quote(LOGIN_STARTUP_LABEL) + ";"
            "$s.Save()")


def login_startup_state(startup_dir: str | os.PathLike[str] | None = None, platform: str = sys.platform,
                        env: Mapping[str, str] | None = None) -> dict[str, Any]:
    """A contract.LoginStartup dict: is the shortcut there? (We check that the file exists.)"""
    if not platform.startswith("win"):
        return {"supported": False, "enabled": None, "mechanism": None, "path": None,
                "error": "Starting at sign-in is set up on Windows only. On Linux the Bunker runs as a service."}
    folder = Path(startup_dir) if startup_dir else startup_folder(env)
    if folder is None:
        return {"supported": True, "enabled": None, "mechanism": "startup_shortcut", "path": None,
                "error": "Could not find this user's Startup folder (APPDATA is not set)."}
    lnk = folder / SHORTCUT_NAME
    try:
        on = lnk.is_file()
    except OSError as exc:
        return {"supported": True, "enabled": None, "mechanism": "startup_shortcut", "path": str(lnk),
                "error": f"Could not read the Startup folder: {exc}"}
    return {"supported": True, "enabled": on, "mechanism": "startup_shortcut", "path": str(lnk), "error": None}


def set_login_startup(enabled: bool, launcher_path: str | os.PathLike[str], data_dir: str | os.PathLike[str],
                      startup_dir: str | os.PathLike[str] | None = None, runner: Runner = default_runner,
                      platform: str = sys.platform, env: Mapping[str, str] | None = None,
                      timeout: float = 15.0) -> dict[str, Any]:
    """Create or remove the per-user Startup shortcut. Safe to call again with the same value (idempotent).

    The shortcut runs `launcher_path open --data "<data_dir>"` (open = skip the 5-second menu) from the launcher's own folder. Paths with spaces are
    quoted; the shortcut file is overwritten in place, so there is never a second copy.
    """
    state = login_startup_state(startup_dir, platform, env)
    if not state["supported"] or state["path"] is None:
        return state
    lnk = Path(state["path"])
    if not enabled:
        try:
            lnk.unlink(missing_ok=True)
        except OSError as exc:
            return {**state, "enabled": None, "error": f"Could not remove the shortcut: {exc}"}
        return login_startup_state(startup_dir, platform, env)
    launcher = Path(launcher_path)
    if not launcher.is_absolute():
        return {**state, "error": "The launcher path is not a full path, so no shortcut was made."}
    try:
        lnk.parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return {**state, "enabled": None, "error": f"Could not open the Startup folder: {exc}"}
    arguments = f'open --data "{Path(data_dir)}"'   # 'open' skips the launcher menu
    script = shortcut_script(lnk, launcher, arguments, launcher.parent)
    argv = ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script]
    try:
        code, _out, err = runner(argv, timeout)
    except subprocess.TimeoutExpired:
        return {**login_startup_state(startup_dir, platform, env),
                "error": f"Windows did not finish making the shortcut within {int(timeout)} s."}
    except OSError as exc:
        return {**login_startup_state(startup_dir, platform, env), "error": f"Could not run PowerShell: {exc}"}
    after = login_startup_state(startup_dir, platform, env)
    if code != 0 or not after["enabled"]:
        return {**after, "error": (err.strip() or f"PowerShell exited with code {code}") if code != 0
                else "PowerShell finished but the shortcut is not there."}
    return after


# ---------------------------------------------------------------------------------------------------------------
# Linux service status
# ---------------------------------------------------------------------------------------------------------------

UNIT_RE = re.compile(r"^[A-Za-z0-9@._\-]{1,100}$")
DEFAULT_UNIT = "hbdeck"     # packaging/linux/install.sh SERVICE=hbdeck (override with --name)


def service_status(unit: str = DEFAULT_UNIT, runner: Runner = default_runner, timeout: float = 3.0,
                   platform: str = sys.platform, which: Callable[[str], str | None] = shutil.which) -> dict[str, Any]:
    """A contract.ServiceInfo dict from `systemctl is-active` and `systemctl is-enabled`, each bounded by `timeout`.

    systemctl's own word is passed through (active, inactive, failed, enabled, disabled, ...). A word we could not
    read stays None, with the reason in `error`. On Windows (or without systemctl) `supported` is False.
    """
    out: dict[str, Any] = {"unit": unit, "active": None, "enabled": None, "checked_at": _now_iso(), "error": None,
                           "supported": True}
    if not platform.startswith("linux"):
        return {**out, "supported": False, "error": "The service check is for Linux (systemd). Not used on Windows."}
    if not UNIT_RE.match(unit):
        return {**out, "error": "That service name is not valid."}
    exe = which("systemctl")
    if not exe:
        return {**out, "supported": False, "error": "systemctl was not found, so this Linux does not use systemd."}
    errors: list[str] = []
    for verb, key in (("is-active", "active"), ("is-enabled", "enabled")):
        try:
            _code, stdout, stderr = runner([exe, verb, unit], timeout)
        except subprocess.TimeoutExpired:
            errors.append(f"systemctl {verb} did not answer within {timeout:g} s")
            continue
        except OSError as exc:
            errors.append(f"systemctl {verb} could not run: {exc}")
            continue
        word = (stdout.strip().splitlines() or [""])[0].strip()
        if word:
            out[key] = word
        else:
            errors.append(f"systemctl {verb} gave no answer{': ' + stderr.strip() if stderr.strip() else ''}")
    out["error"] = "; ".join(errors) or None
    return out


def engine_service_field(info: dict[str, Any]) -> dict[str, Any] | None:
    """What GET /engine sends as `service`: the ServiceInfo, or null where systemd is not supported."""
    return info if info.get("supported") else None


def capabilities(platform: str = sys.platform, which: Callable[[str], str | None] = shutil.which) -> dict[str, bool]:
    """contract.EngineCapabilities for this machine (no subprocess, no network)."""
    win = platform.startswith("win")
    linux = platform.startswith("linux")
    return {"reveal_folders": win, "windows_firewall": win, "login_startup": win,
            "systemd_status": bool(linux and which("systemctl"))}


__all__ = [
    "Runner", "default_runner", "nearest_existing_parent", "volume_of", "disk_info", "disk_report", "is_disk_full",
    "DISK_FULL_MESSAGE", "REVEAL_TARGETS", "RevealError", "reveal_target", "reveal", "CONSOLE_TAIL_MAX",
    "REDACTED", "make_redactor", "console_tail", "LOGIN_STARTUP_LABEL", "SHORTCUT_NAME", "startup_folder",
    "shortcut_script", "login_startup_state", "set_login_startup", "DEFAULT_UNIT", "service_status",
    "engine_service_field", "capabilities",
]
