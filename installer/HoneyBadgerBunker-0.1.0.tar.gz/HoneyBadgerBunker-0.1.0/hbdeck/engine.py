"""The Engine: one object that owns everything (database, supervisors, operations, scheduler, update channel).

The API layer (hbdeck/api) only translates HTTP requests into calls on this object, and the scheduler only calls
`run_scheduled`. Business rules live here and in the modules it uses, never in the web layer.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import json
import logging
import os
import re
import secrets
import shutil
import socket
import sys
import time
import uuid
from pathlib import Path
from typing import Any

import psutil

from . import __version__, guards
from . import housekeeping as hk
from .backups import BackupManager
from .console import ConsoleBuffer
from .contract import CONNECT_DEFAULTS, ENGINE_DEFAULTS, STATUS_DEFAULTS, merge_defaults
from .countdown import Countdown, span_text, validate_warn_s
from .events import EventBus
from .frameworks import FrameworkManager, detect_framework, probe_files
from .killall import rcon_save_and_quit
from .games import get_game
from .mapcrop import crop_island
from .models import (Admin, Operation, PluginInfo, Ports, Profile, ProfileCreate, Schedule, ScheduleIn, Status, iso,
                     utcnow)
from .operations import OpContext, OperationRunner, OpError, run_blocking
from .platform import LockBusy, Platform, current_platform
from .ports import find_collisions, pick_ports, probe_free
from .profiles import Store, atomic_write, canonical_path, parse_users_cfg, split_cfg
from .registry import OwnershipRegistry
from .rcon import RconBusy, RconUnavailable
from .scheduler import Scheduler, backup_request
from .server_updates import ServerUpdateService, installed_framework_revision
from .server_updates import framework_health as framework_health_info
from .steamcmd import ProcessTracker as SteamCmdTracker
from .steamcmd import SteamCmd, SteamCmdError, read_build_id
from .supervisor import RUN, Supervisor, STOP_FAILED
from .updates import ManifestError, UpdateService
from .wipe_calendar import forced_wipe_info

log = logging.getLogger(__name__)
INITIALIZING, RUNNING, STOPPING, EXITED = "initializing", "running", "stopping", "exited"   # engine states
PLUGIN_FILE_RE = re.compile(r"^[A-Za-z0-9_]{1,64}\.cs$")
PLUGIN_INFO_RE = re.compile(r'\[Info\(\s*"(?P<title>[^"]+)"\s*,\s*"(?P<author>[^"]*)"\s*,\s*"(?P<version>[^"]+)"')


def slugify(name: str) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "", name.lower())[:24]
    return s or "hbserver"


# What an "advanced" (not in the catalog) option name must look like: a real Rust convar such as
# decay.upkeep_period_minutes. Lower case, at least one dot, nothing else: no spaces, braces, quotes or Python text.
ADVANCED_CONVAR_RE = re.compile(r"^[a-z][a-z0-9_]*(\.[a-z0-9_]+)+$")


class Engine:
    def __init__(self, data_dir: Path, *, platform: Platform | None = None, servers_dir: Path | None = None,
                 steamcmd_command: list[str] | None = None, manifest_url: str | None = None,
                 start_scheduler: bool = True, check_updates: bool = True,
                 reservations_dir: Path | None = None) -> None:
        self.data_dir = Path(data_dir).resolve()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.platform = platform or current_platform()
        env_servers = os.environ.get("HB_SERVERS_DIR")
        # Parent folder for new servers: explicit argument, else HB_SERVERS_DIR (the Linux service sets
        # /srv/honeybadger/servers), else <data>/servers.
        self.servers_dir = Path(servers_dir or env_servers or self.data_dir / "servers")
        self.steamcmd_command = steamcmd_command
        self.version = __version__
        self.started = utcnow()
        self.token = secrets.token_hex(24)
        self.port: int | None = None
        self.events = EventBus()
        self.store = Store(self.data_dir / "state.db")
        self.ops = OperationRunner(self)
        self.frameworks = FrameworkManager(self)
        self.backups = BackupManager(self.data_dir)
        kwargs: dict[str, Any] = {}
        if manifest_url:
            kwargs["url"] = manifest_url
        self.updates = UpdateService(self.store, self.data_dir / "cache", **kwargs)
        # "Is there a newer Rust build / framework release?" One cache for the whole engine (server_updates.py).
        # Status frames only READ it; the hourly check below and POST /updates/check may ask upstream.
        self.server_updates = ServerUpdateService(self.data_dir, steamcmd_runner=self._app_info_print)
        self.server_update_interval_s = 3600.0       # hourly (the cache adds its own jitter and backoff)
        self.server_update_first_delay_s = 120.0     # let the engine settle (and autostart) before the first check
        # Housekeeping facts GET /engine reports (housekeeping.py). launcher_path = what a "start when I sign in"
        # shortcut should run; None when this engine was not started from its own Windows launcher folder.
        self.launcher_path: str | None = resolve_launcher_path(self.data_dir, self.platform.os_name)
        self.service_unit = os.environ.get("HB_SERVICE_UNIT") or hk.DEFAULT_UNIT
        self.storage_cache_s = 30.0                  # disk readings are cheap but status frames come every 2 s
        self._storage_cache: dict[str, tuple[float, dict[str, Any]]] = {}
        self._service_cache: tuple[float, dict[str, Any] | None] | None = None
        # Countdown before Stop / Restart / Update (countdown.py). Tests raise the speed so a 60 s countdown
        # takes a fraction of a second; the warnings still say "1 minute".
        self.countdown_speed = 1.0
        self.scheduler = Scheduler(self)
        self.supervisors: dict[str, Supervisor] = {}
        self._consoles: dict[str, ConsoleBuffer] = {}
        self._engine_lock = None
        self._bg: list[asyncio.Task[Any]] = []
        self.start_scheduler = start_scheduler
        self.check_updates = check_updates
        # timings (tests shrink these)
        self.telemetry_interval = 5.0
        self.tail_interval = 0.25
        self.status_interval = 2.0
        self.rcon_backoff_cap = 10.0
        self.backoff_scale = 1.0
        self.steamcmd_backoff: tuple[float, ...] = (5, 15, 30)
        self.map_render_cooldown_s = 60.0   # never ask the server to draw the island more than once a minute
        self.map_render_timeout_s = 20.0    # how long to wait for the picture file
        self._map_render_at: dict[str, float] = {}       # profile id -> time.monotonic() of the last render
        self._map_locks: dict[str, asyncio.Lock] = {}
        self.request_exit = None   # set by the server runner: a callable that makes uvicorn exit
        self.bind = "127.0.0.1"
        # ---- process guards (docs/team/guards/GUARD_PLAN_2026-10-28.md) ----
        self.instance_id = uuid.uuid4().hex          # this engine start; sent as X-HBDeck-Instance on every reply
        self.state = INITIALIZING                    # initializing -> running -> stopping -> exited
        self.registry = OwnershipRegistry(self.data_dir / "ownership.db")
        self.reservations_dir = Path(reservations_dir) if reservations_dir else guards.machine_reservations_dir()
        self.process_iter = None                     # tests may inject a fake psutil.process_iter
        self.listening = None                        # set by the server runner: callable -> True once HTTP listens
        self.heartbeat_interval = guards.HEARTBEAT_INTERVAL_S
        self.ops_quiesce_s = guards.OPS_QUIESCE_S
        self.server_stop_cap_s = guards.SERVER_STOP_CAP_S
        self.last_session: dict[str, Any] | None = None   # {"clean": False, ...} when the last session crashed
        self.shutdown_report: dict[str, Any] | None = None
        self._shutdown_task: asyncio.Task[dict[str, Any]] | None = None
        self._ready_done = False
        self._store_closed = False

    # ================================================================================================
    # lifecycle
    # ================================================================================================
    def claim(self) -> None:
        """Take <data>/engine.lock (the ONE gate for "one engine per data folder"). Idempotent.

        Raises EngineAlreadyRunning (exit code 3) when another live engine owns this folder - even if its web page
        does not answer. Called by the server runner BEFORE anything else, and again (no-op) by startup().
        """
        if self._engine_lock is not None and self._engine_lock.held:
            return
        self._engine_lock = guards.claim_folder(self.platform, self.data_dir)
        self._write_owner()

    def adopt_claim(self, lock: Any) -> None:
        """The server runner took the folder lock BEFORE this Engine (and its database) existed: keep it."""
        self._engine_lock = lock
        self._write_owner()

    def _write_owner(self) -> None:
        """Who holds engine.lock (written only while we hold it; never deleted - the next owner rewrites it)."""
        try:
            guards.write_owner(self.data_dir, {"pid": os.getpid(), "create_time": guards.create_time_of(os.getpid()),
                                               "instance": self.instance_id, "data_dir": canonical_path(self.data_dir),
                                               "port": self.port, "started": iso(self.started)})
        except OSError as exc:
            log.warning("could not write engine.lock.json: %s", exc)

    async def startup(self) -> None:
        self.claim()
        try:
            await self._startup_after_claim()
        except BaseException:
            # Partial startup: undo everything we did and release the lock, so the next try starts clean.
            await self._abort_startup()
            raise

    async def _startup_after_claim(self) -> None:
        prev = guards.last_session_from_heartbeat(self.data_dir)
        if prev is not None and not prev["clean"]:
            self.last_session = prev
            log.warning("the last session ended without a clean stop (last heartbeat %s)", prev.get("ended_at"))
        guards.write_heartbeat(self.data_dir, os.getpid(), self.instance_id)
        self.registry.add("engine", os.getpid(), guards.create_time_of(os.getpid()), list(sys.argv),
                          data_dir=self.data_dir, instance=self.instance_id, containment=self.platform.containment(),
                          started_at=guards.now_iso())
        n = self.store.mark_interrupted_operations()
        if n:
            log.warning("%d operations were interrupted by the last shutdown", n)
        for p in self.store.list_profiles():
            self.supervisor(p.id)
            self._note_survivor(p)
        if self.start_scheduler:
            self.scheduler.start()
        self._bg.append(asyncio.create_task(self._status_loop(), name="status-loop"))
        self._bg.append(asyncio.create_task(self._heartbeat_loop(), name="heartbeat"))
        if self.check_updates:
            self._bg.append(asyncio.create_task(self._update_loop(), name="update-loop"))
            # In _bg on purpose: shutdown (and an aborted startup) cancels it, so it can never outlive the engine.
            self._bg.append(asyncio.create_task(self._server_update_loop(), name="server-update-loop"))
        self.state = RUNNING
        if self.listening is None:
            self._become_ready()
        else:
            # Announce ourselves (engine.json) and autostart only once the web server really listens.
            self._bg.append(asyncio.create_task(self._ready_when_listening(), name="ready"))

    async def _ready_when_listening(self) -> None:
        while self.state == RUNNING:
            if self.listening and self.listening():
                self._become_ready()
                return
            await asyncio.sleep(0.05)

    def _become_ready(self) -> None:
        if self._ready_done or self.state != RUNNING:
            return
        self._ready_done = True
        self._write_owner()
        self.write_engine_json()
        for p in self.store.list_profiles():
            if not p.autostart:
                continue
            sup = self.supervisor(p.id)
            if sup.phase == "conflict":
                self.console(p.id).append("system", "Autostart skipped: a server from a previous session may still "
                                                    "be running. Use 'Stop it' or 'Leave it' on the Deck.", "warn")
                continue
            try:
                self.submit_start(p.id)
            except OpError as exc:
                self.console(p.id).append("system", f"Autostart skipped: {exc}", "warn")

    async def _abort_startup(self) -> None:
        self.state = STOPPING
        self.ops.close()
        for t in self._bg:
            t.cancel()
        await self.scheduler.stop()
        for sup in self.supervisors.values():
            sup.release_reservations()
            sup.release_lock()
        self.registry.remove(os.getpid(), guards.create_time_of(os.getpid()))
        self.remove_engine_json()
        self.state = EXITED
        if self._engine_lock is not None:
            self._engine_lock.release()
            self._engine_lock = None

    async def _heartbeat_loop(self) -> None:
        while True:
            await asyncio.sleep(self.heartbeat_interval)
            guards.write_heartbeat(self.data_dir, os.getpid(), self.instance_id)

    def _note_survivor(self, p: Profile) -> None:
        """A server from a previous session (or another Deck) still running this world = CONFLICT.

        We never adopt it and never kill an unknown pid on our own: the Deck shows it with "Stop it" / "Leave it",
        and autostart / crash restart stay off for this profile until it is resolved.
        """
        found = self.detect_survivor(p)
        if found is not None:
            sup = self.supervisor(p.id)
            sup.enter_conflict(found)
            self.console(p.id).append("system", sup.last_error or "a server may still be running", "warn")

    # ----- the spawn guard -------------------------------------------------------------------------------
    def spawn_allowed(self) -> bool:
        try:
            self.check_spawn_allowed()
            return True
        except OpError:
            return False

    def check_spawn_allowed(self) -> None:
        """Raise unless a new server process may be created right now. Synchronous on purpose (no await)."""
        if self.state not in (INITIALIZING, RUNNING):
            raise OpError("HoneyBadger Bunker is shutting down; no server will be started", "engine_stopping")
        if guards.barrier_active(self.platform, self.data_dir):
            raise OpError("Stop everything is running; no server will be started until it finishes",
                          "engine_stopping")

    # ----- shutdown -----------------------------------------------------------------------------------------
    @property
    def shutdown_budget_s(self) -> float:
        """The whole bounded shutdown: jobs stop, then every server saves and quits IN PARALLEL, then escalation."""
        return self.ops_quiesce_s + self.server_stop_cap_s + guards.ESCALATION_RESERVE_S

    def begin_stopping(self) -> None:
        """Synchronous first half of shutdown: from this instant no operation is accepted and no server starts.

        Runs before the first await of shutdown (Hermes: checking a flag later, inside a callback, is too late).
        """
        if self.state in (STOPPING, EXITED):
            return
        self.state = STOPPING
        self.ops.close()
        for sup in self.supervisors.values():
            sup.on_engine_stopping()

    async def shutdown(self) -> dict[str, Any]:
        """Stop every running server gracefully (bounded), then release everything.

        Safe to call any number of times, from anywhere: every caller awaits the SAME shutdown and gets the same
        report. The engine lock is released last.
        """
        if self._shutdown_task is None:
            self.begin_stopping()
            self._shutdown_task = asyncio.ensure_future(self._shutdown_impl())
        return await asyncio.shield(self._shutdown_task)

    async def _shutdown_impl(self) -> dict[str, Any]:
        report: dict[str, Any] = {"started": guards.now_iso(), "servers": [], "ops_still_running": [],
                                  "helpers_killed": [], "errors": []}
        try:
            for t in self._bg:
                if t.get_name() != "heartbeat":
                    t.cancel()
            await self.scheduler.stop()
            # 1. jobs: cancel queued + running operations (incl. "start the server again" tails), bounded
            report["ops_still_running"] = await self.ops.quiesce(timeout=self.ops_quiesce_s)
            # 2. servers: save + quit in parallel, each bounded, death verified by the OS
            cap = self.server_stop_cap_s
            sups = list(self.supervisors.values())

            def deadline_for(s: Supervisor) -> float:
                prof = self.store.get_profile(s.profile_id)
                return min(float(prof.supervision.stop_deadline_s if prof else 90), cap)

            results = await asyncio.gather(*(s.shutdown(deadline_for(s)) for s in sups), return_exceptions=True)
            for s, r in zip(sups, results):
                if isinstance(r, BaseException):
                    log.error("stopping %s failed: %r", s.profile_id, r)
                    report["errors"].append(f"{s.profile_id}: {r!r}")
                    report["servers"].append({"profile_id": s.profile_id, "result": "error", "pid": s.pid})
                else:
                    report["servers"].append(r)
            # 3. helpers this engine started (SteamCMD...) that are somehow still alive
            report["helpers_killed"] = await self._stop_helpers()
        except Exception as exc:  # noqa: BLE001 - shutdown must always reach the release below
            log.exception("engine shutdown failed")
            report["errors"].append(repr(exc))
        finally:
            for t in self._bg:
                t.cancel()
            if self._bg:
                await asyncio.wait(self._bg, timeout=5)
            report["finished"] = guards.now_iso()
            self.shutdown_report = report
            clean = not report["errors"] and all(r.get("result") != "stop_failed" for r in report["servers"])
            guards.write_heartbeat(self.data_dir, os.getpid(), self.instance_id, clean=clean)
            try:
                atomic_write(self.data_dir / "logs" / "last_shutdown.json", json.dumps(report, indent=1))
            except OSError:
                pass
            self.remove_engine_json()
            self.registry.remove(os.getpid(), guards.create_time_of(os.getpid()))
            self.registry.close()
            self.store.close()
            self._store_closed = True
            self.state = EXITED
            if self._engine_lock is not None:          # LAST: only now may another engine take this folder
                self._engine_lock.release()
                self._engine_lock = None
        return report

    async def _stop_helpers(self) -> list[int]:
        """Kill SteamCMD/helper processes this engine instance registered that are still alive (verified)."""
        killed: list[int] = []
        for row in self.registry.list():
            if row.kind not in ("steamcmd", "helper") or row.instance != self.instance_id:
                continue
            if guards.classify_pid(row.pid, row.create_time) == "alive":
                await asyncio.to_thread(self.platform.kill_tree, row.pid)
                killed.append(row.pid)
            if guards.classify_pid(row.pid, row.create_time) == "dead":
                self.registry.remove_row(row.id)
        return killed

    @property
    def _shut(self) -> bool:
        return self._shutdown_task is not None

    # ----- engine.json: how the shell, CLI and UI find this engine ----------------------------------------
    @property
    def engine_json(self) -> Path:
        return self.data_dir / "engine.json"

    def write_engine_json(self) -> None:
        if self.port is None:
            return
        data = {"port": self.port, "token": self.token, "pid": os.getpid(), "started": iso(self.started),
                "bind": self.bind, "version": self.version, "instance": self.instance_id,
                "create_time": guards.create_time_of(os.getpid()), "data_dir": canonical_path(self.data_dir)}
        atomic_write(self.engine_json, json.dumps(data, indent=1), self.platform)

    def remove_engine_json(self) -> None:
        try:
            data = json.loads(self.engine_json.read_text(encoding="utf-8"))
            if data.get("pid") == os.getpid() and data.get("instance", self.instance_id) == self.instance_id:
                self.engine_json.unlink()
        except (OSError, ValueError):
            pass

    async def _status_loop(self) -> None:
        while True:
            await asyncio.sleep(self.status_interval)
            for pid, sup in list(self.supervisors.items()):
                if sup.alive or sup.state not in ("stopped",) or self.ops.current(pid):
                    self.publish_status(pid)

    async def _update_loop(self) -> None:
        while True:
            await self.updates.check()
            self.events.publish({"type": "engine", "engine": self.engine_info()})
            await asyncio.sleep(6 * 3600)

    async def _server_update_loop(self) -> None:
        """Hourly: is there a newer Rust build or framework release for each server? Never during an operation."""
        await asyncio.sleep(self.server_update_first_delay_s)
        while True:
            await self.check_server_updates()
            await asyncio.sleep(self.server_update_interval_s)

    async def check_server_updates(self) -> None:
        """One round of update checks. A profile with a running operation is skipped (the cache marks it
        'deferred' and asks next time), so a check never competes with an install for SteamCMD or bandwidth."""
        for prof in self.store.list_profiles():
            if self.state != RUNNING:
                return
            busy = self.ops.current(prof.id) is not None
            try:
                await self.server_updates.check(prof, receipt=self.store.get_receipt(prof.id, "framework"),
                                                os_name=self.platform.os_name, busy=busy,
                                                evidence=self._framework_evidence(prof.id))
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 - a failed check is stored by the cache; never stop the loop
                log.exception("server update check failed for %s", prof.id)
            self.publish_status(prof.id)

    async def _app_info_print(self, app_id: int) -> str:
        """Fallback build lookup (`steamcmd +app_info_print`), used only when steamcmd.net does not answer.
        Holds the SteamCMD-root lock without waiting (steamcmd.app_info_print_text) and is registered in the
        ownership registry while it runs, so shutdown and Stop everything can find it."""
        from .steamcmd import app_info_print_text
        root = self.data_dir / "steamcmd"
        steam = SteamCmd(root, self.platform, self.steamcmd_command, tracker=self._helper_tracker())
        if not steam.is_present():
            raise SteamCmdError("SteamCMD is not downloaded yet (it arrives with the first install)")
        return await app_info_print_text(steam, app_id)

    def _helper_tracker(self) -> SteamCmdTracker:
        def started(pid: int, argv: list[str]) -> None:
            self.registry.add("steamcmd", pid, guards.create_time_of(pid), argv, data_dir=self.data_dir,
                              instance=self.instance_id, containment=self.platform.containment(),
                              started_at=guards.now_iso())

        def ended(pid: int) -> None:
            self.registry.remove(pid)
        return SteamCmdTracker(started, ended)

    # ================================================================================================
    # small shared services
    # ================================================================================================
    def console(self, profile_id: str) -> ConsoleBuffer:
        buf = self._consoles.get(profile_id)
        if buf is None:
            buf = ConsoleBuffer(profile_id)
            buf.listeners.append(lambda pid, line: self.events.publish(
                {"type": "console", "profile_id": pid, "line": line.model_dump()}))
            self._consoles[profile_id] = buf
        return buf

    def supervisor(self, profile_id: str) -> Supervisor:
        sup = self.supervisors.get(profile_id)
        if sup is None:
            sup = Supervisor(self, profile_id)
            self.supervisors[profile_id] = sup
        return sup

    def publish_status(self, profile_id: str) -> None:
        try:
            if profile_id not in self.supervisors or self.store.get_profile(profile_id) is None:
                return
            payload = self._status_payload(profile_id)
        except Exception:  # noqa: BLE001 - e.g. a late callback after the database was closed at shutdown
            return
        self.events.publish({"type": "status", "profile_id": profile_id, "status": payload})

    def status(self, profile_id: str) -> Status:
        self.require_profile(profile_id)
        return self.supervisor(profile_id).status()

    def status_payload(self, profile_id: str) -> dict[str, Any]:
        """GET /profiles/{pid}/status and the WebSocket status frame: the Status object plus the basics fields
        (update facts, framework health, last maintenance failure, disk). Every contract field is present;
        what nobody has observed yet is null (contract.STATUS_DEFAULTS)."""
        self.require_profile(profile_id)
        return self._status_payload(profile_id)

    def _status_payload(self, profile_id: str) -> dict[str, Any]:
        out = self.supervisor(profile_id).status().model_dump(mode="json")
        out.update(self._status_extras(profile_id))
        return merge_defaults(out, STATUS_DEFAULTS)

    def _status_extras(self, profile_id: str) -> dict[str, Any]:
        """The basics-bundle status fields. Each part fails on its own: an unreadable folder makes THAT part
        unknown (null / 'unknown'), never the whole status frame."""
        prof = self.store.get_profile(profile_id)
        if prof is None:
            return {}
        out: dict[str, Any] = {}
        os_name = self.platform.os_name
        receipt = self.store.get_receipt(profile_id, "framework")
        rt = self.store.get_runtime(profile_id)
        try:
            out.update(self.server_updates.status(prof, receipt=receipt, os_name=os_name,
                                                  evidence=self._framework_evidence(profile_id)))
        except Exception:  # noqa: BLE001
            log.debug("update facts unavailable for %s", profile_id, exc_info=True)
        try:
            files = probe_files(Path(prof.install_root), os_name) if prof.install_root else None
            out["framework_health"] = framework_health_info(prof.framework, receipt, files,
                                                            self._runtime_marker(profile_id))
        except Exception:  # noqa: BLE001
            log.debug("framework health unavailable for %s", profile_id, exc_info=True)
        failure = rt.get("maintenance_failure")
        out["maintenance_failure"] = failure if isinstance(failure, dict) else None
        dur = rt.get("last_update_duration_s")
        out["last_update_duration_s"] = float(dur) if isinstance(dur, (int, float)) else None
        out["storage"] = {"install": self._disk(prof.install_root or None),
                          "backups": self._disk(str(self.backups.dir_for(prof)))}
        return out

    def _runtime_marker(self, profile_id: str) -> dict[str, Any] | None:
        """Runtime evidence that the framework LOADED: the running server's own log named its version
        (supervisor.framework_version_seen). Files on disk alone never count."""
        sup = self.supervisors.get(profile_id)
        prof = self.store.get_profile(profile_id)
        if sup is None or prof is None or not sup.alive or not sup.framework_version_seen:
            return None
        return {"framework": prof.framework, "version": sup.framework_version_seen}

    def _framework_evidence(self, profile_id: str) -> dict[str, Any] | None:
        """{rust_build, framework_revision, loaded} for the compatibility verdict: only when this run's server
        reported the framework loading on the build that is installed now."""
        if self._runtime_marker(profile_id) is None:
            return None
        rt = self.store.get_runtime(profile_id)
        rev = installed_framework_revision(self.store.get_receipt(profile_id, "framework"))
        if not rt.get("build_id") or not rev:
            return None
        return {"rust_build": str(rt["build_id"]), "framework_revision": rev, "loaded": True,
                "seen_at": iso(utcnow())}

    def _disk(self, path: str | None) -> dict[str, Any]:
        """Free space for one folder (housekeeping.disk_info), cached for storage_cache_s seconds."""
        key = str(path or "")
        hit = self._storage_cache.get(key)
        now = time.monotonic()
        if hit is not None and now - hit[0] < self.storage_cache_s:
            return hit[1]
        info = hk.disk_report({"x": path})["x"]
        self._storage_cache[key] = (now, info)
        return info

    def operation_finished(self, op: Operation) -> None:
        """Called by the operation runner when any job ends. Keeps the durable 'last maintenance job failed' fact
        (shown on the Deck with Try again until an install/update/verify/framework job succeeds), and the last
        update's duration (history, never a promise)."""
        if not op.profile_id or op.kind not in ("install", "update", "verify", "framework"):
            return
        if self.store_closed or self.store.get_profile(op.profile_id) is None:
            return
        if op.state == "failed":
            self.store.update_runtime(op.profile_id, maintenance_failure={
                "operation_id": op.id, "kind": op.kind, "code": op.error_code or "operation_failed",
                "message": op.error or "the job failed", "at": op.finished or iso(utcnow()), "log_id": op.log_id})
        elif op.state == "done":
            fields: dict[str, Any] = {}
            if self.store.get_runtime(op.profile_id).get("maintenance_failure"):
                fields["maintenance_failure"] = None
            if op.kind == "update" and op.started and op.finished:
                t0 = dt.datetime.fromisoformat(op.started.replace("Z", "+00:00"))
                t1 = dt.datetime.fromisoformat(op.finished.replace("Z", "+00:00"))
                fields["last_update_duration_s"] = round((t1 - t0).total_seconds(), 1)
            if fields:
                self.store.update_runtime(op.profile_id, **fields)

    def require_profile(self, profile_id: str) -> Profile:
        p = self.store.get_profile(profile_id)
        if p is None:
            raise OpError("no such server profile", "not_found")
        return p

    def engine_info(self) -> dict[str, Any]:
        """GET /engine and the WebSocket engine frame. Every contract field is present (contract.ENGINE_DEFAULTS)."""
        info = self._engine_info_base()
        try:
            info.update(self._engine_extras())
        except Exception:  # noqa: BLE001 - housekeeping facts must never break the engine frame
            log.debug("engine housekeeping facts unavailable", exc_info=True)
        return merge_defaults(info, ENGINE_DEFAULTS)

    def _engine_extras(self) -> dict[str, Any]:
        caps = hk.capabilities()
        return {"capabilities": caps, "service": self._service_info(caps),
                "login_startup": hk.login_startup_state(),
                "storage": {"servers": self._disk(str(self.servers_dir)),
                            "backups": self._disk(str(self.data_dir / "backups"))}}

    def _service_info(self, caps: dict[str, bool]) -> dict[str, Any] | None:
        """systemctl is-active / is-enabled for the Linux unit (null where systemd is not used). Cached 60 s:
        it runs two short subprocesses, and engine frames go out often."""
        if not caps.get("systemd_status"):
            return None
        now = time.monotonic()
        if self._service_cache is not None and now - self._service_cache[0] < 60:
            return self._service_cache[1]
        info = hk.engine_service_field(hk.service_status(self.service_unit))
        self._service_cache = (now, info)
        return info

    def _engine_info_base(self) -> dict[str, Any]:
        return {"version": self.version, "os": self.platform.os_name, "data_dir": str(self.data_dir),
                "servers_dir": str(self.servers_dir),
                "uptime_s": int((utcnow() - self.started).total_seconds()), "update": self.updates.app_update(),
                "news": self.updates.news(), "manifest": {"fetched_at": self.updates.fetched_at,
                                                          "stale": self.updates.stale, "error": self.updates.last_error},
                "forced_wipe": forced_wipe_info(),
                # process guards: the Deck shows banners from these (never only in logs)
                "instance": self.instance_id, "state": self.state,
                "last_session": self.last_session,      # {"clean": false, "ended_at", "pid"} = last stop was unclean
                "conflicts": self.conflicts(),
                "shutdown_budget_s": self.shutdown_budget_s}

    # ================================================================================================
    # process guards: survivors, conflicts, stop everything
    # ================================================================================================
    def _own_pids(self) -> set[int]:
        return {s.pid for s in self.supervisors.values() if s.alive and s.pid}

    def detect_survivor(self, prof: Profile) -> dict[str, Any] | None:
        """Is anything we do NOT own running this world (identity) or holding its ports? None = nothing found.

        Evidence, strongest first: the pid file in the server folder, the last pid in state.db (pid + creation time,
        so a re-used pid is never mistaken for our server), then an exact-token scan of every process command line.
        A game-named process we cannot inspect, or a scan that fails, also counts (verified = False): it MAY be our
        world, so we refuse rather than guess.
        """
        game = get_game(prof.game)
        own = self._own_pids()
        ports = [port for _p, port, _r in prof.ports.binds()]
        base = {"identity": prof.identity, "port": prof.ports.game_udp, "profile_id": prof.id}
        cands: list[tuple[Any, Any, str]] = []
        rec = guards.read_pid_file(Path(prof.install_root)) or {}
        if rec.get("state") == "running" and rec.get("pid"):
            cands.append((rec.get("pid"), rec.get("create_time"), "pid file"))
        rt = self.store.get_runtime(prof.id)
        if rt.get("last_pid") and rt.get("last_create_time"):
            cands.append((rt.get("last_pid"), rt.get("last_create_time"), "last run"))
        for pid, ct, source in cands:
            if not pid or int(pid) in own:
                continue
            verdict = guards.classify_pid(pid, ct)
            if verdict == "dead":
                continue
            try:
                cmd = psutil.Process(int(pid)).cmdline()
                reasons = guards.token_matches(cmd, prof.identity, ports)
                if not reasons:
                    continue          # same pid + creation time but not this world's command line: not ours
                verified = True
            except psutil.NoSuchProcess:
                continue
            except psutil.Error:
                reasons, verified = ["command line not readable"], False
            return {**base, "pid": int(pid), "create_time": ct, "verified": verified, "reasons": reasons,
                    "source": source}
        res = guards.scan_server_processes(prof.identity, ports, list(game.exe_names.values()), exclude_pids=own,
                                           process_iter=self.process_iter)
        if res.matches:
            m = res.matches[0]
            port = next((int(r.split()[-1]) for r in m.reasons if not r.startswith("identity")), prof.ports.game_udp)
            return {**base, "port": port, "pid": m.pid, "create_time": m.create_time, "verified": True,
                    "reasons": m.reasons, "source": "process scan", "name": m.name}
        if res.unverifiable:
            m = res.unverifiable[0]
            return {**base, "pid": m.pid, "create_time": m.create_time, "verified": False, "reasons": m.reasons,
                    "source": "process scan", "name": m.name}
        if res.error:
            return {**base, "pid": None, "create_time": None, "verified": False,
                    "reasons": [f"the process scan failed ({res.error})"], "source": "process scan"}
        return None

    def preflight_start(self, profile_id: str) -> None:
        """Answer 409 BEFORE an operation is accepted when a start can only fail (Codex: a queued failure becomes
        an operation record, not an HTTP error). The same checks run again inside the operation."""
        self.check_spawn_allowed()
        prof = self.require_profile(profile_id)
        sup = self.supervisor(profile_id)
        if sup.alive or sup._transition.locked():
            return    # our own server: the operation itself reports "already running" (unchanged contract)
        found = self.detect_survivor(prof)
        if found is not None:
            sup.enter_conflict(found)
            raise OpError(sup.last_error or "a server is already running", "server_already_running",
                          {k: found.get(k) for k in ("pid", "port", "identity", "verified", "reasons")})
        if sup.phase == "conflict":
            sup.clear_conflict()

    def conflicts(self) -> list[dict[str, Any]]:
        out = []
        for pid, sup in self.supervisors.items():
            if sup.conflict:
                prof = self.store.get_profile(pid) if not self.store_closed else None
                out.append({**sup.conflict, "profile_id": pid, "name": prof.name if prof else None,
                            "can_rcon_quit": bool(prof and self.store.get_secret(f"{prof.id}:rcon"))})
        return out

    @property
    def store_closed(self) -> bool:
        return self._store_closed

    def conflict_leave(self, profile_id: str) -> dict[str, Any]:
        """"Leave it": the user saw the warning. The server stays refused (no start, no autostart) until it is gone."""
        self.require_profile(profile_id)
        sup = self.supervisor(profile_id)
        if sup.conflict:
            sup.conflict["acknowledged"] = True
            self.publish_status(profile_id)
        return {"ok": True, "conflict": sup.conflict}

    def dismiss_last_session(self) -> dict[str, Any]:
        self.last_session = None
        self.events.publish({"type": "engine", "engine": self.engine_info()})
        return {"ok": True}

    def submit_conflict_stop(self, profile_id: str) -> Operation:
        """"Stop it": verify the survivor again, ask it to save + quit over RCON (if we know the password),
        otherwise / afterwards terminate it, and verify it is gone."""
        prof = self.require_profile(profile_id)
        sup = self.supervisor(profile_id)
        if not sup.conflict:
            raise OpError("there is no conflicting server for this profile", "not_found")

        async def run(ctx: OpContext) -> None:
            c = dict(sup.conflict or {})
            async with ctx.step("Check that it is still the same server") as st:
                found = self.detect_survivor(prof)
                if found is None:
                    sup.clear_conflict()
                    st.detail = "it is already gone"
                    return
                if not found.get("verified") or found.get("pid") != c.get("pid"):
                    sup.enter_conflict(found)
                    raise OpError("that process could not be verified as this server, so it was NOT stopped. "
                                  "Use Stop everything, or end it by hand.", "not_owned")
                st.detail = f"pid {found['pid']} ({', '.join(found.get('reasons', []))})"
            pid, ct = int(found["pid"]), found.get("create_time")
            graceful = False
            password = None
            if self.store.get_secret(f"{prof.id}:rcon"):
                password = self.rcon_password(prof)
            if password:
                async with ctx.step("Save and quit over RCON") as st:
                    graceful = await rcon_save_and_quit("127.0.0.1", prof.ports.rcon_tcp, password, pid, ct,
                                                       float(prof.supervision.stop_deadline_s))
                    st.detail = "it saved and quit" if graceful else "no answer; it will be ended instead"
            if not graceful:
                async with ctx.step("End the process") as st:
                    await asyncio.to_thread(self.platform.terminate_tree, pid)
                    if not await asyncio.to_thread(self.platform.wait_dead, pid, ct, 10):
                        await asyncio.to_thread(self.platform.kill_tree, pid)
                    st.detail = "ended (the world may not have been saved)"
            if not await asyncio.to_thread(self.platform.wait_dead, pid, ct, 10):
                raise OpError(f"pid {pid} is still running; it could not be stopped (permission?)", "stop_failed")
            self.registry.remove(pid, ct)
            rec = guards.read_pid_file(Path(prof.install_root)) or {}
            if rec.get("pid") == pid:                  # the record of the process we just verified dead
                guards.remove_pid_file_if(Path(prof.install_root), rec.get("run_id"))
            sup.clear_conflict()
            ctx.log("The old server is stopped. You can press Start now.")
        return self.ops.submit(profile_id, "conflict_stop", run, {"pid": sup.conflict.get("pid")})

    def submit_kill_all(self) -> Operation:
        """POST /engine/kill-all: answer with an operation id FIRST (this engine is about to stop itself).

        The operation stops everything this data folder owns that is NOT this engine (orphans, survivors, helpers),
        writes the report to <data>/logs/last_killall.json, then shuts this engine down (which stops its own
        servers gracefully, bounded). The result of that last part lands in <data>/logs/last_shutdown.json.
        """
        from .killall import kill_all

        async def run(ctx: OpContext) -> None:
            async with ctx.step("Stop servers this Deck does not control") as st:
                # this engine and the servers it runs are left to its own graceful shutdown below
                report = await asyncio.to_thread(kill_all, self.data_dir,
                                                 exclude_pids={os.getpid(), *self._own_pids()},
                                                 exclude_instance=self.instance_id, include_engines=False,
                                                 platform=self.platform)
                st.detail = report.summary()
                ctx.op.params["report"] = report.as_dict()
            async with ctx.step("Save and stop this Deck's servers, then close the engine") as st:
                st.detail = "the engine stops now; see logs/last_shutdown.json"
                if self.request_exit:
                    loop = asyncio.get_running_loop()
                    loop.call_later(0.3, self.request_exit)
        return self.ops.submit(None, "kill_all", run)

    def rcon_password(self, profile: Profile) -> str:
        ref = f"{profile.id}:rcon"
        blob = self.store.get_secret(ref)
        if blob is None:
            pw = secrets.token_urlsafe(18)
            self.store.set_secret(ref, self.platform.protect(pw.encode()))
            return pw
        return self.platform.unprotect(blob).decode()

    async def say(self, profile_id: str, text: str) -> bool:
        sup = self.supervisors.get(profile_id)
        if not sup or not sup.alive or not sup.rcon or sup.rcon.state != "ready":
            return False
        try:
            await sup.rcon.command(f'say "{text}"', timeout=5, quiet_s=0.05)
            self.console(profile_id).append("system", f"Warned players: {text}")
            return True
        except (RconUnavailable, asyncio.TimeoutError):
            return False

    # ================================================================================================
    # profiles
    # ================================================================================================
    def create_profile(self, body: ProfileCreate) -> Profile:
        profiles = self.store.list_profiles()
        game = get_game(body.game)
        identity = body.identity or slugify(body.name)
        taken = {p.identity for p in profiles}
        base, n = identity, 2
        while body.identity is None and identity in taken:
            identity = f"{base}{n}"[:40]
            n += 1
        install_root = Path(body.install_root) if body.install_root else self.servers_dir / identity
        install_root = install_root.resolve()
        if canonical_path(install_root) == canonical_path(self.data_dir) or len(install_root.parts) < 2:
            raise OpError("choose a dedicated folder for the server", "bad_install_root")
        imported = game.is_installed(install_root, self.platform.os_name)
        if body.existing_install and not imported:
            raise OpError(f"no {game.exe_names[self.platform.os_name]} found in {install_root}; pick the folder "
                          "that contains the server", "not_installed_here")
        if body.ports == "auto":
            ports = pick_ports(profiles)
        else:
            ports = body.ports
            cols = find_collisions(ports, profiles, probe=None)
            if cols:
                c = cols[0]
                raise OpError(f"port {c.port}/{c.protocol} is already used by {c.owner}", "port_in_use",
                              {"port": c.port, "owner": c.owner})
        data = body.model_dump(exclude={"ports", "identity", "install_root", "existing_install"})
        prof = Profile(**data, identity=identity, install_root=str(install_root), ports=ports, imported=imported)
        if not prof.steamcmd_root:
            prof.steamcmd_root = str(self.data_dir / "steamcmd")
        if imported:
            fw = detect_framework(install_root)
            prof.framework = fw or "vanilla"   # type: ignore[assignment]  # tell the truth about what is on disk
            users = game.identity_dir(prof) / "cfg" / "users.cfg"
            if users.exists() and not prof.admins:
                prof.admins = parse_users_cfg(users.read_text(encoding="utf-8", errors="replace"))
        self.store.save_profile(prof)
        self.rcon_password(prof)
        self.supervisor(prof.id)
        self.console(prof.id).append("system", f"Profile created ({'adopted existing install at' if imported else 'will install to'} {install_root})")
        return prof

    def update_profile(self, profile_id: str, body: dict[str, Any]) -> Profile:
        cur = self.require_profile(profile_id)
        sup = self.supervisor(profile_id)
        merged = cur.model_dump()
        merged.update({k: v for k, v in body.items() if k not in ("id", "created", "updated", "imported")})
        if merged.get("ports") == "auto":
            merged["ports"] = cur.ports.model_dump()
        new = Profile.model_validate(merged)
        if sup.alive:
            for f in ("install_root", "identity", "game", "ports", "bind_ip"):
                if getattr(new, f) != getattr(cur, f):
                    raise OpError(f"stop the server before changing {f}", "server_running")
        if new.ports != cur.ports:
            cols = find_collisions(new.ports, self.store.list_profiles(), exclude_id=profile_id)
            if cols:
                c = cols[0]
                raise OpError(f"port {c.port}/{c.protocol} is already used by {c.owner}", "port_in_use",
                              {"port": c.port, "owner": c.owner})
        self.store.save_profile(new)
        self.publish_status(profile_id)
        return new

    def delete_profile(self, profile_id: str, remove_files: bool = False) -> None:
        prof = self.require_profile(profile_id)
        sup = self.supervisor(profile_id)
        if sup.alive or self.ops.current(profile_id):
            raise OpError("stop the server (and wait for running jobs) before deleting it", "server_running")
        sup.release_reservations()
        sup.release_lock()
        if remove_files:
            root = Path(prof.install_root)
            if root.exists():
                if canonical_path(root) in (canonical_path(self.data_dir), canonical_path(Path.home())) \
                        or len(root.resolve().parts) < 3:
                    raise OpError("refusing to delete that folder", "unsafe_delete")
                shutil.rmtree(root)
        self.store.delete_profile(profile_id)
        self.supervisors.pop(profile_id, None)
        self._consoles.pop(profile_id, None)

    def delete_token(self, profile_id: str) -> str:
        self.require_profile(profile_id)
        tok = secrets.token_hex(8)
        self.store.set_kv(f"delete_token:{profile_id}", {"token": tok, "at": iso(utcnow())})
        return tok

    def check_delete_token(self, profile_id: str, token: str | None) -> bool:
        rec = self.store.get_kv(f"delete_token:{profile_id}")
        if not rec or not token or not secrets.compare_digest(rec["token"], token):
            return False
        at = dt.datetime.fromisoformat(rec["at"].replace("Z", "+00:00"))
        return (utcnow() - at).total_seconds() < 600

    def connect_info(self, profile_id: str) -> dict[str, Any]:
        """The short connect summary (GET /connect itself is served by api/network_routes.py). Never carries the
        RCON password: only whether one is set (the secret is shown only by POST .../rcon-password/reveal)."""
        p = self.require_profile(profile_id)
        lan = lan_ip()
        return merge_defaults({"lan_ip": lan, "wan_ip": None, "game_port": p.ports.game_udp,
                               "connect_command": f"client.connect {lan or '127.0.0.1'}:{p.ports.game_udp}",
                               "local_connect_command": f"client.connect 127.0.0.1:{p.ports.game_udp}",
                               "rcon_port": p.ports.rcon_tcp, "hostname": p.hostname, "bind_ip": p.bind_ip,
                               "rcon_password_set": self.store.get_secret(f"{p.id}:rcon") is not None},
                              CONNECT_DEFAULTS)

    # ================================================================================================
    # operations (each returns the Operation at once; the work runs in the background)
    # ================================================================================================
    def _busy(self, sup: Supervisor, state: str | None) -> None:
        sup.busy_state = state
        self.publish_status(sup.profile_id)

    # ----- countdown (Stop / Restart / Update) ------------------------------------------------------------
    def _rcon_ready(self, profile_id: str) -> bool:
        sup = self.supervisors.get(profile_id)
        return bool(sup and sup.alive and sup.rcon is not None and sup.rcon.state == "ready")

    def _countdown(self, profile_id: str, *, check: bool) -> Countdown:
        """A countdown that warns players in chat. `check=True` is the version used BEFORE a request is accepted:
        it refuses (RconUnavailable -> 422) when nobody could hear the warnings. Inside the operation the
        countdown keeps going even if RCON drops: the user chose to wait, and a missed warning is reported."""
        speed = max(1.0, float(self.countdown_speed))
        return Countdown(say=lambda text: self.say(profile_id, text),
                         clock=lambda: time.monotonic() * speed,
                         sleep=lambda s: asyncio.sleep(s / speed),
                         can_say=(lambda: self._rcon_ready(profile_id)) if check else None)

    def check_warn(self, profile_id: str, warn_s: Any) -> int:
        """Validate a request's warn_s (0, 60 or 300) and, when the server is running and players are to be warned,
        make sure RCON can deliver the warnings. Raises ValueError (422 invalid_request) or RconUnavailable
        (422 rcon_unavailable; the UI then offers "Stop now")."""
        w = validate_warn_s(0 if warn_s is None else warn_s)
        if w > 0 and self.supervisor(profile_id).alive:
            self._countdown(profile_id, check=True).check_can_warn(w)
        return w

    async def _warn_players(self, ctx: OpContext, profile_id: str, warn_s: int, action: str,
                            warned_until: int | None = None) -> bool:
        """Run the warning countdown as an operation step. True = go ahead with the action now.
        Cancelling the operation during the countdown means the action never happens."""
        sup = self.supervisor(profile_id)
        if warn_s <= 0 or not sup.alive:
            return True
        cd = self._countdown(profile_id, check=False)

        def still_wanted() -> bool:
            # Rechecked right before acting: the engine is not shutting down, the server still exists, and for a
            # restart/update the guards' desired state is still "run" (nobody asked for it to stay stopped).
            if self.state not in (INITIALIZING, RUNNING) or self.store.get_profile(profile_id) is None:
                return False
            return action == "stop" or sup.desired == RUN

        async def go_ahead() -> bool:
            return True
        async with ctx.step(f"Warn players ({span_text(warn_s)})") as st:
            res = await cd.run(warn_s, action, go_ahead, before_final=still_wanted, warned_until=warned_until)
            sent = [w for w in res.warnings if w.delivered]
            missed = res.failed_warnings
            st.detail = f"{len(sent)} warning(s) sent" + (f", {len(missed)} could not be delivered" if missed else "")
            ctx.op.params["countdown"] = res.to_dict()
            if res.state != "done":
                st.state = "skipped"
                st.detail = ("not done: the Bunker is shutting down, the server was removed, or it is no longer "
                             "meant to be running")
                return False
        return True

    def submit_install(self, profile_id: str, validate: bool = True, kind: str = "install", warn_s: int = 0,
                       warned_until: int | None = None) -> Operation:
        self.require_profile(profile_id)
        if kind == "update":
            warn_s = self.check_warn(profile_id, warn_s)
        else:
            warn_s = 0

        async def run(ctx: OpContext) -> None:
            sup = self.supervisor(profile_id)
            restart_after = False
            if sup.alive:
                if kind == "install":
                    raise OpError("the server is running; use Update instead", "server_running")
                if not await self._warn_players(ctx, profile_id, warn_s, "update", warned_until):
                    return
                async with ctx.step("Save and stop the server"):
                    await self._stop_for_maintenance(sup)
                restart_after = True
            self._busy(sup, "installing" if kind == "install" else "updating")
            try:
                await self._install_steps(ctx, profile_id, validate)
            finally:
                self._busy(sup, None)
            # Only if it was running before; never after a failed install (that raised above). The spawn gate
            # refuses this start if the engine began shutting down meanwhile.
            if restart_after:
                async with ctx.step("Start the server again"):
                    await sup.start()
        return self.ops.submit(profile_id, kind, run, {"validate": validate, "warn_s": warn_s})

    def submit_verify(self, profile_id: str) -> Operation:
        """Verify files: SteamCMD validate, then the framework again, then the config. Stopped servers only, and
        never restarted afterwards. Validate may bring official files up to the branch's current build."""
        prof = self.require_profile(profile_id)
        sup = self.supervisor(profile_id)
        if sup.alive:
            raise OpError("Stop the server before verifying its files.", "server_running")
        if self.ops.current(profile_id) is not None or sup.busy_state:
            raise OpError("Another task is running on this server; try again when it finishes.", "busy")
        if sup.phase == "conflict":
            raise OpError(sup.last_error or "another server holds this world", "server_already_running")

        async def run(ctx: OpContext) -> None:
            if sup.alive:
                raise OpError("Stop the server before verifying its files.", "server_running")
            self._busy(sup, "updating")
            try:
                await self._install_steps(ctx, profile_id, validate=True)
            finally:
                self._busy(sup, None)
        return self.ops.submit(profile_id, "verify", run, {"validate": True, "restart_after": False,
                                                           "branch": prof.branch})

    def _refuse_if_active(self, profile_id: str, what: str) -> None:
        """Server-side guard for Restore / Apply framework (a disabled button is guidance, not a guard)."""
        sup = self.supervisor(profile_id)
        if sup.alive:
            raise OpError(f"stop the server before {what}", "server_running")
        if sup.phase == "conflict":
            raise OpError(sup.last_error or "another server holds this world", "server_already_running")
        if self.ops.current(profile_id) is not None or sup.busy_state:
            raise OpError(f"another task is running on this server; {what} when it finishes", "busy")

    async def _install_steps(self, ctx: OpContext, profile_id: str, validate: bool) -> None:
        prof = self.require_profile(profile_id)
        game = get_game(prof.game)
        sup = self.supervisor(profile_id)
        root = Path(prof.install_root)
        async with ctx.step("Prepare folders"):
            root.mkdir(parents=True, exist_ok=True)
            sup.ensure_lock()
        steam = SteamCmd(Path(prof.steamcmd_root or self.data_dir / "steamcmd"), self.platform, self.steamcmd_command,
                         tracker=self._steamcmd_tracker(prof))
        steam.root.mkdir(parents=True, exist_ok=True)
        lock = self.platform.lock(steam.root / "hbdeck-steamcmd.lock")
        async with ctx.step("Wait for SteamCMD to be free"):
            for _ in range(600):
                try:
                    lock.acquire()
                    break
                except LockBusy:
                    ctx.detail("another install is using SteamCMD")
                    await asyncio.sleep(1)
            else:
                raise OpError("SteamCMD stayed busy for 10 minutes", "steamcmd_busy")
        try:
            log_dir = self.data_dir / "logs" / prof.identity
            log_dir.mkdir(parents=True, exist_ok=True)
            steam_log = log_dir / f"{utcnow().strftime('%Y%m%d-%H%M%S')}-steamcmd.log"
            ctx.op.log_id = steam_log.name      # "Open the install log" (POST .../reveal install_log) opens it
            with open(steam_log, "a", encoding="utf-8") as fh:
                def on_line(stream: str, line: str) -> None:
                    fh.write(line + "\n")
                    fh.flush()
                    self.console(profile_id).append("stdout" if stream != "system" else "system", line)

                async with ctx.step("Download SteamCMD"):
                    if steam.is_present():
                        ctx.detail("already present")
                    else:
                        await steam.ensure_downloaded(lambda t: on_line("system", t))
                async with ctx.step("Update SteamCMD (first run updates itself)"):
                    code = await steam.bootstrap(on_line)
                    ctx.detail(f"exit code {code}")
                async with ctx.step("Download server files") as st:
                    def on_progress(p: Any, speed: float | None) -> None:
                        if p.phase == "bootstrap":
                            return
                        # measured progress for the operation strip: bytes, and WHAT is counted (download vs disk)
                        ctx.op.progress = {"kind": "download" if p.phase.startswith("download") else "disk",
                                           "done": int(p.done) if p.done else None,
                                           "total": int(p.total) if p.total > 0 else None,
                                           "rate": round(speed * 1e6) if speed else None,
                                           "label": "Rust server files"}
                        # Format agreed with the UI: "1234 / 6100 MB" plus optional " 45.2 MB/s".
                        # total == 0 = the disk poller saw files arriving before Steam knew the total size.
                        if p.total <= 0:
                            ctx.detail(f"{p.done / 1e6:.0f} MB downloaded" + (f" {speed:.1f} MB/s" if speed else ""))
                            return
                        txt = f"{p.done / 1e6:.0f} / {p.total / 1e6:.0f} MB"
                        if speed and p.phase.startswith("download"):
                            txt += f" {speed:.1f} MB/s"
                        if not p.phase.startswith("download"):
                            txt = f"{txt} ({p.phase})"
                        ctx.detail(txt, p.percent if p.phase.startswith("download") else None)
                    try:
                        res = await steam.install_app(root, game.app_id,
                                                      lambda: game.is_installed(root, self.platform.os_name),
                                                      branch=prof.branch, validate=validate, on_line=on_line,
                                                      on_progress=on_progress, backoff_s=self.steamcmd_backoff)
                    except SteamCmdError as exc:
                        raise OpError(f"SteamCMD could not install the server: {exc}", "steamcmd_failed") from exc
                    st.detail = f"build {res.build_id} (attempt {res.attempts})"
                    self.store.update_runtime(profile_id, build_id=res.build_id, last_update=iso(utcnow()))
                    ctx.op.progress = None
        finally:
            lock.release()
        await self._framework_steps(ctx, prof, reapply=True)
        async with ctx.step("Preload plugins"):
            copied = self.frameworks.preload_bundled_plugins(self.require_profile(profile_id), ctx.log)
            ctx.op.steps[-1].detail = ", ".join(copied) if copied else "nothing new"
        async with ctx.step("Write server config"):
            sup.write_configs(self.require_profile(profile_id))
        ctx.op.percent = 100.0

    def _steamcmd_tracker(self, prof: Profile) -> SteamCmdTracker:
        """Every SteamCMD run goes into the ownership registry while it runs (Stop everything can find it)."""
        def started(pid: int, argv: list[str]) -> None:
            self.registry.add("steamcmd", pid, guards.create_time_of(pid), argv, install_root=prof.install_root,
                              data_dir=self.data_dir, instance=self.instance_id, profile_id=prof.id,
                              identity=prof.identity, containment=self.platform.containment(),
                              started_at=guards.now_iso())

        def ended(pid: int) -> None:
            self.registry.remove(pid)
        return SteamCmdTracker(started, ended)

    async def _framework_steps(self, ctx: OpContext, prof: Profile, reapply: bool) -> None:
        root = Path(prof.install_root)
        want = prof.framework
        have = detect_framework(root)
        if want == "vanilla":
            ctx.skip("Install framework", "vanilla (no mod framework)")
            return
        if want == "carbon" and have == "carbon":
            ctx.skip("Install Carbon", "already installed (Carbon updates itself on boot)")
            return
        if want == "oxide" and have == "oxide" and not reapply:
            ctx.skip("Install Oxide", "already installed")
            return
        label = "Re-apply Oxide (SteamCMD replaced its files)" if (want == "oxide" and have is None and
                                                                   self.store.get_receipt(prof.id, "framework")) \
            else f"Install {want.capitalize()}"
        # Release identity (release id, asset id, digest) from the update cache, so the receipt can tell a
        # re-published `production_build` apart from the one we installed. Only for the upstream channel: a
        # pinned artifact is a different file.
        release = None
        if (prof.framework_pin or "upstream") == "upstream":
            snap = self.server_updates.cache.snapshot(self.server_updates.framework_key(want, self.platform.os_name))
            release = snap.get("value") if isinstance(snap.get("value"), dict) else None
        async with ctx.step(label) as st:
            try:
                rec = await self.frameworks.install(prof, want, prof.framework_pin, ctx.log, release=release)
            except OpError:
                raise
            except Exception as exc:  # noqa: BLE001
                raise OpError(f"{want} install failed: {exc}. The server will not be started with a "
                              "half-installed framework.", "framework_failed") from exc
            st.detail = f"{want} {rec.get('version') or ''}".strip()

    def submit_start(self, profile_id: str) -> Operation:
        self.preflight_start(profile_id)        # 409 now, not a failed operation later

        async def run(ctx: OpContext) -> None:
            sup = self.supervisor(profile_id)
            async with ctx.step("Launch the server (hidden)"):
                await sup.start()
            async with ctx.step("Wait for 'Server startup complete'") as st:
                warn_task = asyncio.create_task(self._slow_start_warning(ctx, st))
                try:
                    ok = await sup.wait_running()
                finally:
                    warn_task.cancel()
                if not ok:
                    raise OpError(sup.last_error or "the server stopped during startup", "start_failed")
        return self.ops.submit(profile_id, "start", run)

    async def _slow_start_warning(self, ctx: OpContext, st: Any) -> None:
        await asyncio.sleep(900)
        ctx.log("Startup is taking more than 15 minutes (big maps can). The server is still being watched.", "warn")
        st.detail = "still starting after 15 minutes"

    async def _stop_for_maintenance(self, sup, graceful: bool = True) -> bool:
        """Stop a server BEFORE touching its files (restart, backup, wipe, update, framework, restore).

        If the process cannot be verified dead (Supervisor.stop() returned False and set STOP_FAILED), the operation
        must NOT go on: replacing or archiving a live world is exactly the damage the stop was meant to prevent.
        Returns True for a clean stop, False for a forced stop whose death WAS verified.
        """
        clean = await sup.stop(graceful=graceful)
        if sup.alive or sup.phase == STOP_FAILED:
            raise OpError(sup.last_error or "the server could not be stopped and may still be running; "
                          "use Stop everything or end it in Task Manager", "stop_failed")
        return clean

    def submit_stop(self, profile_id: str, graceful: bool = True, warn_s: int = 0) -> Operation:
        self.require_profile(profile_id)
        warn_s = self.check_warn(profile_id, warn_s) if graceful else 0

        async def run(ctx: OpContext) -> None:
            sup = self.supervisor(profile_id)
            if not await self._warn_players(ctx, profile_id, warn_s, "stop"):
                return
            async with ctx.step("Save the world and quit" if graceful else "Stop now (no save)") as st:
                clean = await self._stop_for_maintenance(sup, graceful=graceful)
                st.detail = "stopped cleanly" if clean else "had to be forced (unsafe)"
        return self.ops.submit(profile_id, "stop", run, {"graceful": graceful, "warn_s": warn_s})

    def submit_restart(self, profile_id: str, warn_s: int = 0, warned_until: int | None = None) -> Operation:
        self.require_profile(profile_id)
        if not self.supervisor(profile_id).alive:
            self.preflight_start(profile_id)
        warn_s = self.check_warn(profile_id, warn_s)

        async def run(ctx: OpContext) -> None:
            sup = self.supervisor(profile_id)
            if sup.alive:
                if not await self._warn_players(ctx, profile_id, warn_s, "restart", warned_until):
                    return
                async with ctx.step("Save the world and quit"):
                    await self._stop_for_maintenance(sup)
            async with ctx.step("Launch the server (hidden)"):
                await sup.start()
            async with ctx.step("Wait for 'Server startup complete'"):
                if not await sup.wait_running():
                    raise OpError(sup.last_error or "the server stopped during startup", "start_failed")
        return self.ops.submit(profile_id, "restart", run, {"warn_s": warn_s})

    def submit_framework(self, profile_id: str, framework: str, pin: str = "upstream") -> Operation:
        if framework not in ("carbon", "oxide", "vanilla"):
            raise OpError("framework must be carbon, oxide or vanilla", "bad_request")
        self.require_profile(profile_id)
        self._refuse_if_active(profile_id, "changing its framework")

        async def run(ctx: OpContext) -> None:
            sup = self.supervisor(profile_id)
            if sup.alive:
                raise OpError("stop the server before changing its framework", "server_running")
            # Same folder lock the install path takes (<install>/hbdeck.lock): an adopted server folder may be
            # managed by another Deck with a different data folder - never remove/replace its files under it.
            sup.ensure_lock()
            prof = self.require_profile(profile_id)
            async with ctx.step("Back up plugins, configs and world"):
                if get_game(prof.game).identity_dir(prof).exists():
                    self.backups.create(prof, f"before switching to {framework}", ctx.log, kind="other")
                else:
                    ctx.op.steps[-1].state = "skipped"
            need_validate = False
            current = detect_framework(Path(prof.install_root))
            if current and current != framework:
                async with ctx.step(f"Remove {current}"):
                    need_validate = self.frameworks.remove(prof, ctx.log)
            prof.framework = framework  # type: ignore[assignment]
            prof.framework_pin = pin
            self.store.save_profile(prof)
            if need_validate:
                # The old framework had replaced game files: a SteamCMD validate puts the originals back,
                # then the install steps lay down the new framework.
                ctx.log("Restoring original game files with SteamCMD validate")
                await self._install_steps(ctx, profile_id, validate=True)
                return
            await self._framework_steps(ctx, prof, reapply=True)
            async with ctx.step("Preload plugins"):
                self.frameworks.preload_bundled_plugins(prof, ctx.log)
        return self.ops.submit(profile_id, "framework", run, {"framework": framework, "pin": pin})

    def submit_backup(self, profile_id: str, label: str = "", *, kind: str = "manual", schedule_id: str | None = None,
                      keep_newest: int | None = None) -> Operation:
        """kind "manual" (the Back up button; never pruned automatically) or "scheduled" (a backup schedule, which
        keeps only its own newest `keep_newest`; pruning runs only after this archive was written)."""
        self.require_profile(profile_id)

        async def run(ctx: OpContext) -> None:
            sup = self.supervisor(profile_id)
            restart_after = sup.alive
            if restart_after:
                async with ctx.step("Save and stop the server"):
                    await self._stop_for_maintenance(sup)
            self._busy(sup, "backing_up")
            try:
                async with ctx.step("Write backup zip") as st:
                    info = await run_blocking(self.backups.create, self.require_profile(profile_id),
                                              label or "manual backup", ctx.log, kind=kind,
                                              schedule_id=schedule_id, keep_newest=keep_newest)
                    st.detail = f"{info.id} ({info.size / 1e6:.1f} MB)"
                    ctx.op.params["backup_id"] = info.id
            finally:
                self._busy(sup, None)
            if restart_after:
                async with ctx.step("Start the server again"):
                    await sup.start()
        return self.ops.submit(profile_id, "backup", run, {"label": label, "kind": kind,
                                                           **({"schedule_id": schedule_id} if schedule_id else {})})

    def submit_restore(self, profile_id: str, backup_id: str) -> Operation:
        self.require_profile(profile_id)
        self._refuse_if_active(profile_id, "restoring a backup")

        async def run(ctx: OpContext) -> None:
            sup = self.supervisor(profile_id)
            if sup.alive:
                raise OpError("stop the server before restoring a backup", "server_running")
            sup.ensure_lock()    # hold <install>/hbdeck.lock (see submit_framework) before replacing any file
            self._busy(sup, "backing_up")
            try:
                prof = self.require_profile(profile_id)
                async with ctx.step("Safety backup of the current state"):
                    if get_game(prof.game).identity_dir(prof).exists():
                        await run_blocking(self.backups.create, prof, f"before restoring {backup_id}", ctx.log,
                                           backup_id, kind="pre_restore")
                async with ctx.step(f"Restore {backup_id}"):
                    await run_blocking(self.backups.restore, prof, backup_id, ctx.log)
            finally:
                self._busy(sup, None)
        return self.ops.submit(profile_id, "restore", run, {"backup_id": backup_id})

    def submit_wipe(self, profile_id: str, scope: str, new_seed: int | None = None, backup: bool = True) -> Operation:
        if scope not in ("map", "blueprints", "full"):
            raise OpError("scope must be map, blueprints or full", "bad_request")
        self.require_profile(profile_id)

        async def run(ctx: OpContext) -> None:
            sup = self.supervisor(profile_id)
            sup.ensure_lock()    # hold <install>/hbdeck.lock (see submit_framework) before deleting any file
            was_running = sup.alive
            if was_running:
                async with ctx.step("Save and stop the server"):
                    await self._stop_for_maintenance(sup)
            self._busy(sup, "wiping")
            try:
                prof = self.require_profile(profile_id)
                game = get_game(prof.game)
                async with ctx.step("Check what will be removed") as st:
                    plan = game.wipe_plan(prof, scope)
                    st.detail = (f"{len(plan.files)} items; kept: {', '.join(plan.keep)}" if plan.keep
                                 else f"{len(plan.files)} items")
                async with ctx.step("Backup before wipe (always)"):
                    await run_blocking(self.backups.create, prof, f"before {scope} wipe", ctx.log, kind="pre_wipe")
                async with ctx.step(f"Wipe ({scope})"):
                    await run_blocking(self.backups.wipe, prof, scope, ctx.log)
                if new_seed is not None:
                    async with ctx.step(f"Set new map seed {new_seed}"):
                        prof.map.seed = int(new_seed)
                        self.store.save_profile(prof)
                self.store.update_runtime(profile_id, last_wipe={"scope": scope, "at": iso(utcnow()),
                                                                 "seed": prof.map.seed})
            finally:
                self._busy(sup, None)
            if was_running:
                async with ctx.step("Start the server again"):
                    await sup.start()
        return self.ops.submit(profile_id, "wipe", run, {"scope": scope, "new_seed": new_seed, "backup": True})

    def wipe_plan_view(self, profile_id: str, scope: str) -> dict[str, Any]:
        """Exactly what a wipe of this scope would remove and keep, for the confirm dialog (nothing is changed)."""
        if scope not in ("map", "blueprints", "full"):
            raise OpError("scope must be map, blueprints or full", "bad_request")
        prof = self.require_profile(profile_id)
        try:
            plan = get_game(prof.game).wipe_plan(prof, scope)
        except ValueError as exc:
            raise OpError(str(exc), "bad_request") from exc
        return plan.as_dict()

    def run_scheduled(self, s: Schedule, catch_up: bool = False) -> Operation | None:
        """Called by the scheduler when an occurrence is due. Enqueues the matching operation."""
        if self.store.get_profile(s.profile_id) is None:
            return None
        if self.state in (STOPPING, EXITED):
            return None                                   # shutting down: schedules never start anything now
        sup = self.supervisor(s.profile_id)
        self.console(s.profile_id).append("system", f"Schedule '{s.label or s.action}' is due"
                                                    f"{' (catching up a missed run)' if catch_up else ''}.")
        # The scheduler already warned players ahead of the due time (its own warnings list), so the action runs
        # now; warned_until tells a countdown which warnings were already given, so none is repeated.
        warned = self.scheduler.warned_until(s.id, s.next_utc)
        if s.action == "restart":
            if not sup.alive:
                self.console(s.profile_id).append("system", "Scheduled restart skipped: the server is not running.")
                return None
            return self.submit_restart(s.profile_id, warn_s=0, warned_until=warned)
        if s.action == "update":
            return self.submit_install(s.profile_id, validate=True, kind="update", warned_until=warned)
        if s.action == "backup":
            return self.submit_backup(s.profile_id, **backup_request(s))  # type: ignore[arg-type]
        scope = {"wipe_map": "map", "wipe_full": "full", "wipe_blueprints": "blueprints"}[s.action]
        seed = None
        if s.seed_rotation:
            seed = secrets.randbelow(2_000_000_000) + 1
        return self.submit_wipe(s.profile_id, scope, seed)

    # ================================================================================================
    # RCON-backed actions
    # ================================================================================================
    async def command(self, profile_id: str, command: str, echo: bool = True) -> dict[str, Any]:
        self.require_profile(profile_id)
        sup = self.supervisor(profile_id)
        if not sup.alive or sup.rcon is None or sup.rcon.state != "ready":
            raise OpError("RCON is not connected (the server is stopped or still starting)", "rcon_unavailable")
        # The engine is the ONE writer of the "> command" + reply lines in the console. The response lists their
        # seq numbers (console_seqs) so the UI can show them once instead of adding its own copy beside them.
        written: list[int] = []

        def put(text: str) -> None:
            line = self.console(profile_id).append("rcon", text)
            if line is not None:
                written.append(line.seq)

        if echo:
            put(f"> {command}")
        try:
            reply = await sup.rcon.command(command, timeout=10)
        except (RconUnavailable, asyncio.TimeoutError) as exc:
            raise OpError(f"no reply over RCON: {exc or 'timed out'}", "rcon_unavailable") from exc
        if echo and reply.text:
            for ln in reply.text.splitlines():
                put(ln)
        return {"identifier": reply.identifier, "reply": reply.text, "at": reply.at, "console_seqs": written}

    async def map_png(self, profile_id: str) -> Path:
        """The island picture for this profile's current map (WP17).

        1. If <install>/map_<size>_<seed>.png already exists, use it (one picture per seed, so it is drawn once).
           The served file is the island crop (`_island.png`, see mapcrop.py): the raw render is mostly ocean.
        2. Else, if the server is running with RCON ready, send `world.rendermap` (about 5 s on a 1000 m map) and
           wait up to map_render_timeout_s for the file.
        3. Else raise a plain-English 404.
        Never asks the server to draw more than once per map_render_cooldown_s per profile (rendering is heavy).
        """
        prof = self.require_profile(profile_id)
        game = get_game(prof.game)
        root = Path(os.path.realpath(prof.install_root))
        expected = game.map_render_path(prof)
        if expected is not None and await _picture_ready(expected):
            return await asyncio.to_thread(crop_island, expected)
        if not game.map_render_command:
            raise OpError("This game cannot draw a map picture.", "no_map_picture")
        sup = self.supervisor(profile_id)
        if not sup.alive or sup.rcon is None or sup.rcon.state != "ready":
            raise OpError("There is no picture of this island yet. Start the server and open the map again: "
                          "the Bunker asks the running game to draw it.", "no_map_picture")
        lock = self._map_locks.setdefault(profile_id, asyncio.Lock())
        async with lock:                          # two windows asking at once = still one render
            if expected is not None and await _picture_ready(expected):
                return await asyncio.to_thread(crop_island, expected)
            last = self._map_render_at.get(profile_id)
            now = time.monotonic()
            if last is not None and now - last < self.map_render_cooldown_s:
                wait = int(self.map_render_cooldown_s - (now - last)) + 1
                raise OpError(f"The island was drawn less than a minute ago but no picture appeared. "
                              f"Try again in {wait} s.", "render_cooldown", {"retry_after_s": wait})
            self._map_render_at[profile_id] = now
            self.console(profile_id).append("system", f"Drawing the island picture ({game.map_render_command})...")
            loop = asyncio.get_running_loop()
            deadline = loop.time() + self.map_render_timeout_s
            target = expected
            try:
                reply = await sup.rcon.command(game.map_render_command, timeout=self.map_render_timeout_s,
                                               quiet_s=0.3)
                named = game.parse_map_render_reply(reply.text)
                if named:
                    cand = Path(os.path.realpath(named))
                    # only ever serve a .png inside this server's own folder
                    if cand.suffix.lower() == ".png" and cand.parent == root:
                        target = cand
            except (RconUnavailable, RconBusy, asyncio.TimeoutError):
                pass                              # the file may still appear; keep watching for it below
            while target is not None and loop.time() < deadline:
                if await _picture_ready(target):
                    return await asyncio.to_thread(crop_island, target)
                await asyncio.sleep(0.25)
            raise OpError(f"The server did not finish drawing the island within {self.map_render_timeout_s:g} s.",
                          "render_timeout")

    async def kick(self, profile_id: str, steamid: str, reason: str) -> dict[str, Any]:
        Admin(steamid64=steamid)
        return await self.command(profile_id, f'kick {steamid} "{_q(reason) or "Kicked"}"')

    async def ban(self, profile_id: str, steamid: str, reason: str, duration_s: int | None) -> dict[str, Any]:
        """banid <steamid> "<name>" "<reason>" [<N>s] - duration suffix 's' = seconds (decompiled Arg.GetTimestamp)."""
        Admin(steamid64=steamid)
        sup = self.supervisor(profile_id)
        name = next((p.name for p in (sup.players or []) if p.steamid64 == steamid), "unnamed")
        cmd = f'banid {steamid} "{_q(name)}" "{_q(reason) or "Banned"}"'
        if duration_s:
            cmd += f" {int(duration_s)}s"
        return await self.command(profile_id, cmd)

    async def set_admins(self, profile_id: str, admins: list[Admin]) -> Profile:
        prof = self.require_profile(profile_id)
        old = {a.steamid64: a for a in prof.admins}
        prof.admins = admins
        self.store.save_profile(prof)
        sup = self.supervisor(profile_id)
        if sup.alive and sup.rcon and sup.rcon.state == "ready":
            new = {a.steamid64: a for a in admins}
            for sid, a in old.items():
                if sid not in new or new[sid].role != a.role:
                    await self.command(profile_id, f"{'removeowner' if a.role == 'owner' else 'removemoderator'} {sid}")
            for sid, a in new.items():
                if sid not in old or old[sid].role != a.role:
                    await self.command(profile_id, f'{"ownerid" if a.role == "owner" else "moderatorid"} {sid} '
                                                   f'"{_q(a.name)}" "added by HoneyBadger Bunker"')
            await self.command(profile_id, "server.writecfg")
        else:
            sup.write_configs(prof)
        return prof

    # ================================================================================================
    # convars
    # ================================================================================================
    def convars(self, profile_id: str) -> list[dict[str, Any]]:
        prof = self.require_profile(profile_id)
        game = get_game(prof.game)
        cfg_vals = self._server_cfg_values(prof)
        always = {k for k, v in game.server_cfg_values(prof).items() if v is not None and k not in prof.managed_convars}
        out = []
        for spec in game.convar_catalog():
            if spec.profile_field:
                value = str(getattr(prof, spec.profile_field))
                if isinstance(getattr(prof, spec.profile_field), bool):
                    value = "true" if getattr(prof, spec.profile_field) else "false"
            elif spec.name in prof.managed_convars:
                value = prof.managed_convars[spec.name]
            elif spec.name in ("server.level", "server.seed", "server.worldsize", "server.levelurl"):
                value = {"server.level": "Barren" if prof.map.kind == "barren" else "Procedural Map",
                         "server.seed": str(prof.map.seed), "server.worldsize": str(prof.map.size),
                         "server.levelurl": prof.map.custom_url or ""}[spec.name]
            else:
                value = cfg_vals.get(spec.name, spec.default)
            row = spec.describe(value)
            # removable = "Use default" may take the line out of server.cfg (PUT null). Lines the Bunker always
            # writes (name, slots, map, ...) are not removable: null puts them back to the catalog default instead.
            row["removable"] = not (spec.profile_field or spec.name in always)
            out.append(row)
        return out

    @staticmethod
    def convar_catalog(game_id: str = "rust") -> list[dict[str, Any]]:
        """The option catalog with defaults only (the wizard uses it before any profile exists)."""
        return [spec.describe() for spec in get_game(game_id).convar_catalog()]

    def _server_cfg_values(self, prof: Profile) -> dict[str, str]:
        from .profiles import parse_cfg_line
        path = get_game(prof.game).identity_dir(prof) / "cfg" / "server.cfg"
        vals: dict[str, str] = {}
        if path.exists():
            for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
                parsed = parse_cfg_line(raw)
                if parsed:
                    vals.setdefault(parsed[0], parsed[1])
        return vals

    async def set_convars(self, profile_id: str, changes: dict[str, Any]) -> dict[str, Any]:
        """Validate, store, write server.cfg, and apply live ones over RCON. Returns what happened.

        The body is ONE flat object {convar name: value}. Rules (WP41, "a wrong request cannot pollute server.cfg"):
        - a name that is not in the catalog is refused (422 unknown_convar) unless the body also carries
          "advanced": true AND the name looks like a real Rust convar (section.name, lower case, no spaces,
          braces or quotes);
        - a value of null means REMOVE: the key leaves the profile and its line leaves server.cfg, so the game's
          own default applies after the next start. Options the Bunker always writes (server name, map, tick
          rate, ...) cannot be removed: null puts them back to the catalog default instead;
        - an empty string is only a real value for text options; numbers and switches refuse it;
        - values must be text, a number or true/false: never an object or list (no Python text ever lands in
          the file).
        """
        from .games.rust_catalog import CATALOG_BY_NAME
        prof = self.require_profile(profile_id)
        changes = dict(changes)
        advanced = changes.pop("advanced", False)
        if not isinstance(advanced, bool):
            raise OpError("'advanced' must be true or false", "invalid_value", {"errors": {"advanced": "not a boolean"}})
        always_written = {k for k, v in get_game(prof.game).server_cfg_values(prof).items()
                          if v is not None and k not in prof.managed_convars}
        applied_live: list[str] = []
        needs_restart: list[str] = []
        errors: dict[str, str] = {}
        unknown: list[str] = []
        clean: dict[str, str] = {}
        remove: list[str] = []          # keys whose line leaves server.cfg
        reset: list[str] = []           # always-written keys put back to the catalog default
        for name, value in changes.items():
            key = str(name).strip().lower()
            spec = CATALOG_BY_NAME.get(key)
            if value is None:
                # Removing is always allowed for a key the profile holds, even a junk one: that is the clean-up path.
                if spec is not None and (spec.profile_field or key in always_written):
                    try:
                        clean[key] = spec.validate(spec.default)
                        reset.append(key)
                    except ValueError as exc:
                        errors[key] = str(exc)
                elif spec is not None or key in prof.managed_convars:
                    remove.append(key)
                elif advanced and ADVANCED_CONVAR_RE.match(key):
                    remove.append(key)       # an advanced line the profile never held: removing it is harmless
                else:
                    unknown.append(key)
                continue
            if spec is None and not (advanced and ADVANCED_CONVAR_RE.match(key)):
                unknown.append(key)          # not an option, whatever its value is
                continue
            if isinstance(value, (dict, list, tuple, set)):
                errors[key] = f"{key}: expected text, a number or true/false"
                continue
            if isinstance(value, bool):
                value = "true" if value else "false"
            try:
                if spec is not None:
                    if str(value).strip() == "" and spec.kind != "string":
                        raise ValueError(f"{spec.label}: cannot be empty (send null to remove it instead)")
                    clean[key] = spec.validate(value)
                else:
                    if not advanced or not ADVANCED_CONVAR_RE.match(key):
                        unknown.append(key)
                        continue
                    if key.startswith("rcon.") or key in always_written or key == "server.identity":
                        raise ValueError(f"'{key}' is written by the Bunker itself and cannot be set here")
                    text = str(value).strip()
                    if text == "":
                        raise ValueError(f"{key}: cannot be empty (send null to remove it instead)")
                    if any(c in text for c in '\r\n"{}'):
                        raise ValueError(f"{key}: line breaks, double quotes and braces are not allowed")
                    clean[key] = text
            except ValueError as exc:
                errors[key] = str(exc)
        if unknown:
            raise OpError("these are not options the Bunker knows: " + ", ".join(sorted(unknown)), "unknown_convar",
                          {"unknown": sorted(unknown), "errors": {k: "not in the option catalog" for k in unknown}})
        if errors:
            raise OpError("some values were not accepted", "invalid_value", {"errors": errors})
        data = prof.model_dump()
        for key, val in clean.items():
            spec = CATALOG_BY_NAME.get(key)
            if spec and spec.profile_field:
                cur = data[spec.profile_field]
                data[spec.profile_field] = (val == "true") if isinstance(cur, bool) else type(cur)(val)
            elif key == "server.seed":
                data["map"]["seed"] = int(val)
            elif key == "server.worldsize":
                data["map"]["size"] = int(val)
            elif key == "server.level":
                data["map"]["kind"] = "barren" if val.lower() == "barren" else "procedural"
            elif key == "server.levelurl":
                data["map"]["kind"] = "custom" if val else "procedural"
                data["map"]["custom_url"] = val or None
            else:
                data["managed_convars"][key] = val
        for key in remove:
            data["managed_convars"].pop(key, None)
        prof = Profile.model_validate(data)
        self.store.save_profile(prof)
        sup = self.supervisor(profile_id)
        if remove:
            sup.write_configs(prof, remove=remove)
        else:
            sup.write_configs(prof)
        for key, val in clean.items():
            spec = CATALOG_BY_NAME.get(key)
            live = spec.live if spec else True
            if sup.alive and live and sup.rcon and sup.rcon.state == "ready":
                try:
                    await sup.rcon.command(f'{key} "{val}"', timeout=5, quiet_s=0.05)
                    applied_live.append(key)
                except (RconUnavailable, asyncio.TimeoutError):
                    needs_restart.append(key)
            elif sup.alive:
                needs_restart.append(key)
        if applied_live:
            self.console(profile_id).append("system", f"Applied live: {', '.join(applied_live)}")
        if remove and sup.alive:
            needs_restart.extend(k for k in remove if k not in needs_restart)   # the game's default needs a start
        return {"saved": sorted(clean), "removed": sorted(remove), "reset_to_default": sorted(reset),
                "applied_live": applied_live, "restart_required": needs_restart}

    def server_cfg_view(self, profile_id: str) -> dict[str, Any]:
        prof = self.require_profile(profile_id)
        game = get_game(prof.game)
        path = game.identity_dir(prof) / "cfg" / "server.cfg"
        text = path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""
        managed_keys = [k for k, v in game.server_cfg_values(prof).items() if v is not None]
        managed, unmanaged = split_cfg(text, managed_keys)
        # Every real line (not blank, not a comment) the Bunker does not write, exactly as it is in the file,
        # including lines that are not even a valid setting. The Options screen shows them with a note.
        keys = {k.lower() for k in managed_keys} | {"rcon.password"}
        unmanaged_lines = [raw for raw in text.splitlines()
                           if raw.strip() and not raw.strip().startswith(("//", "#"))
                           and raw.split()[0].lower() not in keys]
        return {"path": str(path), "text": text, "managed": managed, "unmanaged": unmanaged,
                "unmanaged_lines": unmanaged_lines}

    # ================================================================================================
    # plugins
    # ================================================================================================
    def _plugin_dirs(self, prof: Profile) -> tuple[str, Path, Path]:
        fw = detect_framework(Path(prof.install_root)) or prof.framework
        dirs = self.frameworks.plugin_dirs(fw, Path(prof.install_root))
        if dirs is None:
            raise OpError("this server runs vanilla Rust: install Carbon or Oxide to use plugins", "no_framework")
        return fw, dirs[0], dirs[1]

    async def plugins(self, profile_id: str) -> list[PluginInfo]:
        prof = self.require_profile(profile_id)
        try:
            fw, on_dir, off_dir = self._plugin_dirs(prof)
        except OpError:
            return []
        records = {r["filename"].lower(): r for r in self.store.list_plugin_records(profile_id)}
        sup = self.supervisor(profile_id)
        loaded_titles: set[str] | None = None
        if sup.alive and sup.state == "running":
            live = await sup.loaded_plugins_via_rcon() if fw == "carbon" else None
            loaded_titles = {p["title"] for p in live} if live is not None else set(sup.loaded_plugins)
        out: list[PluginInfo] = []
        for folder, enabled in ((on_dir, True), (off_dir, False)):
            if not folder.exists():
                continue
            for f in sorted(folder.glob("*.cs")):
                title, version = f.stem, None
                try:
                    m = PLUGIN_INFO_RE.search(f.read_text(encoding="utf-8", errors="replace")[:200_000])
                    if m:
                        title, version = m.group("title"), m.group("version")
                except OSError:
                    pass
                rec = records.get(f.name.lower(), {})
                loaded = None
                if loaded_titles is not None:
                    loaded = enabled and title in loaded_titles
                out.append(PluginInfo(id=f.stem.lower(), filename=f.name, title=title, version=version,
                                      source=rec.get("source", "user"), enabled=enabled, loaded=loaded, framework=fw))
        return out

    def install_plugin_file(self, profile_id: str, filename: str, content: bytes, source: str = "upload") -> PluginInfo:
        prof = self.require_profile(profile_id)
        if not PLUGIN_FILE_RE.match(filename):
            raise OpError("plugin files must be named like MyPlugin.cs (letters, digits, _)", "bad_filename")
        if len(content) > 4 << 20:
            raise OpError("plugin file is larger than 4 MB", "too_large")
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise OpError("plugin file is not UTF-8 text", "bad_plugin") from exc
        fw, on_dir, off_dir = self._plugin_dirs(prof)
        (off_dir / filename).unlink(missing_ok=True)
        atomic_write(on_dir / filename, text)
        import hashlib
        self.store.save_plugin_record(profile_id, {"id": f"{profile_id}:{Path(filename).stem.lower()}",
                                                   "filename": filename, "source": source,
                                                   "sha256": hashlib.sha256(content).hexdigest(),
                                                   "installed_at": iso(utcnow())})
        self.console(profile_id).append("system", f"Plugin {filename} installed ({source}); {fw} loads it automatically.")
        m = PLUGIN_INFO_RE.search(text)
        return PluginInfo(id=Path(filename).stem.lower(), filename=filename, title=m.group("title") if m else Path(filename).stem,
                          version=m.group("version") if m else None, source=source, enabled=True, loaded=None, framework=fw)

    def submit_catalog_plugin(self, profile_id: str, catalog_id: str) -> Operation:
        self.require_profile(profile_id)

        async def run(ctx: OpContext) -> None:
            entry = next((p for p in self.updates.catalog()["plugins"] if p.get("id") == catalog_id), None)
            if entry is None:
                raise OpError(f"'{catalog_id}' is not in the verified catalog", "not_found")
            art = self.updates.artifact(entry.get("artifact", ""))
            if art is None:
                raise OpError("catalog entry has no downloadable artifact", "not_downloadable")
            async with ctx.step(f"Download {entry.get('title')} {entry.get('version')} (sha256 checked)"):
                dest = self.data_dir / "cache" / "plugins" / art["filename"]
                try:
                    await self.updates.download_artifact(art, dest)
                except ManifestError as exc:
                    raise OpError(str(exc), "untrusted") from exc
            async with ctx.step("Install into the plugins folder"):
                self.install_plugin_file(profile_id, entry["filename"], dest.read_bytes(), source="catalog")
        return self.ops.submit(profile_id, "plugin", run, {"catalog_id": catalog_id})

    def _find_plugin(self, prof: Profile, plugin_id: str) -> tuple[Path | None, bool, str, Path, Path]:
        fw, on_dir, off_dir = self._plugin_dirs(prof)
        for folder, enabled in ((on_dir, True), (off_dir, False)):
            if folder.exists():
                for f in folder.glob("*.cs"):
                    if f.stem.lower() == plugin_id.lower():
                        return f, enabled, fw, on_dir, off_dir
        return None, False, fw, on_dir, off_dir

    async def plugin_action(self, profile_id: str, plugin_id: str, action: str) -> dict[str, Any]:
        prof = self.require_profile(profile_id)
        f, enabled, fw, on_dir, off_dir = self._find_plugin(prof, plugin_id)
        if f is None:
            raise OpError("plugin not found", "not_found")
        if action == "enable" and not enabled:
            on_dir.mkdir(parents=True, exist_ok=True)
            os.replace(f, on_dir / f.name)
        elif action == "disable" and enabled:
            off_dir.mkdir(parents=True, exist_ok=True)
            os.replace(f, off_dir / f.name)
        elif action == "reload":
            cmd = f"c.reload {f.stem}" if fw == "carbon" else f"oxide.reload {f.stem}"
            return await self.command(profile_id, cmd)
        elif action == "delete":
            f.unlink()
            self.store.delete_plugin_record(f"{profile_id}:{f.stem.lower()}")
        self.console(profile_id).append("system", f"Plugin {f.name}: {action}")
        return {"ok": True, "plugin": plugin_id, "action": action}

    # ================================================================================================
    # schedules
    # ================================================================================================
    def save_schedule(self, profile_id: str, body: ScheduleIn, sid: str | None = None) -> Schedule:
        self.require_profile(profile_id)
        s = Schedule(**body.model_dump(), profile_id=profile_id, **({"id": sid} if sid else {}))
        self.scheduler.refresh(s)
        return self.store.save_schedule(s)

    def build_id(self, profile_id: str) -> str | None:
        p = self.require_profile(profile_id)
        return read_build_id(Path(p.install_root), get_game(p.game).app_id)

    def ports_auto(self) -> Ports:
        return pick_ports(self.store.list_profiles(), probe=probe_free)


async def _picture_ready(path: Path) -> bool:
    """True when the picture file exists, is not empty and is not still growing (size steady over 0.1 s)."""
    try:
        first = path.stat().st_size
        if first <= 0:
            return False
        await asyncio.sleep(0.1)
        return path.stat().st_size == first
    except OSError:
        return False


def resolve_launcher_path(data_dir: Path, os_name: str) -> str | None:
    """The Windows launcher a "start when I sign in" shortcut should run, or None.

    Only `HoneyBadger Bunker.bat` in this app's own folder, and only when THIS engine's data folder is the one that
    launcher uses (its `state` folder next to it): otherwise the shortcut would open a different Deck. Linux runs as
    a service, so there is no launcher there.
    """
    if os_name != "windows":
        return None
    root = Path(__file__).resolve().parents[1]
    bat = root / "HoneyBadger Bunker.bat"
    try:
        if bat.is_file() and canonical_path(root / "state") == canonical_path(Path(data_dir)):
            return str(bat)
    except OSError:
        return None
    return None


def _q(text: str) -> str:
    """Make free text safe inside a quoted console argument."""
    return (text or "").replace('"', "'").replace("\n", " ").replace("\r", " ")[:200]


def lan_ip() -> str | None:
    """This PC's LAN address (UDP 'connect' sends no packets; it only asks the OS which interface it would use)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("192.0.2.1", 9))
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return None
