"""Shared contract for the basics bundle (28 Oct 2026): every NEW field the engine sends the UI.

Source of truth for the names: docs/team/basics/BASICS_PLAN_2026-10-28.md, section "Shared seams", and the
"Shared seams" block of docs/team/basics/codex_basics_design_2026-10-28.md. ui/src/types.ts mirrors these names
one-for-one, so a rename here must be made there too (tests/test_contract.py checks the TypeScript side).

The one rule that matters (plain English):
    Anything the engine has not OBSERVED is unknown, and unknown is None (JSON null).
    Never 0, never [] and never "" in place of "we do not know", and never "up to date" when a check failed.

How the pieces get used:
- The Network builder (hbdeck/network.py), the Maintenance builder (server_updates.py, countdown.py, rcon.py) and
  hbdeck/housekeeping.py return PLAIN DICTS with these field names. Validate them with the models below
  (Model.model_validate(d)) in tests, or at the API edge.
- Until every producer is wired in, the integrator merges STATUS_DEFAULTS into GET /profiles/{pid}/status (and into
  the WebSocket "status" frame, which uses the same serializer), ENGINE_DEFAULTS into GET /engine, and
  CONNECT_DEFAULTS into GET /profiles/{pid}/connect, with merge_defaults(). So every field always exists, and the
  ones nobody has produced yet say "unknown" (null) instead of being missing.
"""
from __future__ import annotations

import copy
import re
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

# ---------------------------------------------------------------------------------------------------------------
# Small shared pieces
# ---------------------------------------------------------------------------------------------------------------

#: Disk thresholds (bytes). The UI formats them as GB with the same 1024 base as ui/src/format.ts bytes().
#: They are WARNING lines, not guaranteed requirements: a Rust install is about 15 GB on disk and grows with updates.
DISK_WARN_BYTES = 20 * 1024 ** 3     # under 20 GB free -> amber lamp ("getting low")
DISK_LOW_BYTES = 5 * 1024 ** 3       # under 5 GB free  -> red lamp ("an update or backup may fail")

STEAMID64_RE = re.compile(r"^7656\d{13}$")   # every Steam account id is 17 digits starting 7656


class _Model(BaseModel):
    """Base for every contract model: extra keys from a newer producer are kept, not thrown away."""
    model_config = ConfigDict(extra="allow")


DiskLevel = Literal["ok", "warn", "low"]


def disk_level(free_bytes: int | None, warn_bytes: int = DISK_WARN_BYTES,
               low_bytes: int = DISK_LOW_BYTES) -> DiskLevel | None:
    """'ok' / 'warn' / 'low' for a free-space reading; None when the free space is unknown."""
    if free_bytes is None:
        return None
    if free_bytes < low_bytes:
        return "low"
    if free_bytes < warn_bytes:
        return "warn"
    return "ok"


class DiskInfo(_Model):
    """Free space on the volume that holds `path`. Bytes. Unknown = None (never 0)."""
    path: str | None = None                  # the folder asked about (may not exist yet, e.g. a new install folder)
    free_bytes: int | None = None
    total_bytes: int | None = None
    checked_at: str | None = None            # ISO UTC
    error: str | None = None                 # plain English, when the reading failed
    # additions (housekeeping.disk_info fills them; older producers may leave them out):
    probed_path: str | None = None           # the nearest existing parent folder that was actually measured
    volume: str | None = None                # what identifies the volume ("C:\\", or "dev:2049" on Linux)
    level: DiskLevel | None = None           # disk_level(free_bytes) with the thresholds below
    warn_below_bytes: int = DISK_WARN_BYTES
    low_below_bytes: int = DISK_LOW_BYTES

    @model_validator(mode="after")
    def _fill_level(self) -> "DiskInfo":
        if self.level is None and self.free_bytes is not None:
            self.level = disk_level(self.free_bytes, self.warn_below_bytes, self.low_below_bytes)
        return self


class UpdateInfo(_Model):
    """One "is there a newer build?" fact. Build ids are STRINGS. A failed check never says available=False."""
    installed: str | None = None             # build id on disk (appmanifest), None = unknown
    latest: str | None = None                # newest build id the source reported, None = unknown
    available: bool | None = None            # None = unknown (no check yet, or the check failed)
    source: str | None = None                # e.g. "steamcmd.net (third party)", "steamcmd app_info_print", "github"
    checked_at: str | None = None
    stale: bool = False                      # True = this is an older cached answer (the latest check failed)
    error: str | None = None
    installed_revision: str | None = None    # framework: release id / asset digest we installed
    latest_revision: str | None = None       # framework: release id / asset digest the source reports now


Compatibility = Literal["confirmed", "incompatible", "unknown"]


class FrameworkUpdateInfo(UpdateInfo):
    """A framework (Carbon/Oxide) release, plus whether it is known to work with this Rust build."""
    compatibility: Compatibility = "unknown"
    compatibility_reason: str | None = None


class FrameworkHealth(_Model):
    """Expected vs detected framework. DLL presence alone is NOT health (frameworks.py:47)."""
    expected: str | None = None              # what the profile asks for: "carbon" | "oxide" | "vanilla"
    detected: str | None = None              # what is on disk, None = nothing found / unknown
    state: Literal["ok", "missing", "mismatch", "unknown"] = "unknown"
    runtime_verified: bool = False           # True only when the running server's own log/command proved it loaded
    reason: str | None = None


class MaintenanceFailure(_Model):
    """The last failed maintenance job, kept separate from the process state (a failed update may leave the old
    files installed and the server stopped: that is NOT "not installed")."""
    operation_id: str
    kind: Literal["install", "update", "verify", "framework"]
    code: str
    message: str
    at: str
    log_id: str | None = None


class ProfileStorage(_Model):
    install: DiskInfo = Field(default_factory=DiskInfo)
    backups: DiskInfo = Field(default_factory=DiskInfo)


class EngineStorage(_Model):
    servers: DiskInfo = Field(default_factory=DiskInfo)
    backups: DiskInfo = Field(default_factory=DiskInfo)


# ---------------------------------------------------------------------------------------------------------------
# GET /engine additions
# ---------------------------------------------------------------------------------------------------------------

class EngineCapabilities(_Model):
    """What this engine can do on this machine. False = not offered here (the UI hides or explains the control)."""
    reveal_folders: bool = False             # True on Windows desktop; headless Linux only returns paths
    windows_firewall: bool = False
    login_startup: bool = False
    systemd_status: bool = False


class ServiceInfo(_Model):
    """`systemctl is-active` / `is-enabled` for the Linux unit. GET /engine sends null on Windows."""
    unit: str
    active: str | None = None                # systemctl's own word: active / inactive / failed / activating ...
    enabled: str | None = None               # enabled / disabled / static / masked ...
    checked_at: str | None = None
    error: str | None = None
    supported: bool = True                   # False = no systemd here (GET /engine/service still answers)


class LoginStartup(_Model):
    """Per-user "Start HoneyBadger Bunker when I sign in" (a Startup-folder shortcut). Not "at boot"."""
    supported: bool = False
    enabled: bool | None = None              # None = could not tell
    mechanism: Literal["startup_shortcut"] | None = None
    error: str | None = None
    path: str | None = None                  # the shortcut file, when known


class EngineExtras(_Model):
    """Everything the basics bundle adds to GET /engine."""
    capabilities: EngineCapabilities = Field(default_factory=EngineCapabilities)
    service: ServiceInfo | None = None
    login_startup: LoginStartup = Field(default_factory=LoginStartup)
    storage: EngineStorage = Field(default_factory=EngineStorage)


# ---------------------------------------------------------------------------------------------------------------
# GET /profiles/{pid}/status additions
# ---------------------------------------------------------------------------------------------------------------

class StatusExtras(_Model):
    """Everything the basics bundle adds to GET /profiles/{pid}/status (and the WS status frame)."""
    rust_update: UpdateInfo = Field(default_factory=UpdateInfo)
    framework_update: FrameworkUpdateInfo = Field(default_factory=FrameworkUpdateInfo)
    framework_health: FrameworkHealth = Field(default_factory=FrameworkHealth)
    maintenance_failure: MaintenanceFailure | None = None
    storage: ProfileStorage = Field(default_factory=ProfileStorage)
    last_update_duration_s: float | None = None


# ---------------------------------------------------------------------------------------------------------------
# GET /profiles/{pid}/connect (Network builder fills it)
# ---------------------------------------------------------------------------------------------------------------

class PublicAddress(_Model):
    detected_ip: str | None = None           # what api.ipify.org (or the icanhazip fallback) said
    configured_address: str | None = None    # the user's manual override (a DNS name or IP), None = not set
    source: Literal["ipify", "icanhazip"] | None = None
    checked_at: str | None = None
    stale: bool = False                      # True = previous value kept because the latest lookup failed
    error: str | None = None


class Forwarding(_Model):
    """One router forwarding line. RCON is NEVER listed (never forward RCON)."""
    role: Literal["game", "query", "app"]    # "app" = Rust+ (TCP), only when Rust+ is on
    protocol: Literal["udp", "tcp"] = "udp"
    port: int = Field(ge=1, le=65535)

    @model_validator(mode="after")
    def _protocol_matches_role(self) -> "Forwarding":
        if self.role in ("game", "query") and self.protocol != "udp":
            raise ValueError("game and query forwarding are UDP")
        return self


class QueryCheck(_Model):
    """One A2S_INFO attempt. Neither scope proves that people outside your network can join."""
    scope: Literal["local", "hairpin"]
    state: Literal["not_checked", "answered", "timeout", "mismatch", "error"] = "not_checked"
    hostname: str | None = None              # the name the server answered with
    checked_at: str | None = None
    error: str | None = None
    target: str | None = None                # "ip:port" that was asked


class FirewallInfo(_Model):
    """Windows Firewall rule for the game/query UDP ports. A rule existing is NOT reachability."""
    state: Literal["unsupported", "unknown", "configured", "missing", "stale"] = "unknown"
    helper_path: str | None = None           # the per-server "Add firewall rule.bat" the engine wrote
    checked_at: str | None = None
    error: str | None = None


class ConnectExtras(_Model):
    """The new GET /profiles/{pid}/connect fields. rcon_password is GONE from this reply (Decision 7)."""
    hostname: str | None = None
    bind_ip: str | None = None
    lan_addresses: list[str] | None = None   # None = could not read the adapters; [] = read, none usable
    selected_lan_ip: str | None = None
    public_address: PublicAddress = Field(default_factory=PublicAddress)
    public_connect_command: str | None = None
    forwarding: list[Forwarding] | None = None
    query_check: list[QueryCheck] = Field(default_factory=lambda: [QueryCheck(scope="local"),
                                                                   QueryCheck(scope="hairpin")])
    external_reachability: Literal["not_tested", "hairpin_answered"] = "not_tested"
    browser_listing: Literal["not_tested"] = "not_tested"
    firewall: FirewallInfo = Field(default_factory=FirewallInfo)
    rcon_password_set: bool | None = None


class ConnectInfo(ConnectExtras):
    """The whole connect reply: the ordinary fields kept for older screens plus ConnectExtras."""
    lan_ip: str | None = None
    wan_ip: str | None = None
    game_port: int
    connect_command: str
    local_connect_command: str | None = None
    rcon_port: int

    @model_validator(mode="before")
    @classmethod
    def _no_secret(cls, data: Any) -> Any:
        if isinstance(data, dict) and "rcon_password" in data:
            raise ValueError("rcon_password must not be in the connect reply (use POST .../rcon-password/reveal)")
        return data


# ---------------------------------------------------------------------------------------------------------------
# Operation frames (extend the existing Operation, models.py:322; no second job system)
# ---------------------------------------------------------------------------------------------------------------

class OperationProgress(_Model):
    """MEASURED progress for the current step. `kind` names what is being counted (download vs disk)."""
    kind: Literal["download", "disk", "items"]
    done: int | None = None                  # bytes (or items for kind "items"); None = not measured
    total: int | None = None                 # None = total unknown -> the UI shows an indeterminate bar
    rate: float | None = None                # per second, same unit as done; None = not measured
    label: str | None = None                 # e.g. "Rust server files"


class OperationExtras(_Model):
    """New optional fields on an Operation / operation frame. An older frame without them is still valid."""
    error_code: str | None = None            # machine code for a failure (e.g. "disk_full", "steamcmd_busy")
    progress: OperationProgress | None = None
    cancellable: bool = False                # True only while the current phase can honour Cancel safely
    log_id: str | None = None                # which log holds the detail (opened via POST .../reveal install_log)


OPERATION_EXTRA_KINDS = ("verify",)          # new operation kind added by this bundle


# ---------------------------------------------------------------------------------------------------------------
# Schedules: the new "backup" action with its own retention
# ---------------------------------------------------------------------------------------------------------------

ScheduleActionExt = Literal["restart", "wipe_map", "wipe_full", "wipe_blueprints", "update", "backup"]
KEEP_NEWEST_DEFAULT = 10


class ScheduleBackupFields(_Model):
    """`action` may now be "backup"; `keep_newest` = how many of THIS schedule's backups to keep.

    Pruning happens only after a successful archive and never touches manual / pre-wipe / pre-restore backups.
    """
    action: ScheduleActionExt = "restart"
    keep_newest: int | None = Field(default=None, ge=1, le=500)

    @model_validator(mode="after")
    def _default_keep(self) -> "ScheduleBackupFields":
        if self.action == "backup" and self.keep_newest is None:
            self.keep_newest = KEEP_NEWEST_DEFAULT
        if self.action != "backup":
            self.keep_newest = None
        return self


#: Countdown warnings (seconds before the action) used by the shared countdown helper.
WARNING_STEPS_S = (300, 60, 10)


class WarnRequest(_Model):
    """Body addition for POST /stop, /restart, /update: how long players get before it happens."""
    warn_s: Literal[0, 60, 300] = 0


# ---------------------------------------------------------------------------------------------------------------
# Players: bans and one-step admin (Maintenance builder's rcon.py returns these shapes as dicts)
# ---------------------------------------------------------------------------------------------------------------

class BanEntry(_Model):
    steamid64: str
    name: str | None = None
    reason: str | None = None
    expires_at: str | None = None            # None = permanent or unknown (see `permanent`)
    permanent: bool | None = None

    @field_validator("steamid64")
    @classmethod
    def _sid(cls, v: str) -> str:
        if not STEAMID64_RE.match(v):
            raise ValueError("a SteamID64 is 17 digits starting with 7656")
        return v


class BanList(_Model):
    """GET /profiles/{pid}/bans. entries None + error = the reply could not be read (NOT an empty list)."""
    entries: list[BanEntry] | None = None
    checked_at: str | None = None
    source: Literal["rcon", "config"] | None = None
    error: str | None = None


class AdminChange(_Model):
    """PUT /profiles/{pid}/players/{sid}/admin and POST .../unban result: saved config vs applied live."""
    steamid64: str
    role: Literal["owner", "moderator"] | None = None
    saved: bool = False                      # written to users.cfg / the profile, survives a restart
    applied: bool | None = None              # the running server accepted it now; None = not running / unknown
    error: str | None = None


class AdminRoleRequest(_Model):
    role: Literal["owner", "moderator"] | None = None


# ---------------------------------------------------------------------------------------------------------------
# Housekeeping requests / replies (hbdeck/api/housekeeping_routes.py)
# ---------------------------------------------------------------------------------------------------------------

RevealTarget = Literal["install", "logs", "backups", "install_log"]


class RevealRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    target: RevealTarget


class RevealResult(_Model):
    target: RevealTarget
    path: str
    opened: bool = False                     # True = a folder window was asked to open on this PC
    available: bool = False                  # False = opening folders is not available here (headless Linux)
    message: str = ""


class ConsoleTail(_Model):
    lines: list[dict[str, Any]]
    requested: int
    returned: int
    redacted: bool = True
    note: str | None = None                  # e.g. "Only 37 lines are held for this server right now."


class StorageCheckRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    path: str = Field(min_length=1, max_length=1024)


class LoginStartupRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    enabled: bool


class OrphanedBackupSet(_Model):
    """GET /backups/orphaned: backups whose profile no longer exists (backups are keyed by profile id)."""
    profile_id: str
    identity: str | None = None
    label: str | None = None
    backups: list[dict[str, Any]] = Field(default_factory=list)


# ---------------------------------------------------------------------------------------------------------------
# Defaults the integrator merges so every field exists with null semantics
# ---------------------------------------------------------------------------------------------------------------

STATUS_DEFAULTS: dict[str, Any] = StatusExtras().model_dump(mode="json")
ENGINE_DEFAULTS: dict[str, Any] = EngineExtras().model_dump(mode="json")
CONNECT_DEFAULTS: dict[str, Any] = ConnectExtras().model_dump(mode="json")
OPERATION_DEFAULTS: dict[str, Any] = OperationExtras().model_dump(mode="json")


def merge_defaults(payload: dict[str, Any], defaults: dict[str, Any]) -> dict[str, Any]:
    """Return `payload` with every key of `defaults` present. Values the producer sent always win; nested dicts are
    filled key by key. The defaults are deep-copied so a caller can never edit the shared constants by accident.

        status = merge_defaults(engine.status(pid).model_dump(mode="json"), STATUS_DEFAULTS)
    """
    out = dict(payload)
    for key, default in defaults.items():
        if key not in out:
            out[key] = copy.deepcopy(default)
        elif isinstance(default, dict) and isinstance(out[key], dict):
            out[key] = merge_defaults(out[key], default)
    return out


__all__ = [
    "DISK_WARN_BYTES", "DISK_LOW_BYTES", "disk_level", "DiskInfo", "UpdateInfo", "FrameworkUpdateInfo",
    "FrameworkHealth", "MaintenanceFailure", "ProfileStorage", "EngineStorage", "EngineCapabilities", "ServiceInfo",
    "LoginStartup", "EngineExtras", "StatusExtras", "PublicAddress", "Forwarding", "QueryCheck", "FirewallInfo",
    "ConnectExtras", "ConnectInfo", "OperationProgress", "OperationExtras", "OPERATION_EXTRA_KINDS",
    "ScheduleBackupFields", "KEEP_NEWEST_DEFAULT", "WARNING_STEPS_S", "WarnRequest", "BanEntry", "BanList",
    "AdminChange", "AdminRoleRequest", "RevealTarget", "RevealRequest", "RevealResult", "ConsoleTail",
    "StorageCheckRequest", "LoginStartupRequest", "OrphanedBackupSet", "STATUS_DEFAULTS", "ENGINE_DEFAULTS",
    "CONNECT_DEFAULTS", "OPERATION_DEFAULTS", "merge_defaults",
]
