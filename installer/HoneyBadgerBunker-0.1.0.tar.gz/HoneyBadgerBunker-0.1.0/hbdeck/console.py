"""Console capture: turn raw program output into numbered lines the UI can show and filter.

Three small pieces:
- LineDecoder: bytes arrive in random-sized chunks; this cuts them into whole lines, copes with Windows (CRLF),
  Linux (LF) and progress-bar style carriage returns (CR alone), strips colour codes, and never crashes on bad bytes.
- ConsoleBuffer: a bounded "ring" of the most recent lines for one profile. Every line gets a sequence number so the
  UI can ask "give me everything after line 1234" and never miss or repeat a line. Old lines fall off the back.
- LogTailer: follows a log file that another program is writing (RustDedicated's own -logfile), like `tail -f`.
"""
from __future__ import annotations

import asyncio
import codecs
import collections
import re
import threading
from pathlib import Path
from typing import Callable, Iterable

from .models import ConsoleLine, iso, utcnow

ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07]*\x07")
ERROR_RE = re.compile(r"(error|exception)\b|\b(failed|fatal)\b", re.IGNORECASE)
WARN_RE = re.compile(r"\bwarn(ing)?\b", re.IGNORECASE)


def classify(text: str) -> str:
    """Guess a display level from the text (only used for colouring and filters, never for decisions)."""
    if text.startswith("[CHAT]") or text.startswith("[TEAM CHAT]"):
        return "info"                    # player chat: never coloured as an error even if it says "error"
    if ERROR_RE.search(text):
        return "error"
    if WARN_RE.search(text):
        return "warn"
    return "info"


class LineDecoder:
    """Incremental bytes -> text lines decoder. Feed chunks with feed(); call flush() at end of stream."""

    def __init__(self, encoding: str = "utf-8") -> None:
        # errors="replace": an invalid byte becomes a visible placeholder instead of an exception.
        self._dec = codecs.getincrementaldecoder(encoding)(errors="replace")
        self._buf = ""

    def feed(self, data: bytes) -> list[str]:
        self._buf += self._dec.decode(data)
        return self._split(final=False)

    def flush(self) -> list[str]:
        self._buf += self._dec.decode(b"", final=True)
        return self._split(final=True)

    def _split(self, final: bool) -> list[str]:
        out: list[str] = []
        buf = self._buf
        start = 0
        i = 0
        n = len(buf)
        while i < n:
            ch = buf[i]
            if ch == "\n":
                out.append(buf[start:i])
                start = i + 1
            elif ch == "\r":
                if i + 1 < n:
                    out.append(buf[start:i])
                    start = i + 2 if buf[i + 1] == "\n" else i + 1
                    i = start - 1
                elif final:
                    out.append(buf[start:i])
                    start = i + 1
                else:
                    break                      # wait: the next chunk may start with "\n" (a split CRLF)
            i += 1
        self._buf = buf[start:]
        if final and self._buf:
            out.append(self._buf)
            self._buf = ""
        return [clean(line) for line in out]


def clean(line: str) -> str:
    """Remove colour escape codes and trailing spaces."""
    return ANSI_RE.sub("", line).rstrip()


Listener = Callable[[str, ConsoleLine], None]


class ConsoleBuffer:
    """Bounded per-profile line store with monotonically increasing sequence numbers (thread-safe)."""

    def __init__(self, profile_id: str, maxlen: int = 5000) -> None:
        self.profile_id = profile_id
        self._lines: collections.deque[ConsoleLine] = collections.deque(maxlen=maxlen)
        self._seq = 0
        self._lock = threading.Lock()
        self.listeners: list[Listener] = []

    @property
    def last_seq(self) -> int:
        return self._seq

    def append(self, source: str, text: str, level: str | None = None) -> ConsoleLine | None:
        text = clean(text)
        if not text:
            return None
        with self._lock:
            self._seq += 1
            line = ConsoleLine(seq=self._seq, at=iso(utcnow()) or "", source=source,  # type: ignore[arg-type]
                               level=level or classify(text), text=text)  # type: ignore[arg-type]
            self._lines.append(line)
        for cb in list(self.listeners):
            try:
                cb(self.profile_id, line)
            except Exception:  # noqa: BLE001 - a broken listener must never stop capture
                pass
        return line

    def extend(self, source: str, texts: Iterable[str]) -> None:
        for t in texts:
            self.append(source, t)

    def query(self, after: int = 0, source: str | None = None, limit: int = 500) -> list[ConsoleLine]:
        with self._lock:
            lines = [ln for ln in self._lines if ln.seq > after and (source is None or ln.source == source)]
        return lines[-limit:] if limit else lines


class LogTailer:
    """Follow a file being written by another process, delivering complete lines to `on_line`.

    - Starts at the beginning of the file (it is THIS run's file, created fresh at launch).
    - If the file shrinks (truncated or replaced), it starts again from the top.
    - If the file does not exist yet, it keeps waiting.
    """

    def __init__(self, path: Path, on_line: Callable[[str], None], interval: float = 0.25) -> None:
        self.path = Path(path)
        self.on_line = on_line
        self.interval = interval
        self._offset = 0
        self._decoder = LineDecoder()
        self._stopped = asyncio.Event()

    def poll_once(self) -> int:
        """Read whatever is new right now. Returns the number of lines delivered."""
        try:
            size = self.path.stat().st_size
        except FileNotFoundError:
            return 0
        if size < self._offset:                  # truncated/rotated: start over
            self._offset = 0
            self._decoder = LineDecoder()
        if size == self._offset:
            return 0
        with open(self.path, "rb") as fh:
            fh.seek(self._offset)
            data = fh.read(size - self._offset)
        self._offset += len(data)
        lines = self._decoder.feed(data)
        for ln in lines:
            self.on_line(ln)
        return len(lines)

    async def run(self) -> None:
        while not self._stopped.is_set():
            self.poll_once()
            try:
                await asyncio.wait_for(self._stopped.wait(), self.interval)
            except asyncio.TimeoutError:
                pass
        self.poll_once()                         # final read after stop: catch the last lines
        for ln in self._decoder.flush():
            self.on_line(ln)

    def stop(self) -> None:
        self._stopped.set()
