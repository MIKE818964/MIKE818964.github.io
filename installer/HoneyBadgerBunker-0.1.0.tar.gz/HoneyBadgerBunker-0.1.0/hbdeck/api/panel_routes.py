"""Player panel routes (APIRouter) - the Deck screen's GET/PUT for the in-game HoneyBadger Panel (WP45).

=== WHAT THE INTEGRATOR DOES (hbdeck/api/app.py, inside create_app) =======================================
Add ONE line after the other basics routers and BEFORE `app.include_router(api)`:
    api.include_router(panel_router(PanelAdapter(engine)))
with the import  `from .panel_routes import PanelAdapter, panel_router`.
Mounting on `api` gives these routes the /api/v1 prefix and the Bearer-token check, like network_routes.
==========================================================================================================

Routes (under /profiles/{pid}):
  GET  /panel    the current panel settings, the read-only wipe (from the engine), the join strings (from the
                 engine) and the full panel.json the plugin reads (one source of truth for the live preview).
  PUT  /panel    validate the owner's settings, write panel.json atomically (bump revision), then send `hbp.apply`
                 and confirm. 422 on bad input, 409 when the server has no framework for the panel.

Every outside effect (wipe, connect, RCON, console) comes through the small PanelEngine interface, so the tests
drive these routes with a fake engine and never touch a real server.
"""
from __future__ import annotations

import json
from typing import Any, Protocol

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from .. import playerpanel as pp
from ..operations import OpError


# =================================================================================================================
# The small engine interface these routes need
# =================================================================================================================

class PanelEngine(Protocol):
    """Everything the panel routes ask of the engine. PanelAdapter implements it for the real Engine; the tests
    implement it with a fake."""

    def get_profile(self, pid: str) -> Any | None: ...          # a models.Profile or None
    def forced_wipe(self) -> dict[str, Any]: ...                # wipe_calendar.forced_wipe_info()
    def connect(self, pid: str) -> dict[str, Any]: ...          # network.connect_info() for this profile
    def is_running(self, pid: str) -> bool: ...                 # server process alive with RCON
    async def apply(self, pid: str, revision: int) -> dict[str, Any]: ...   # send hbp.apply + confirm
    @property
    def platform(self) -> Any | None: ...                       # for file permission hardening (optional)


class PanelAdapter:
    """Maps PanelEngine onto the real hbdeck.engine.Engine without changing engine.py."""

    def __init__(self, engine: Any) -> None:
        self.engine = engine

    @property
    def platform(self) -> Any | None:
        return getattr(self.engine, "platform", None)

    def get_profile(self, pid: str) -> Any | None:
        return self.engine.store.get_profile(pid)

    def forced_wipe(self) -> dict[str, Any]:
        from ..wipe_calendar import forced_wipe_info
        return forced_wipe_info()

    def connect(self, pid: str) -> dict[str, Any]:
        # Reuse the Connection page's own builder so the join strings are identical to what the owner sees there.
        from .network_routes import EngineAdapter
        from .. import network as net
        eng = EngineAdapter(self.engine)
        prof = eng.get_profile(pid)
        if prof is None:
            return {}
        cache = net.NetCache.load(eng.kv_get(f"network:{pid}"))
        pub = net.PublicIpCache()
        pub.load(eng.kv_get("network:public_ip"))
        cache.public = pub.snapshot()
        running = eng.is_running(pid)
        status = {"running": running, "busy": eng.busy_reason(pid) is not None, "reason": None}
        return net.connect_info(prof, status, cache, lan=net.lan_addresses(), route_ip=net.os_route_ip(),
                                rcon_password_set=eng.rcon_secret_get(pid) is not None, os_name=eng.os_name)

    def is_running(self, pid: str) -> bool:
        sup = self.engine.supervisors.get(pid)
        return bool(sup and sup.alive and getattr(sup, "rcon", None) and sup.rcon.state == "ready")

    async def apply(self, pid: str, revision: int) -> dict[str, Any]:
        """Send `hbp.apply` over RCON and confirm by tailing the console (the same console the installer tails)."""
        if not self.is_running(pid):
            return pp._pending(revision)
        buf = self.engine.console(pid)
        start = buf.last_seq

        async def send(cmd: str) -> str:
            res = await self.engine.command(pid, cmd)
            return str(res.get("reply") or "")

        def tail() -> list[str]:
            return [ln.text for ln in buf.query(after=start)]

        return await pp.apply_revision(revision, online=True, send=send, tail=tail)


# =================================================================================================================
# Helpers
# =================================================================================================================

def _err(status: int, code: str, message: str, detail: dict[str, Any] | None = None) -> JSONResponse:
    return JSONResponse({"error": {"code": code, "message": message, "detail": detail or {}}}, status_code=status,
                        headers={"Cache-Control": "no-store"})


async def _json_body(request: Request) -> dict[str, Any] | JSONResponse:
    raw = await request.body()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except ValueError:
        return _err(400, "bad_json", "request body is not valid JSON")
    if not isinstance(data, dict):
        return _err(400, "bad_json", "request body must be a JSON object")
    return data


def _view(eng: PanelEngine, pid: str, profile: Any) -> dict[str, Any]:
    """The GET answer: current settings, the read-only wipe + join (from the engine), and the full panel.json."""
    stored = pp.read_panel(profile)
    config = pp.config_from_panel(stored, profile) if stored else pp.default_config(profile)
    revision = pp.current_revision(profile)
    wipe = eng.forced_wipe()
    connect = eng.connect(pid)
    panel = pp.build_panel(profile, forced_wipe=wipe, connect=connect, config=config, revision=revision)
    return {
        "config": config,
        "wipe": wipe,
        "join": {"lan": connect.get("lan_connect_command"), "public": connect.get("public_connect_command")},
        "revision": revision,
        "server_online": eng.is_running(pid),
        "panel": panel,
    }


# =================================================================================================================
# Router
# =================================================================================================================

def panel_router(eng: PanelEngine) -> APIRouter:
    router = APIRouter()

    def not_found() -> JSONResponse:
        return _err(404, "not_found", "no such server profile")

    @router.get("/profiles/{pid}/panel")
    async def get_panel(pid: str) -> Any:
        prof = eng.get_profile(pid)
        if prof is None:
            return not_found()
        try:
            return _view(eng, pid, prof)
        except OpError as exc:
            return _err(409, exc.code, str(exc), getattr(exc, "detail", None))

    @router.put("/profiles/{pid}/panel")
    async def put_panel(pid: str, request: Request) -> Any:
        prof = eng.get_profile(pid)
        if prof is None:
            return not_found()
        body = await _json_body(request)
        if isinstance(body, JSONResponse):
            return body
        try:
            config = pp.validate_config(body)
        except ValueError as exc:
            return _err(422, "invalid_value", str(exc))
        try:
            wipe = eng.forced_wipe()
            connect = eng.connect(pid)
            _panel, revision = pp.write_new_revision(prof, config, forced_wipe=wipe, connect=connect,
                                                     platform=eng.platform)
        except OpError as exc:
            status = {"no_framework": 409, "no_install_root": 409}.get(exc.code, 409)
            return _err(status, exc.code, str(exc), getattr(exc, "detail", None))
        except OSError as exc:
            return _err(500, "write_failed", f"could not write the panel file: {exc}")
        result = await eng.apply(pid, revision)
        out = _view(eng, pid, prof)
        out.update({"applied": bool(result.get("applied")), "apply_message": str(result.get("message", "")),
                    "revision": revision})
        return out

    return router
