"""Housekeeping API routes (basics bundle, section E): open folders, console copy, disk check, start at sign-in,
Linux service status, and the list of backups whose server was removed.

HOW THE INTEGRATOR MOUNTS THIS (one line in hbdeck/api/app.py create_app, next to the other routes, BEFORE
`app.include_router(api)`):

    from .housekeeping_routes import router as housekeeping_router
    api.include_router(housekeeping_router)      # inherits the /api/v1 prefix and the Bearer-token check

WHAT THE ENGINE MUST PROVIDE (read through request.app.state.engine, which create_app already sets):
    engine.require_profile(pid) -> Profile          raises OpError(code="not_found") for an unknown id
    engine.data_dir: Path                           <data>/logs/<identity> and <data>/backups/<profile id> live here
    engine.console(pid).query(after=0, limit=0)     the in-memory console lines (ConsoleBuffer)
    engine.store.get_secret(f"{pid}:rcon")          only used to see whether an RCON password EXISTS
    engine.rcon_password(profile) -> str            the secret, used only to blank it out of the console copy
    engine.store.list_profiles() -> list[Profile]   for GET /backups/orphaned
  optional (getattr with a default, so a missing one degrades honestly):
    engine.launcher_path: str | None                the installed launcher the Startup shortcut should run;
                                                    None -> PUT /engine/login-startup answers 409 launcher_unknown
    engine.service_unit: str = "hbdeck"             the systemd unit name (install.sh --name)

Every error uses the same body as the rest of the API: {"error": {"code", "message", "detail"}}.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from .. import housekeeping as hk
from ..contract import LoginStartupRequest, RevealRequest, StorageCheckRequest
from ..operations import OpError

router = APIRouter()


def _error(status: int, code: str, message: str, detail: dict[str, Any] | None = None) -> JSONResponse:
    """Same shape as app.py error_body (kept local so this module never imports app.py: no import loop)."""
    return JSONResponse({"error": {"code": code, "message": message, "detail": detail or {}}}, status_code=status)


async def _body(request: Request) -> dict[str, Any] | JSONResponse:
    raw = await request.body()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except ValueError:
        return _error(400, "bad_json", "request body is not valid JSON")
    if not isinstance(data, dict):
        return _error(400, "bad_json", "request body must be a JSON object")
    return data


def _invalid(exc: ValidationError) -> JSONResponse:
    errs = [{"field": ".".join(str(x) for x in e.get("loc", [])), "message": e.get("msg", "")} for e in exc.errors()]
    return _error(422, "invalid_request", errs[0]["message"] if errs else "invalid request", {"errors": errs})


def _profile(engine: Any, pid: str) -> Any:
    try:
        return engine.require_profile(pid)
    except OpError as exc:
        if getattr(exc, "code", "") == "not_found":
            return None
        raise


def _not_found() -> JSONResponse:
    return _error(404, "not_found", "no such server profile")


# ----- open a folder ----------------------------------------------------------------------------------------------

@router.post("/profiles/{pid}/reveal")
async def reveal_folder(pid: str, request: Request) -> Any:
    """Body {target: install|logs|backups|install_log}. Never takes a path from the browser."""
    engine = request.app.state.engine
    body = await _body(request)
    if isinstance(body, JSONResponse):
        return body
    try:
        req = RevealRequest.model_validate(body)
    except ValidationError:
        return _error(400, "bad_target", "target must be one of: " + ", ".join(hk.REVEAL_TARGETS),
                      {"allowed": list(hk.REVEAL_TARGETS)})
    prof = _profile(engine, pid)
    if prof is None:
        return _not_found()
    try:
        path = hk.reveal_target(prof, req.target, engine.data_dir)
    except hk.RevealError as exc:
        return _error(exc.status, exc.code, exc.message)
    result = await asyncio.to_thread(hk.reveal, path)
    return {"target": req.target, **result}


# ----- console copy -----------------------------------------------------------------------------------------------

def _redactor(engine: Any, prof: Any):  # noqa: ANN202 - returns the redact function
    """Blank this server's RCON password (only if one exists; never create one just to hide it)."""
    secrets: list[str] = []
    try:
        if engine.store.get_secret(f"{prof.id}:rcon"):
            secrets.append(engine.rcon_password(prof))
    except Exception:  # noqa: BLE001 - redaction must not fail the copy; the pattern rule below still applies
        pass
    return hk.make_redactor(secrets)


@router.get("/profiles/{pid}/console/tail")
async def console_tail(pid: str, request: Request, n: int = hk.CONSOLE_TAIL_MAX) -> Any:
    engine = request.app.state.engine
    prof = _profile(engine, pid)
    if prof is None:
        return _not_found()
    lines = engine.console(pid).query(after=0, limit=0)
    return hk.console_tail(lines, n=n, redact=_redactor(engine, prof))


# ----- engine-level -----------------------------------------------------------------------------------------------

@router.post("/engine/storage/check")
async def storage_check(request: Request) -> Any:
    """Body {path}: free space where a NEW server would go (nearest existing parent). Reads only; creates nothing."""
    body = await _body(request)
    if isinstance(body, JSONResponse):
        return body
    try:
        req = StorageCheckRequest.model_validate(body)
    except ValidationError as exc:
        return _invalid(exc)
    return await asyncio.to_thread(hk.disk_info, req.path)


@router.put("/engine/login-startup")
async def login_startup(request: Request) -> Any:
    """Body {enabled}: the per-user "Start HoneyBadger Bunker when I sign in" shortcut."""
    engine = request.app.state.engine
    body = await _body(request)
    if isinstance(body, JSONResponse):
        return body
    try:
        req = LoginStartupRequest.model_validate(body)
    except ValidationError as exc:
        return _invalid(exc)
    launcher = getattr(engine, "launcher_path", None)
    if req.enabled and not launcher:
        state = await asyncio.to_thread(hk.login_startup_state)
        if state["supported"]:
            return _error(409, "launcher_unknown", "This Bunker was not started from its installed launcher, so it "
                          "does not know what the shortcut should run.", {"login_startup": state})
    result = await asyncio.to_thread(hk.set_login_startup, req.enabled, launcher or "", engine.data_dir)
    return result


@router.get("/engine/service")
async def service(request: Request) -> Any:
    engine = request.app.state.engine
    unit = getattr(engine, "service_unit", None) or hk.DEFAULT_UNIT
    return await asyncio.to_thread(hk.service_status, unit)


# ----- backups whose server was removed ---------------------------------------------------------------------------

def _orphans(data_dir: Path, known_ids: set[str]) -> list[dict[str, Any]]:
    """Backups are stored per profile id (<data>/backups/<id>/, backups.py:38). A folder whose id is not a current
    profile belongs to a removed server; list its backups so they stay reachable."""
    root = Path(data_dir) / "backups"
    out: list[dict[str, Any]] = []
    if not root.is_dir():
        return out
    for d in sorted(root.iterdir()):
        if not d.is_dir() or d.name in known_ids:
            continue
        items: list[dict[str, Any]] = []
        for meta in sorted(d.glob("*.json")):
            try:
                items.append(json.loads(meta.read_text(encoding="utf-8")))
            except (OSError, ValueError):
                continue
        if items:
            items.sort(key=lambda b: str(b.get("id", "")), reverse=True)
            out.append({"profile_id": d.name, "identity": None, "label": items[0].get("label"), "backups": items})
    return out


@router.get("/backups/orphaned")
async def orphaned_backups(request: Request) -> Any:
    """A list of {profile_id, identity, label, backups, ...} (contract.OrphanedBackupSet). The real engine's
    BackupManager.orphaned() also reads the server identity from each archive; the plain folder scan is the
    fallback for an engine without one."""
    engine = request.app.state.engine
    profiles = engine.store.list_profiles()
    mgr = getattr(engine, "backups", None)
    if mgr is not None and hasattr(mgr, "orphaned"):
        sets = await asyncio.to_thread(mgr.orphaned, profiles)
        for s in sets:
            s.setdefault("label", (s.get("backups") or [{}])[0].get("label"))
        return sets
    return await asyncio.to_thread(_orphans, engine.data_dir, {p.id for p in profiles})
