"""The local web API (FastAPI): REST + a WebSocket event stream, exactly as docs/API_CONTRACT.md describes."""
from .app import create_app

__all__ = ["create_app"]
