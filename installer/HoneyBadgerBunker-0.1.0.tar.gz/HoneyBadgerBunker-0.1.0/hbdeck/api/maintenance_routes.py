"""Maintenance routes: update check, Verify, bans, admin role (BASICS_PLAN B + E).

INTEGRATION (api/app.py, inside create_app, after `api = APIRouter(prefix="/api/v1", ...)` and before
`app.include_router(api)`, so the token check and the /api/v1 prefix apply):

    from .maintenance_routes import build_maintenance_router
    api.include_router(build_maintenance_router(engine))

Engine attributes these routes use (all exist today unless marked NEW):
    engine.require_profile(pid)            -> Profile; raises OpError("...", "not_found")
    engine.supervisor(pid)                 -> .alive, .rcon (.state == "ready"), .write_configs(profile)
    engine.ops.current(pid)                -> the running Operation or None
    engine.command(pid, cmd, echo=True)    -> {"reply": str, ...}; raises OpError(..., "rcon_unavailable")
    engine.store.save_profile / get_receipt(pid, "framework") / list_profiles()
    engine.platform.os_name
    engine.server_updates                  (wired 2026-10-28): server_updates.ServerUpdateService(engine.data_dir,
                                           steamcmd_runner=...). If missing, one is created on first use and
                                           stored on the engine, so status frames and this route share one cache.
    engine.submit_verify(pid)              (wired 2026-10-28): the stopped-only "verify" operation (see server_updates.verify_steps).
                                           Until it exists, POST /verify answers 501 not_wired.

Errors use the engine's shape {"error": {"code", "message", "detail"}}.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from .. import rcon
from ..models import Admin
from ..operations import OpError
from ..server_updates import VERIFY_COPY, ServerUpdateService

STATUS = {"not_found": 404, "server_running": 409, "busy": 409, "rcon_unavailable": 503, "bad_request": 400,
          "invalid_value": 422, "invalid_steamid": 422, "invalid_request": 422, "unknown_reply": 502,
          "not_wired": 501}


def error(code: str, message: str, detail: dict[str, Any] | None = None, status: int | None = None) -> JSONResponse:
    return JSONResponse({"error": {"code": code, "message": message, "detail": detail or {}}},
                        status_code=status or STATUS.get(code, 400))


def rcon_unavailable_response() -> JSONResponse:
    """422 for "warn players for N minutes" while RCON is down (countdown.RconUnavailable). The stop/restart/update
    routes (guards' app.py) return this so the UI can offer "Stop now" instead."""
    return error("rcon_unavailable", "Players cannot be warned right now because RCON is not connected. "
                 "Use Stop now instead.", status=422)


def _rcon_ready(engine: Any, pid: str) -> bool:
    sup = engine.supervisor(pid)
    return bool(sup.alive and sup.rcon is not None and getattr(sup.rcon, "state", None) == "ready")


def _bans_cfg(prof: Any) -> Path:
    from ..games import get_game
    return Path(get_game(prof.game).identity_dir(prof)) / "cfg" / "bans.cfg"


def _service(engine: Any) -> ServerUpdateService:
    svc = getattr(engine, "server_updates", None)
    if svc is None:
        svc = ServerUpdateService(getattr(engine, "data_dir", None))
        engine.server_updates = svc
    return svc


def build_maintenance_router(engine: Any) -> APIRouter:
    r = APIRouter()

    def sender(pid: str, echo: bool = True):  # noqa: ANN202 - async (command) -> reply text
        async def send(command: str) -> str:
            return str((await engine.command(pid, command, echo=echo)).get("reply") or "")
        return send

    # ----- updates -------------------------------------------------------------------------------------------
    @r.post("/profiles/{pid}/updates/check")
    async def updates_check(pid: str) -> Any:
        try:
            prof = engine.require_profile(pid)
        except OpError as exc:
            return error(exc.code, str(exc))
        busy = engine.ops.current(pid) is not None
        return await _service(engine).check(prof, receipt=engine.store.get_receipt(pid, "framework"),
                                            os_name=engine.platform.os_name, busy=busy, manual=True)

    @r.post("/profiles/{pid}/verify")
    async def verify(pid: str) -> Any:
        try:
            prof = engine.require_profile(pid)
        except OpError as exc:
            return error(exc.code, str(exc))
        if engine.supervisor(pid).alive:
            return error("server_running", "Stop the server before verifying its files.")
        if engine.ops.current(pid) is not None:
            return error("busy", "Another task is running on this server; try again when it finishes.")
        submit = getattr(engine, "submit_verify", None)
        if submit is None:
            return error("not_wired", "Verify is not connected to the operation system yet.")
        try:
            op = submit(pid)
        except OpError as exc:
            return error(exc.code, str(exc))
        body = op.model_dump(mode="json") if hasattr(op, "model_dump") else op
        return JSONResponse({"operation": body, "copy": VERIFY_COPY.format(branch=prof.branch)}, status_code=202)

    # ----- bans --------------------------------------------------------------------------------------------
    @r.get("/profiles/{pid}/bans")
    async def bans(pid: str) -> Any:
        try:
            prof = engine.require_profile(pid)
        except OpError as exc:
            return error(exc.code, str(exc))
        path = _bans_cfg(prof)
        try:
            saved_entries = rcon.parse_bans_cfg(path.read_text(encoding="utf-8", errors="replace")) \
                if path.exists() else []
            saved = {"entries": [b.to_dict() for b in saved_entries], "file_exists": path.exists(), "error": None}
        except OSError as exc:
            saved = {"entries": None, "file_exists": None, "error": str(exc)}
        from ..models import iso, utcnow
        if not _rcon_ready(engine, pid):
            return {"entries": saved["entries"], "source": "saved", "live": None, "saved": saved,
                    "checked_at": iso(utcnow()), "stale": False, "error": None,
                    "note": "The server is not running (or RCON is not connected): this is the saved ban file."}
        try:
            live = await rcon.banlist(sender(pid, echo=False))
        except rcon.RconParseError as exc:
            return error("unknown_reply", "The server answered the ban-list command in a way we do not "
                         "recognise, so we cannot say who is banned.", {"reply": exc.reply[:2000], "saved": saved})
        except OpError as exc:
            return error(exc.code, str(exc), {"saved": saved})
        return {"entries": [b.to_dict() for b in live], "source": "live", "live": True, "saved": saved,
                "checked_at": iso(utcnow()), "stale": False, "error": None}

    @r.post("/profiles/{pid}/players/{sid}/unban")
    async def unban(pid: str, sid: str) -> Any:
        try:
            prof = engine.require_profile(pid)
            sid = rcon.validate_steamid64(sid)
        except OpError as exc:
            return error(exc.code, str(exc))
        except ValueError as exc:
            return error("invalid_steamid", str(exc))
        applied: dict[str, Any]
        if _rcon_ready(engine, pid):
            try:
                applied = (await rcon.unban(sender(pid), sid)).to_dict()
            except OpError as exc:
                applied = {"sent": False, "confirmed": False, "state": exc.code, "message": str(exc)}
        elif engine.supervisor(pid).alive:
            applied = {"sent": False, "confirmed": False, "state": "rcon_unavailable",
                       "message": "saved; the running server still has the ban until it restarts"}
        else:
            applied = {"sent": False, "confirmed": False, "state": "not_running",
                       "message": "saved; it applies when the server starts"}
        # Rust's own `unban` does not save bans.cfg, so we remove the line ourselves (the saved config).
        path = _bans_cfg(prof)
        saved: dict[str, Any] = {"changed": False, "error": None}
        try:
            if path.exists():
                from ..profiles import atomic_write
                new, removed = rcon.remove_from_bans_cfg(path.read_text(encoding="utf-8", errors="replace"), sid)
                if removed:
                    atomic_write(path, new, getattr(engine, "platform", None))
                    saved["changed"] = True
        except OSError as exc:
            saved["error"] = str(exc)
        # The UI reads AdminChange: saved/applied as plain booleans (null = applies at the next start) + one error line.
        applied_flag = True if applied.get("confirmed") else (None if applied.get("state") in ("rcon_unavailable", "not_running") else False)
        err = saved["error"] or (None if applied_flag is not False else applied.get("message") or applied.get("state"))
        return {"steamid64": sid, "role": None, "saved": saved["error"] is None, "applied": applied_flag, "error": err,
                "detail": {"saved": saved, "applied": applied}}

    @r.post("/profiles/{pid}/bans")
    async def ban_steamid(pid: str, request: Request) -> Any:
        """Ban a SteamID64, online or not: {"steamid64", "reason"?, "duration_s": int | null, "name"?}.
        Live: `banid` over RCON when RCON answers. Saved: ALWAYS a banid line in bans.cfg, because Rust's banid
        does not save the file itself (only ServerUsers.Save() does, e.g. on ownerid or server.writecfg), so
        without it the ban would be gone after a restart. Answers in the AdminChange shape."""
        try:
            prof = engine.require_profile(pid)
        except OpError as exc:
            return error(exc.code, str(exc))
        try:
            body = json.loads(await request.body() or b"{}")
        except ValueError:
            return error("bad_request", "request body is not valid JSON")
        if not isinstance(body, dict):
            return error("invalid_request", 'body must be {"steamid64": "...", "reason": "...", "duration_s": null}')
        try:
            sid = rcon.validate_steamid64(body.get("steamid64"))
        except ValueError as exc:
            return error("invalid_steamid", str(exc))
        reason = str(body.get("reason") or "").strip()
        name = str(body.get("name") or "").strip()
        if len(reason) > 200 or len(name) > 80:
            return error("invalid_value", "The reason can be at most 200 characters and the name at most 80.")
        dur = body.get("duration_s")
        if dur is not None:
            if isinstance(dur, bool) or not isinstance(dur, int) or not 60 <= dur <= 315360000:
                return error("invalid_value", "duration_s must be null (permanent) or whole seconds from 60 to "
                             "315360000 (ten years).")
        # 1) live: the running server bans now (and kicks the player if they are on)
        applied: dict[str, Any]
        if _rcon_ready(engine, pid):
            try:
                applied = (await rcon.ban(sender(pid), sid, name, reason, dur)).to_dict()
            except OpError as exc:
                applied = {"sent": False, "confirmed": False, "state": exc.code, "message": str(exc)}
        elif engine.supervisor(pid).alive:
            applied = {"sent": False, "confirmed": False, "state": "rcon_unavailable",
                       "message": "saved to bans.cfg; the running server is not answering RCON, so it does not know "
                                  "yet. It reads the file at its next start (an admin command that saves the ban "
                                  "list before then could write over the line)."}
        else:
            applied = {"sent": False, "confirmed": False, "state": "not_running",
                       "message": "saved; it applies when the server starts"}
        # 2) saved: the bans.cfg line, so the ban holds after a restart
        from ..models import utcnow
        expiry = int(utcnow().timestamp()) + dur if dur else None
        line = rcon.bans_cfg_line(sid, name, reason, expiry)
        path = _bans_cfg(prof)
        saved: dict[str, Any] = {"changed": False, "error": None, "line": line}
        if not prof.install_root:
            saved["error"] = "this server has no install folder yet, so there is no bans.cfg to write"
        else:
            try:
                from ..profiles import atomic_write
                old = path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""
                # the server said ALREADY banned: keep the file's existing line, so it matches the real ban
                keep_old = applied.get("state") == "already"
                new, changed = rcon.add_to_bans_cfg(old, sid, line, replace=not keep_old)
                if changed:
                    atomic_write(path, new, getattr(engine, "platform", None))
                    saved["changed"] = True
            except OSError as exc:
                saved["error"] = str(exc)
        applied_flag = True if applied.get("confirmed") else (
            None if applied.get("state") in ("rcon_unavailable", "not_running") else False)
        err = saved["error"] or (None if applied_flag is not False else applied.get("message") or applied.get("state"))
        return {"steamid64": sid, "role": None, "saved": saved["error"] is None, "applied": applied_flag, "error": err,
                "detail": {"saved": saved, "applied": applied}}

    # ----- admin role ---------------------------------------------------------------------------------------
    @r.put("/profiles/{pid}/players/{sid}/admin")
    async def set_admin(pid: str, sid: str, request: Request) -> Any:
        try:
            prof = engine.require_profile(pid)
            sid = rcon.validate_steamid64(sid)
        except OpError as exc:
            return error(exc.code, str(exc))
        except ValueError as exc:
            return error("invalid_steamid", str(exc))
        try:
            body = json.loads(await request.body() or b"{}")
        except ValueError:
            return error("bad_request", "request body is not valid JSON")
        if not isinstance(body, dict) or "role" not in body or body["role"] not in ("owner", "moderator", None):
            return error("invalid_request", 'body must be {"role": "owner" | "moderator" | null}')
        role = body["role"]
        old = next((a for a in prof.admins if a.steamid64 == sid), None)
        name = str(body.get("name") or (old.name if old else "") or "")
        # Saved configuration: everyone else stays exactly as they were.
        prof.admins = [a for a in prof.admins if a.steamid64 != sid]
        if role is not None:
            prof.admins.append(Admin(steamid64=sid, role=role, name=name))
        engine.store.save_profile(prof)
        # Live state: only the commands needed for THIS player.
        results: list[dict[str, Any]] = []
        if _rcon_ready(engine, pid):
            send = sender(pid)
            try:
                if old is not None and old.role != role:
                    fn = rcon.removeowner if old.role == "owner" else rcon.removemoderator
                    results.append((await fn(send, sid)).to_dict())
                if role is not None and (old is None or old.role != role):
                    fn = rcon.ownerid if role == "owner" else rcon.moderatorid
                    results.append((await fn(send, sid, name)).to_dict())
            except OpError as exc:
                results.append({"sent": False, "confirmed": False, "state": exc.code, "message": str(exc)})
            if not results:
                state = "nothing_to_do"
            elif all(x.get("confirmed") for x in results):
                state = "confirmed"
            elif any(x.get("sent") for x in results):
                state = "sent_unconfirmed"
            else:
                state = "failed"
        elif engine.supervisor(pid).alive:
            state = "rcon_unavailable"            # saved; the running server picks it up at its next start
        else:
            state = "not_running"
            try:
                engine.supervisor(pid).write_configs(prof)    # users.cfg now matches the saved list
            except Exception as exc:  # noqa: BLE001 - the profile is saved; the file is rewritten at next start
                results.append({"sent": False, "confirmed": False, "state": "write_failed", "message": str(exc)})
        # AdminChange shape for the UI: applied True = confirmed live, False = tried and failed, None = at next start.
        if state in ("confirmed", "nothing_to_do"):
            applied_flag: bool | None = True
        elif state in ("rcon_unavailable", "not_running"):
            applied_flag = None
        else:
            applied_flag = False
        failures = [x for x in results if not x.get("confirmed")]
        err = None
        if applied_flag is False:
            err = "; ".join(str(x.get("message") or x.get("state")) for x in failures) or state
        elif any(x.get("state") == "write_failed" for x in results):
            err = next(str(x.get("message")) for x in results if x.get("state") == "write_failed")
        return {"steamid64": sid, "role": role, "admins": [a.model_dump() for a in prof.admins], "saved": True,
                "applied": applied_flag, "error": err, "detail": {"state": state, "commands": results}}

    # GET /backups/orphaned is served by housekeeping_routes.py (one route, the list shape ui/src/api.ts reads);
    # it uses engine.backups.orphaned() from backups.py, so the identity read from each archive is kept.

    return r
