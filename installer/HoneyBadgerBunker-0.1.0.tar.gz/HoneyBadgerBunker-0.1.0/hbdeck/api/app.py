"""FastAPI application: every route from docs/API_CONTRACT.md.

Security model (local app):
- The engine listens on 127.0.0.1 by default. Every /api request needs `Authorization: Bearer <token>`; the token
  is random per engine start and lives in <data>/engine.json (readable by this user only) and in the page the
  engine serves to a LOCAL browser.
- Host and Origin headers are checked, so a random website you visit cannot drive the engine through your
  browser (DNS-rebinding / cross-site requests are refused).
- GET requests never change anything. Changes return an Operation id (202) or the new object (200).
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import secrets
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ValidationError
from starlette.exceptions import HTTPException as StarletteHTTPException

from .. import APP_NAME, __version__
from ..engine import Engine
from ..models import Admin, ProfileCreate, ScheduleIn
from ..operations import OpError
from ..rcon import RconUnavailable
from .housekeeping_routes import router as housekeeping_router
from .maintenance_routes import build_maintenance_router, rcon_unavailable_response
from .network_routes import EngineAdapter, SecretPathLogFilter, network_router
from .panel_routes import PanelAdapter, panel_router

STATIC_DIR = Path(__file__).resolve().parents[1] / "static"
LOOPBACK_CLIENTS = {"127.0.0.1", "::1", "localhost", "testclient"}

PLACEHOLDER = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>HoneyBadger Bunker</title>
<style>body{margin:0;font-family:Segoe UI,system-ui,sans-serif;background:#faf6ee;color:#2b2622;display:grid;
place-items:center;min-height:100vh}main{max-width:560px;padding:32px}h1{color:#b86a00;margin:0 0 12px}
code{background:#efe6d6;padding:2px 6px;border-radius:4px}</style></head><body><main>
<h1>HoneyBadger Bunker</h1><p>The engine is running (version __VERSION__), but the user interface has not
been built yet.</p><p>Build it from the <code>ui/</code> folder; it will be served from <code>hbdeck/static/</code>.
</p><p>The API is available at <code>/api/v1</code>.</p></main></body></html>"""


class ApiError(Exception):
    def __init__(self, status: int, code: str, message: str, detail: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.status, self.code, self.message, self.detail = status, code, message, detail or {}


OP_STATUS = {"not_found": 404, "server_running": 409, "already_running": 409, "port_in_use": 409, "locked": 409,
             "rcon_unavailable": 503, "bad_request": 400, "invalid_value": 422, "bad_filename": 400,
             "too_large": 413, "bad_plugin": 400, "no_framework": 409, "not_installed": 409, "crash_loop": 409,
             "not_owned": 409, "unsafe_delete": 400, "bad_install_root": 400, "framework_conflict": 409,
             "confirm_required": 400, "not_installed_here": 400, "no_map_picture": 404, "render_cooldown": 429,
             "render_timeout": 504, "server_already_running": 409, "engine_stopping": 503, "cancelled": 409,
             "spawn_failed": 500, "metadata_failed": 500, "stop_failed": 500, "busy": 409, "invalid_request": 422,
             "unknown_convar": 422}


def error_body(code: str, message: str, detail: dict[str, Any] | None = None) -> dict[str, Any]:
    return {"error": {"code": code, "message": message, "detail": detail or {}}}


def create_app(engine: Engine, extra_hosts: set[str] | None = None, manage_lifecycle: bool = True) -> FastAPI:
    from contextlib import asynccontextmanager

    @asynccontextmanager
    async def lifespan(app: FastAPI):  # noqa: ANN202
        if manage_lifecycle:
            await engine.startup()
        try:
            yield
        finally:
            if manage_lifecycle:
                await engine.shutdown()

    app = FastAPI(title=APP_NAME, version=__version__, docs_url=None, redoc_url=None, openapi_url=None,
                  lifespan=lifespan)
    app.state.engine = engine
    extra = set(extra_hosts or set())
    # The access log is off (server.py access_log=False). Should anyone turn it on, the RCON-reveal path is still
    # never written to it: this filter drops those lines, decided from the path alone.
    access = logging.getLogger("uvicorn.access")
    if not any(isinstance(f, SecretPathLogFilter) for f in access.filters):
        access.addFilter(SecretPathLogFilter())

    def allowed_hosts() -> set[str]:
        port = engine.port
        hosts = set(extra)
        for h in ("127.0.0.1", "localhost", "[::1]"):
            hosts.add(f"{h}:{port}" if port else h)
        if getattr(engine, "bind", "127.0.0.1") not in ("127.0.0.1", "::1", "localhost"):
            hosts.add(f"{engine.bind}:{port}")   # type: ignore[attr-defined]
        return hosts

    # ----- errors ------------------------------------------------------------------------------------------
    @app.exception_handler(ApiError)
    async def _api_err(_r: Request, exc: ApiError) -> JSONResponse:
        return JSONResponse(error_body(exc.code, exc.message, exc.detail), status_code=exc.status)

    @app.exception_handler(OpError)
    async def _op_err(_r: Request, exc: OpError) -> JSONResponse:
        return JSONResponse(error_body(exc.code, str(exc), exc.detail), status_code=OP_STATUS.get(exc.code, 400))

    @app.exception_handler(RequestValidationError)
    async def _val_err(_r: Request, exc: RequestValidationError) -> JSONResponse:
        errs = [{"field": ".".join(str(x) for x in e.get("loc", [])[1:]), "message": e.get("msg", "")}
                for e in exc.errors()]
        msg = errs[0]["message"] if errs else "invalid request"
        return JSONResponse(error_body("invalid_request", msg, {"errors": errs}), status_code=422)

    @app.exception_handler(ValidationError)
    async def _pyd_err(_r: Request, exc: ValidationError) -> JSONResponse:
        errs = [{"field": ".".join(str(x) for x in e.get("loc", [])), "message": e.get("msg", "")} for e in exc.errors()]
        return JSONResponse(error_body("invalid_request", errs[0]["message"] if errs else "invalid", {"errors": errs}),
                            status_code=422)

    @app.exception_handler(ValueError)
    async def _value_err(_r: Request, exc: ValueError) -> JSONResponse:
        return JSONResponse(error_body("invalid_request", str(exc)), status_code=422)

    @app.exception_handler(StarletteHTTPException)
    async def _http_err(_r: Request, exc: StarletteHTTPException) -> JSONResponse:
        code = {404: "not_found", 405: "method_not_allowed", 401: "unauthorized", 403: "forbidden"}.get(
            exc.status_code, "http_error")
        return JSONResponse(error_body(code, str(exc.detail)), status_code=exc.status_code)

    # ----- Host / Origin guard (all routes) ----------------------------------------------------------------
    @app.middleware("http")
    async def guard(request: Request, call_next):  # noqa: ANN001, ANN202
        host = request.headers.get("host", "")
        hosts = allowed_hosts()
        ident = {"X-HBDeck-Instance": engine.instance_id}   # proves WHICH engine answered (not a port squatter)
        if host not in hosts:
            return JSONResponse(error_body("forbidden_host", "requests must use 127.0.0.1 or localhost"), 403,
                                headers=ident)
        origin = request.headers.get("origin")
        if origin and origin not in {f"http://{h}" for h in hosts}:
            return JSONResponse(error_body("forbidden_origin", "cross-site requests are not allowed"), 403,
                                headers=ident)
        resp = await call_next(request)
        resp.headers["X-HBDeck-Instance"] = engine.instance_id
        if not request.url.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-cache"
        else:
            resp.headers["Cache-Control"] = "no-store"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Referrer-Policy"] = "no-referrer"
        return resp

    def require_token(request: Request) -> None:
        auth = request.headers.get("authorization", "")
        tok = auth[7:] if auth.lower().startswith("bearer ") else ""
        if not tok or not secrets.compare_digest(tok, engine.token):
            raise ApiError(401, "unauthorized", "missing or wrong engine token")

    api = APIRouter(prefix="/api/v1", dependencies=[Depends(require_token)])

    def op_response(op: Any) -> JSONResponse:
        return JSONResponse({"operation": op.model_dump(mode="json")}, status_code=202)

    async def body_json(request: Request) -> dict[str, Any]:
        raw = await request.body()
        if not raw:
            return {}
        try:
            data = json.loads(raw)
        except ValueError as exc:
            raise ApiError(400, "bad_json", "request body is not valid JSON") from exc
        if not isinstance(data, dict):
            raise ApiError(400, "bad_json", "request body must be a JSON object")
        return data

    # ----- engine ------------------------------------------------------------------------------------------
    @api.get("/engine")
    async def get_engine() -> dict[str, Any]:
        return engine.engine_info()

    @api.post("/engine/shutdown")
    async def shutdown_engine() -> dict[str, Any]:
        # From this instant nothing new starts (synchronous), then the web server exits and the lifespan hook
        # runs the bounded shutdown (save + quit every server, verify, release the lock last).
        engine.begin_stopping()

        async def later() -> None:
            await asyncio.sleep(0.2)
            if engine.request_exit:
                engine.request_exit()
            else:
                await engine.shutdown()
        asyncio.get_running_loop().create_task(later())
        return {"ok": True, "message": "stopping all servers gracefully, then exiting",
                "budget_s": engine.shutdown_budget_s}

    @api.get("/engine/kill-all")
    async def kill_all_preview() -> dict[str, Any]:
        """What "Stop everything" would end (strictly read-only: the confirm dialog lists it)."""
        from ..killall import collect
        rep = await asyncio.to_thread(collect, engine.data_dir, exclude_pids={os.getpid()}, include_engines=False)
        own = [{"kind": "game", "pid": s.pid, "label": f"game server '{engine.store.get_profile(pid).identity}'"
                if engine.store.get_profile(pid) else "game server", "source": "this Deck"}
               for pid, s in engine.supervisors.items() if s.alive and s.pid]
        out = rep.as_dict()
        out["targets"] = own + [t for t in out["targets"] if t["pid"] not in {o["pid"] for o in own}]
        return out

    @api.post("/engine/kill-all")
    async def kill_all() -> JSONResponse:
        return op_response(engine.submit_kill_all())

    @api.post("/engine/last-session/dismiss")
    async def dismiss_last_session() -> dict[str, Any]:
        return engine.dismiss_last_session()

    @api.post("/engine/update/check")
    async def update_check() -> dict[str, Any]:
        await engine.updates.check()
        info = engine.engine_info()
        engine.events.publish({"type": "engine", "engine": info})
        return info

    @api.post("/engine/update/apply")
    async def update_apply() -> JSONResponse:
        return op_response(engine_app_update(engine))

    # ----- profiles ----------------------------------------------------------------------------------------
    @api.get("/profiles")
    async def list_profiles() -> list[dict[str, Any]]:
        return [p.model_dump(mode="json") for p in engine.store.list_profiles()]

    @api.post("/profiles", status_code=201)
    async def create_profile(request: Request) -> JSONResponse:
        body = ProfileCreate.model_validate(await body_json(request))
        prof = engine.create_profile(body)
        return JSONResponse(prof.model_dump(mode="json"), status_code=201)

    @api.get("/profiles/{pid}")
    async def get_profile(pid: str) -> dict[str, Any]:
        return engine.require_profile(pid).model_dump(mode="json")

    @api.put("/profiles/{pid}")
    async def put_profile(pid: str, request: Request) -> dict[str, Any]:
        return engine.update_profile(pid, await body_json(request)).model_dump(mode="json")

    @api.get("/profiles/{pid}/delete-token")
    async def delete_token(pid: str) -> dict[str, Any]:
        return {"token": engine.delete_token(pid), "expires_in_s": 600}

    @api.delete("/profiles/{pid}")
    async def delete_profile(pid: str, remove_files: bool = False, confirm: str | None = None) -> dict[str, Any]:
        if remove_files and not engine.check_delete_token(pid, confirm):
            raise ApiError(400, "confirm_required", "deleting server files needs ?confirm=<token from delete-token>")
        engine.delete_profile(pid, remove_files=remove_files)
        return {"ok": True}

    @api.get("/profiles/{pid}/status")
    async def get_status(pid: str) -> dict[str, Any]:
        return engine.status_payload(pid)

    # GET /profiles/{pid}/connect lives in network_routes.py (mounted below): it never returns the RCON password.

    # ----- lifecycle ---------------------------------------------------------------------------------------
    @api.post("/profiles/{pid}/install")
    async def install(pid: str, request: Request) -> JSONResponse:
        b = await body_json(request)
        return op_response(engine.submit_install(pid, validate=bool(b.get("validate", True)), kind="install"))

    @api.post("/profiles/{pid}/update")
    async def update(pid: str, request: Request) -> JSONResponse:
        b = await body_json(request)
        try:
            return op_response(engine.submit_install(pid, validate=bool(b.get("validate", True)), kind="update",
                                                     warn_s=b.get("warn_s", 0)))
        except RconUnavailable:
            return rcon_unavailable_response()

    @api.post("/profiles/{pid}/start")
    async def start(pid: str) -> JSONResponse:
        return op_response(engine.submit_start(pid))

    @api.post("/profiles/{pid}/conflict/stop")
    async def conflict_stop(pid: str) -> JSONResponse:
        """"Stop it": end the server from a previous session that holds this world (verified first)."""
        return op_response(engine.submit_conflict_stop(pid))

    @api.post("/profiles/{pid}/conflict/leave")
    async def conflict_leave(pid: str) -> dict[str, Any]:
        """"Leave it": hide the banner; the profile stays refused until that server is gone."""
        return engine.conflict_leave(pid)

    # Stop / Restart / Update take warn_s 0 | 60 | 300 (default 0 = now). Warnings need RCON: when players cannot
    # be warned the request is refused with 422 rcon_unavailable BEFORE an operation exists ("use Stop now").
    @api.post("/profiles/{pid}/stop")
    async def stop(pid: str, request: Request) -> JSONResponse:
        b = await body_json(request)
        try:
            return op_response(engine.submit_stop(pid, graceful=bool(b.get("graceful", True)),
                                                  warn_s=b.get("warn_s", 0)))
        except RconUnavailable:
            return rcon_unavailable_response()

    @api.post("/profiles/{pid}/restart")
    async def restart(pid: str, request: Request) -> JSONResponse:
        b = await body_json(request)
        try:
            return op_response(engine.submit_restart(pid, warn_s=b.get("warn_s", 0)))
        except RconUnavailable:
            return rcon_unavailable_response()

    @api.post("/profiles/{pid}/framework")
    async def framework(pid: str, request: Request) -> JSONResponse:
        b = await body_json(request)
        return op_response(engine.submit_framework(pid, str(b.get("framework", "")), str(b.get("pin", "upstream"))))

    @api.post("/profiles/{pid}/wipe")
    async def wipe(pid: str, request: Request) -> JSONResponse:
        b = await body_json(request)
        seed = b.get("new_seed")
        return op_response(engine.submit_wipe(pid, str(b.get("scope", "")), int(seed) if seed is not None else None))

    @api.get("/profiles/{pid}/wipe-plan")
    async def wipe_plan(pid: str, scope: str = "map") -> dict[str, Any]:
        """What a wipe would remove and keep (the dialog shows both before the user confirms)."""
        return engine.wipe_plan_view(pid, scope)

    @api.get("/profiles/{pid}/map.png")
    async def map_png(pid: str) -> FileResponse:
        """The island picture. Needs the Bearer token like every API call, so the UI fetches it and shows a blob URL
        (a plain <img src> cannot send the header). The guard middleware marks it no-store: after a wipe the
        seed changes but this URL does not."""
        path = await engine.map_png(pid)
        return FileResponse(path, media_type="image/png")

    @api.post("/profiles/{pid}/backup")
    async def backup(pid: str, request: Request) -> JSONResponse:
        b = await body_json(request)
        return op_response(engine.submit_backup(pid, str(b.get("label", ""))))

    @api.post("/profiles/{pid}/restore")
    async def restore(pid: str, request: Request) -> JSONResponse:
        b = await body_json(request)
        return op_response(engine.submit_restore(pid, str(b.get("backup_id", ""))))

    @api.get("/profiles/{pid}/backups")
    async def backups(pid: str) -> list[dict[str, Any]]:
        # rows carry kind + protected + keep_newest (WP43) so the Backups screen can say what clean-up does to each
        def keep_of(sid: str) -> int | None:
            s = engine.store.get_schedule(sid)
            return int(getattr(s, "keep_newest", 10) or 10) if s is not None else None
        return engine.backups.rows(engine.require_profile(pid), keep_of)

    @api.delete("/profiles/{pid}/backups/{bid}")
    async def delete_backup(pid: str, bid: str) -> dict[str, Any]:
        engine.backups.delete(engine.require_profile(pid), bid)
        return {"ok": True}

    # ----- console + commands ------------------------------------------------------------------------------
    @api.get("/profiles/{pid}/console")
    async def console(pid: str, after: int = 0, source: str | None = None, limit: int = 500) -> dict[str, Any]:
        engine.require_profile(pid)
        if source not in (None, "stdout", "rcon", "system"):
            raise ApiError(400, "bad_request", "source must be stdout, rcon or system")
        lines = engine.console(pid).query(after=after, source=source, limit=max(1, min(limit, 5000)))
        return {"lines": [ln.model_dump() for ln in lines], "last_seq": engine.console(pid).last_seq}

    @api.post("/profiles/{pid}/command")
    async def command(pid: str, request: Request) -> dict[str, Any]:
        b = await body_json(request)
        cmd = str(b.get("command", "")).strip()
        if not cmd:
            raise ApiError(400, "bad_request", "command is empty")
        return await engine.command(pid, cmd)

    # ----- players + admins --------------------------------------------------------------------------------
    @api.get("/profiles/{pid}/players")
    async def players(pid: str) -> list[dict[str, Any]]:
        engine.require_profile(pid)
        sup = engine.supervisor(pid)
        if sup.alive and sup.rcon and sup.rcon.state == "ready":
            try:
                rows = await sup.rcon.playerlist(timeout=5)
                if rows is not None:
                    sup.players = rows
            except Exception:  # noqa: BLE001 - fall back to the last known list
                pass
        return [p.model_dump() for p in (sup.players or [])] if sup.alive else []

    @api.post("/profiles/{pid}/players/{steamid}/kick")
    async def kick(pid: str, steamid: str, request: Request) -> dict[str, Any]:
        b = await body_json(request)
        return await engine.kick(pid, steamid, str(b.get("reason", "")))

    @api.post("/profiles/{pid}/players/{steamid}/ban")
    async def ban(pid: str, steamid: str, request: Request) -> dict[str, Any]:
        b = await body_json(request)
        d = b.get("duration_s")
        return await engine.ban(pid, steamid, str(b.get("reason", "")), int(d) if d else None)

    @api.get("/profiles/{pid}/admins")
    async def get_admins(pid: str) -> list[dict[str, Any]]:
        return [a.model_dump() for a in engine.require_profile(pid).admins]

    @api.put("/profiles/{pid}/admins")
    async def put_admins(pid: str, request: Request) -> list[dict[str, Any]]:
        raw = json.loads(await request.body() or b"[]")
        items = raw.get("admins", []) if isinstance(raw, dict) else raw
        admins = [Admin.model_validate(a) for a in items]
        prof = await engine.set_admins(pid, admins)
        return [a.model_dump() for a in prof.admins]

    # ----- config ------------------------------------------------------------------------------------------
    @api.get("/profiles/{pid}/convars")
    async def get_convars(pid: str) -> list[dict[str, Any]]:
        return engine.convars(pid)

    @api.put("/profiles/{pid}/convars")
    async def put_convars(pid: str, request: Request) -> JSONResponse:
        res = await engine.set_convars(pid, await body_json(request))
        if res["restart_required"]:
            from ..models import Operation, Step, iso, utcnow
            op = Operation(profile_id=pid, kind="convars", state="done", params=res, started=iso(utcnow()),
                           finished=iso(utcnow()),
                           steps=[Step(name="Saved to server.cfg", state="done"),
                                  Step(name="Restart needed for: " + ", ".join(res["restart_required"]),
                                       state="pending")])
            engine.store.save_operation(op)
            engine.events.publish({"type": "operation", "operation": op.model_dump(mode="json")})
            return JSONResponse({"operation": op.model_dump(mode="json"), **res}, status_code=202)
        return JSONResponse(res, status_code=200)

    @api.get("/profiles/{pid}/server-cfg")
    async def server_cfg(pid: str) -> dict[str, Any]:
        return engine.server_cfg_view(pid)

    # ----- plugins -----------------------------------------------------------------------------------------
    @api.get("/profiles/{pid}/plugins")
    async def get_plugins(pid: str) -> list[dict[str, Any]]:
        return [p.model_dump() for p in await engine.plugins(pid)]

    @api.post("/profiles/{pid}/plugins")
    async def add_plugin(pid: str, request: Request) -> Response:
        ctype = request.headers.get("content-type", "")
        if ctype.startswith("multipart/form-data"):
            form = await request.form()
            upload = form.get("file")
            if upload is None or not hasattr(upload, "read"):
                raise ApiError(400, "bad_request", "multipart upload needs a 'file' field")
            data = await upload.read()  # type: ignore[union-attr]
            info = engine.install_plugin_file(pid, Path(str(upload.filename)).name, data)  # type: ignore[union-attr]
            return JSONResponse(info.model_dump(), status_code=201)
        b = await body_json(request)
        if not b.get("catalog_id"):
            raise ApiError(400, "bad_request", "send {catalog_id} or a multipart .cs file")
        return op_response(engine.submit_catalog_plugin(pid, str(b["catalog_id"])))

    @api.post("/profiles/{pid}/plugins/{plugin_id}/{action}")
    async def plugin_action(pid: str, plugin_id: str, action: str) -> dict[str, Any]:
        if action not in ("enable", "disable", "reload"):
            raise ApiError(404, "not_found", "unknown plugin action")
        return await engine.plugin_action(pid, plugin_id, action)

    @api.delete("/profiles/{pid}/plugins/{plugin_id}")
    async def delete_plugin(pid: str, plugin_id: str) -> dict[str, Any]:
        return await engine.plugin_action(pid, plugin_id, "delete")

    @api.get("/convars")
    async def convar_catalog(game: str = "rust") -> list[dict[str, Any]]:
        return engine.convar_catalog(game)

    @api.get("/catalog")
    async def catalog() -> dict[str, Any]:
        return engine.updates.catalog()

    # ----- schedules ---------------------------------------------------------------------------------------
    @api.get("/profiles/{pid}/schedules")
    async def get_schedules(pid: str) -> list[dict[str, Any]]:
        engine.require_profile(pid)
        return [engine.scheduler.refresh(s).model_dump() for s in engine.store.list_schedules(pid)]

    @api.post("/profiles/{pid}/schedules", status_code=201)
    async def post_schedule(pid: str, request: Request) -> JSONResponse:
        s = engine.save_schedule(pid, ScheduleIn.model_validate(await body_json(request)))
        return JSONResponse(s.model_dump(), status_code=201)

    @api.put("/profiles/{pid}/schedules/{sid}")
    async def put_schedule(pid: str, sid: str, request: Request) -> dict[str, Any]:
        cur = engine.store.get_schedule(sid)
        if cur is None or cur.profile_id != pid:
            raise ApiError(404, "not_found", "schedule not found")
        merged = cur.model_dump(include=set(ScheduleIn.model_fields))
        merged.update(await body_json(request))
        return engine.save_schedule(pid, ScheduleIn.model_validate(merged), sid=sid).model_dump()

    @api.delete("/profiles/{pid}/schedules/{sid}")
    async def delete_schedule(pid: str, sid: str) -> dict[str, Any]:
        cur = engine.store.get_schedule(sid)
        if cur is None or cur.profile_id != pid:
            raise ApiError(404, "not_found", "schedule not found")
        engine.store.delete_schedule(sid)
        return {"ok": True}

    # ----- operations --------------------------------------------------------------------------------------
    @api.get("/operations")
    async def operations(profile_id: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        return [o.model_dump(mode="json") for o in engine.store.list_operations(profile_id, max(1, min(limit, 500)))]

    @api.get("/operations/{oid}")
    async def operation(oid: str) -> dict[str, Any]:
        op = engine.ops.get(oid)
        if op is None:
            raise ApiError(404, "not_found", "operation not found")
        return op.model_dump(mode="json")

    @api.post("/operations/{oid}/cancel")
    async def cancel(oid: str) -> dict[str, Any]:
        if engine.ops.get(oid) is None:
            raise ApiError(404, "not_found", "operation not found")
        return {"cancelled": engine.ops.cancel(oid)}

    # ----- basics bundle routers (each module's header says what it serves) -----------------------------------
    # Mounted on `api`, so they inherit the /api/v1 prefix and the Bearer-token check.
    api.include_router(network_router(EngineAdapter(engine)))     # Connection page, RCON reveal/rotate
    api.include_router(build_maintenance_router(engine))          # update check, Verify, bans, admin role
    api.include_router(panel_router(PanelAdapter(engine)))        # Player panel screen (WP45): GET/PUT panel.json
    api.include_router(housekeeping_router)                       # folders, console copy, disk, sign-in, service,
    #                                                               orphaned backups
    app.include_router(api)

    # ----- events WebSocket --------------------------------------------------------------------------------
    @app.websocket("/api/v1/events")
    async def events(ws: WebSocket) -> None:
        tok = ws.query_params.get("token", "")
        origin = ws.headers.get("origin")
        hosts = allowed_hosts()
        if (not tok or not secrets.compare_digest(tok, engine.token)
                or ws.headers.get("host", "") not in hosts
                or (origin and origin not in {f"http://{h}" for h in hosts})):
            await ws.close(code=4401)
            return
        await ws.accept()
        sub = engine.events.subscribe()
        await ws.send_json({"type": "engine", "engine": engine.engine_info()})
        for p in engine.store.list_profiles():
            await ws.send_json({"type": "status", "profile_id": p.id, "status": engine.status_payload(p.id)})

        async def reader() -> None:
            while True:
                msg = await ws.receive_json()
                if isinstance(msg, dict) and msg.get("type") == "subscribe" and msg.get("profile_id"):
                    sub.profiles.add(str(msg["profile_id"]))
                elif isinstance(msg, dict) and msg.get("type") == "unsubscribe":
                    sub.profiles.discard(str(msg.get("profile_id")))

        rtask = asyncio.create_task(reader())
        try:
            while True:
                get = asyncio.create_task(sub.queue.get())
                done, _ = await asyncio.wait({get, rtask}, return_when=asyncio.FIRST_COMPLETED)
                if rtask in done:
                    get.cancel()
                    break
                await ws.send_json(get.result())
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            rtask.cancel()
            engine.events.unsubscribe(sub)

    # ----- static UI ---------------------------------------------------------------------------------------
    @app.get("/", response_class=HTMLResponse)
    async def index(request: Request) -> HTMLResponse:
        index_file = STATIC_DIR / "index.html"
        if not index_file.exists():
            return HTMLResponse(PLACEHOLDER.replace("__VERSION__", html.escape(__version__)))
        page = index_file.read_text(encoding="utf-8")
        client = request.client.host if request.client else ""
        boot: dict[str, Any] = {"apiBase": "/api/v1", "wsBase": "/api/v1/events", "os": engine.platform.os_name,
                                "version": __version__}
        if client in LOOPBACK_CLIENTS:
            boot["token"] = engine.token          # only ever handed to a browser on this same machine
        else:
            boot["token"] = None
        script = f"<script>window.__HB = {json.dumps(boot)};</script>"
        page = page.replace("</head>", script + "</head>", 1) if "</head>" in page else script + page
        return HTMLResponse(page)

    assets = STATIC_DIR / "assets"
    app.mount("/assets", StaticFiles(directory=str(assets), check_dir=False), name="assets")
    return app


def engine_app_update(engine: Engine) -> Any:
    """Download + verify the newer app build named by the manifest, and hand it to the launcher for the next start.

    Honest about what happened: the operation's params always say {"staged": true, "activated": false} - this
    running engine never swaps its own code. The final step says "restart the Deck to switch versions" ONLY when
    an activation path exists (the Windows launcher started us; it consumes <data>/updates/pending.json).
    """
    from ..operations import OpContext
    from ..updates import launcher_can_activate, write_pending_update

    async def run(ctx: OpContext) -> None:
        upd = engine.updates.app_update()
        if not upd or not upd.get("available"):
            raise OpError("no newer app version in the verified manifest", "no_update")
        payload = engine.updates.payload or {}
        ids = payload.get("app", {}).get("artifacts", []) or []
        os_name = engine.platform.os_name
        art = next((engine.updates.artifact(i) for i in ids
                    if (engine.updates.artifact(i) or {}).get("os") in (os_name, "any")), None)
        if art is None:
            raise OpError(f"the manifest has no app build for {os_name}", "no_artifact")
        version = str(upd["version"])
        dest_dir = engine.data_dir / "updates" / version
        archive = dest_dir / art["filename"]
        async with ctx.step(f"Download {art['filename']} (size + sha256 checked)"):
            await engine.updates.download_artifact(art, archive)
        async with ctx.step("Hand the update to the launcher") as st:
            note = write_pending_update(engine.data_dir, version, archive, str(art["sha256"]))
            st.detail = str(note)
        can_activate = launcher_can_activate()
        ctx.op.params.update({"version": version, "staged": True, "activated": False,
                              "pending_file": str(note),
                              "activation": "launcher_on_restart" if can_activate else "none"})
        if can_activate:
            async with ctx.step("Ready to switch") as st:
                st.detail = "downloaded and verified; restart the Deck to switch versions"
        else:
            async with ctx.step("Staged, not activated") as st:
                st.detail = (f"downloaded and verified, but NOT activated: this Deck was not started by the Windows "
                             f"launcher, so nothing can switch it to {version}. Start it with "
                             "'HoneyBadger Bunker.bat' to apply the update.")
            ctx.log(f"App update {version} staged but not activated (no launcher).", "warn")
    return engine.ops.submit(None, "app_update", run)
