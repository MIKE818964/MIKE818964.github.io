"""Connection page routes (APIRouter). Plan: docs/team/basics/BASICS_PLAN_2026-10-28.md, section A.

=== WHAT THE INTEGRATOR MUST DO (hbdeck/api/app.py, inside create_app) ====================================
1. DELETE the old route (it returns the RCON password in plain text):
       @api.get("/profiles/{pid}/connect")
       async def get_connect(pid: str) -> dict[str, Any]:
           return engine.connect_info(pid)
   (engine.connect_info can then be removed too; nothing else calls it.)
2. Add ONE line after the other @api routes and BEFORE `app.include_router(api)`:
       api.include_router(network_router(EngineAdapter(engine)))
   with the import  `from .network_routes import EngineAdapter, network_router`.
   Mounting on `api` gives these routes the /api/v1 prefix and the Bearer-token check.
3. Access logs: uvicorn's access log is already off (server.py access_log=False). If it is ever turned on, add
   `logging.getLogger("uvicorn.access").addFilter(SecretPathLogFilter())`; `is_secret_path(path)` tells any
   other logger which paths carry the RCON secret (decided from the PATH, before any body is read).
=========================================================================================================

Engine attributes EngineAdapter uses (all exist today): engine.store.get_profile / list_profiles / get_secret /
set_secret / get_kv / set_kv, engine.update_profile(pid, dict), engine.supervisors[pid].alive / .busy_state /
.conflict, engine.ops.current(pid), engine.platform.protect / unprotect / os_name.

Routes (all under /profiles/{pid}):
  GET  /connect                     the Connection page data (never the RCON password)
  PUT  /connect                     {hostname?, name?, bind_ip?, ports?, public_address_override?,
                                    selected_lan_ip?}
  POST /connect/public-ip           look the public address up now (ipify, icanhazip fallback)
  POST /connect/query-check         {scope: "local" | "hairpin"}; targets ONLY this profile's own address
  POST /firewall/helper             write '<install>/Add firewall rule.bat' -> {helper_path}; {reveal: true} also
                                    opens Explorer with the file selected (Windows)
  GET  /firewall                    run `netsh ... show rule` (no admin) -> configured | missing | stale | unknown
  POST /rcon-password/reveal        {password}, Cache-Control: no-store, max 5 per minute per server
  POST /rcon-password               generate a new password (server stopped only); the reply never has it
"""
from __future__ import annotations

import asyncio
import collections
import json
import logging
import re
import secrets
import subprocess
import sys
import time
from typing import Any, Callable, Protocol

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from .. import network as net
from ..contract import CONNECT_DEFAULTS, merge_defaults
from ..models import Ports

log = logging.getLogger(__name__)

SECRET_PATH_RE = re.compile(r"/profiles/[^/]+/rcon-password/reveal/?$")
REVEAL_LIMIT = 5            # reveals ...
REVEAL_WINDOW_S = 60.0      # ... per this many seconds, per server
PORT_CHANGE_NOTE = "Used on next start; update your router forwarding and re-run the firewall helper."


def is_secret_path(path: str) -> bool:
    """True for request paths whose RESPONSE carries the RCON password (never log those)."""
    return bool(SECRET_PATH_RE.search(path.split("?", 1)[0]))


class SecretPathLogFilter(logging.Filter):
    """Drop access-log lines for secret-bearing paths. Attach to logging.getLogger('uvicorn.access')."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            text = record.getMessage()
        except Exception:  # noqa: BLE001 - a broken record is not our business; let it through
            return True
        return not any(is_secret_path(tok) for tok in text.split() if "/rcon-password/" in tok)


# =================================================================================================================
# The small engine interface these routes need
# =================================================================================================================

class NetworkEngine(Protocol):
    """Everything the Connection routes ask of the engine. EngineAdapter implements it for the real Engine;
    the tests implement it with a fake."""
    os_name: str

    def get_profile(self, pid: str) -> Any | None: ...                 # a models.Profile or None
    def list_profiles(self) -> list[Any]: ...
    def update_profile(self, pid: str, changes: dict[str, Any]) -> Any: ...   # validates + saves atomically
    def is_running(self, pid: str) -> bool: ...                        # server process alive
    def busy_reason(self, pid: str) -> str | None: ...                 # running job / conflict, else None
    def rcon_secret_get(self, pid: str) -> str | None: ...
    def rcon_secret_set(self, pid: str, password: str) -> None: ...
    def kv_get(self, key: str) -> Any: ...
    def kv_set(self, key: str, value: Any) -> None: ...


class EngineAdapter:
    """Maps NetworkEngine onto the real hbdeck.engine.Engine without changing engine.py."""

    def __init__(self, engine: Any) -> None:
        self.engine = engine

    @property
    def os_name(self) -> str:
        return self.engine.platform.os_name

    def get_profile(self, pid: str) -> Any | None:
        return self.engine.store.get_profile(pid)

    def list_profiles(self) -> list[Any]:
        return self.engine.store.list_profiles()

    def update_profile(self, pid: str, changes: dict[str, Any]) -> Any:
        return self.engine.update_profile(pid, changes)

    def is_running(self, pid: str) -> bool:
        sup = self.engine.supervisors.get(pid)
        return bool(sup and sup.alive)

    def busy_reason(self, pid: str) -> str | None:
        op = self.engine.ops.current(pid)
        if op is not None:
            return f"a {op.kind} job is running"
        sup = self.engine.supervisors.get(pid)
        if sup is not None and getattr(sup, "conflict", None):
            return "another server (not started by the Bunker) holds this world or these ports"
        if sup is not None and getattr(sup, "busy_state", None):
            return f"the server is {sup.busy_state}"
        return None

    def rcon_secret_get(self, pid: str) -> str | None:
        blob = self.engine.store.get_secret(f"{pid}:rcon")
        if blob is None:
            return None
        return self.engine.platform.unprotect(blob).decode()

    def rcon_secret_set(self, pid: str, password: str) -> None:
        self.engine.store.set_secret(f"{pid}:rcon", self.engine.platform.protect(password.encode()))

    def kv_get(self, key: str) -> Any:
        return self.engine.store.get_kv(key)

    def kv_set(self, key: str, value: Any) -> None:
        self.engine.store.set_kv(key, value)


# =================================================================================================================
# Helpers
# =================================================================================================================

def err(status: int, code: str, message: str, detail: dict[str, Any] | None = None, **top: Any) -> JSONResponse:
    """The engine's error shape {error: {code, message, detail}} (app.error_body), plus optional top-level keys
    such as `port` for port_conflict, as the plan's shared seam asks."""
    body: dict[str, Any] = {"code": code, "message": message, "detail": dict(detail or {})}
    body.update(top)
    return JSONResponse({"error": body}, status_code=status, headers={"Cache-Control": "no-store"})


def default_revealer(path: str) -> None:
    """Open Explorer with the file selected (Windows only). Fire and forget; Explorer is not our child to manage."""
    if sys.platform == "win32":
        subprocess.Popen(["explorer", f"/select,{path}"])  # noqa: S603,S607 - fixed program, our own file path


async def _json_body(request: Request) -> dict[str, Any] | JSONResponse:
    raw = await request.body()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except ValueError:
        return err(400, "bad_json", "request body is not valid JSON")
    if not isinstance(data, dict):
        return err(400, "bad_json", "request body must be a JSON object")
    return data


def network_router(eng: NetworkEngine, *, probe: net.PortProbe = net.probe_port,
                   a2s: Callable[..., net.A2SReply] = net.a2s_info,
                   public_cache: net.PublicIpCache | None = None,
                   firewall_runner: net.Runner | None = None,
                   lan_reader: Callable[[], list[net.LanAddress] | None] = net.lan_addresses,
                   route_ip: Callable[[], str | None] = net.os_route_ip,
                   revealer: Callable[[str], None] = default_revealer,
                   clock: Callable[[], float] = time.monotonic,
                   local_timeout: float = 2.0, hairpin_timeout: float = 3.0) -> APIRouter:
    """Build the router. Every outside effect (sockets, HTTP, netsh, Explorer) is injectable for tests."""
    router = APIRouter()
    pub = public_cache or net.PublicIpCache()
    pub.load(eng.kv_get("network:public_ip"))
    reveals: dict[str, collections.deque[float]] = collections.defaultdict(collections.deque)

    # ----- small shared steps ---------------------------------------------------------------------------
    def load_cache(pid: str) -> net.NetCache:
        c = net.NetCache.load(eng.kv_get(f"network:{pid}"))
        c.public = pub.snapshot()
        return c

    def save_cache(pid: str, c: net.NetCache) -> None:
        eng.kv_set(f"network:{pid}", c.dump())

    def status_of(pid: str) -> dict[str, Any]:
        running = eng.is_running(pid)
        busy = eng.busy_reason(pid)
        reason = "stop the server first" if running else busy
        return {"running": running, "busy": busy is not None, "reason": reason}

    def build(pid: str, prof: Any, cache: net.NetCache) -> dict[str, Any]:
        lan = lan_reader()
        info = net.connect_info(prof, status_of(pid), cache, lan=lan, route_ip=route_ip(),
                                rcon_password_set=eng.rcon_secret_get(pid) is not None, os_name=eng.os_name)
        return merge_defaults(info, CONNECT_DEFAULTS)    # every contract field present (unknown = null)

    def not_found() -> JSONResponse:
        return err(404, "not_found", "no such server profile")

    # ----- GET /connect -----------------------------------------------------------------------------------
    @router.get("/profiles/{pid}/connect")
    async def get_connect(pid: str) -> Any:
        prof = eng.get_profile(pid)
        if prof is None:
            return not_found()
        return build(pid, prof, load_cache(pid))

    # ----- PUT /connect -----------------------------------------------------------------------------------
    @router.put("/profiles/{pid}/connect")
    async def put_connect(pid: str, request: Request) -> Any:
        prof = eng.get_profile(pid)
        if prof is None:
            return not_found()
        body = await _json_body(request)
        if isinstance(body, JSONResponse):
            return body
        cache = load_cache(pid)
        changes: dict[str, Any] = {}
        if "hostname" in body and body["hostname"] != prof.hostname:
            changes["hostname"] = body["hostname"]
        if "name" in body and body["name"] != prof.name:
            changes["name"] = body["name"]           # the Bunker's own label (advanced; Rust never shows it)
        if "bind_ip" in body and body["bind_ip"] != prof.bind_ip:
            changes["bind_ip"] = body["bind_ip"]
        new_ports: Ports | None = None
        if body.get("ports") is not None:
            try:
                new_ports = Ports.model_validate(body["ports"])
            except ValidationError as exc:
                e0 = exc.errors()[0] if exc.errors() else {}
                return err(422, "invalid_request", str(e0.get("msg", "invalid ports")).replace("Value error, ", ""),
                           {"errors": [{"field": "ports." + ".".join(str(x) for x in e.get("loc", [])),
                                        "message": e.get("msg", "")} for e in exc.errors()]})
            if new_ports != prof.ports:
                changes["ports"] = new_ports.model_dump()
            else:
                new_ports = None
        try:
            override = net.validate_public_override(body["public_address_override"]) \
                if "public_address_override" in body else cache.public_address_override
        except ValueError as exc:
            return err(422, "invalid_request", str(exc), {"field": "public_address_override"})
        lan_choice = body.get("selected_lan_ip", cache.selected_lan_ip) or None
        # The override also lives on the Profile (network.py prefers the profile's value), so keep both in step:
        # otherwise clearing it here would leave an old profile value in force.
        if "public_address_override" in body and override != getattr(prof, "public_address_override", None):
            changes["public_address_override"] = override

        # Ports and bind address are read by the game at start: only change them on a stopped, idle server.
        if "ports" in changes or "bind_ip" in changes:
            if eng.is_running(pid):
                return err(409, "server_running", "stop the server before changing its ports or bind address")
            busy = eng.busy_reason(pid)
            if busy:
                return err(409, "server_busy", f"wait until it finishes: {busy}")
        if new_ports is not None:
            bind_ip = str(changes.get("bind_ip", prof.bind_ip))
            others = {}
            for other in eng.list_profiles():
                if other.id == pid:
                    continue
                for proto, port, _role in other.ports.binds():
                    others[(proto, port)] = other.name
            for proto, port, role in new_ports.binds():
                if (proto, port) in others:
                    return err(409, "port_conflict",
                               f"{proto.upper()} port {port} is already used by the server '{others[(proto, port)]}'",
                               {"port": port, "protocol": proto, "role": role, "owner": others[(proto, port)]},
                               port=port)
            for proto, port, role in new_ports.binds():
                result = await asyncio.to_thread(probe, port, proto, bind_ip)
                if result == "bad_address":
                    return err(422, "invalid_request", f"{bind_ip} is not an address of this PC",
                               {"field": "bind_ip"})
                if result != "free":
                    return err(409, "port_conflict",
                               f"{proto.upper()} port {port} is in use by another program on this PC",
                               {"port": port, "protocol": proto, "role": role, "owner": "another program"},
                               port=port)
        if changes:
            try:
                prof = await asyncio.to_thread(eng.update_profile, pid, changes)
            except ValidationError as exc:
                e0 = exc.errors()[0] if exc.errors() else {}
                return err(422, "invalid_request", str(e0.get("msg", "invalid value")).replace("Value error, ", ""))
            except ValueError as exc:
                return err(422, "invalid_request", str(exc))
            except Exception as exc:  # noqa: BLE001 - the engine's OpError carries .code/.detail
                code = getattr(exc, "code", None)
                if code is None:
                    raise
                status = {"not_found": 404, "server_running": 409, "port_in_use": 409, "locked": 409}.get(code, 400)
                detail = getattr(exc, "detail", {}) or {}
                if code == "port_in_use":
                    return err(409, "port_conflict", str(exc), detail, port=detail.get("port"))
                return err(status, code, str(exc), detail)
        notice = None
        cache.public_address_override = override
        cache.selected_lan_ip = lan_choice
        if "ports" in changes or "bind_ip" in changes:
            cache.invalidate_queries()                 # old answers were about the old ports/address
        if "ports" in changes:
            cache.mark_firewall_stale("ports changed: run the firewall helper again")
            notice = PORT_CHANGE_NOTE
        save_cache(pid, cache)
        out = build(pid, prof, cache)
        out["notice"] = notice
        return out

    # ----- POST /connect/public-ip ------------------------------------------------------------------------
    @router.post("/profiles/{pid}/connect/public-ip")
    async def refresh_public_ip(pid: str) -> Any:
        prof = eng.get_profile(pid)
        if prof is None:
            return not_found()
        await asyncio.to_thread(pub.get, True)
        eng.kv_set("network:public_ip", pub.dump())
        return build(pid, prof, load_cache(pid))

    # ----- POST /connect/query-check ----------------------------------------------------------------------
    @router.post("/profiles/{pid}/connect/query-check")
    async def query_check(pid: str, request: Request) -> Any:
        prof = eng.get_profile(pid)
        if prof is None:
            return not_found()
        body = await _json_body(request)
        if isinstance(body, JSONResponse):
            return body
        scope = body.get("scope")
        if scope not in net.QUERY_SCOPES:
            return err(422, "invalid_request", "scope must be 'local' or 'hairpin'", {"field": "scope"})
        cache = load_cache(pid)
        port = prof.ports.query_udp                    # ALWAYS the profile's own query port, never from the body
        result = net.blank_query(scope)
        result["checked_at"] = net.utc_iso()
        if scope == "local":
            host = "127.0.0.1" if prof.bind_ip in ("0.0.0.0", "::") else prof.bind_ip
        else:
            host = cache.public.get("detected_ip")     # the DETECTED public address only (not a typed override)
        result["target"] = f"{host}:{port}" if host else None
        if not eng.is_running(pid):
            result.update(state="error", error="The server is not running, so nothing can answer. Start it first.")
        elif host is None:
            result.update(state="error", error="The public address is not known yet. Press Refresh first.")
        else:
            reply = await asyncio.to_thread(a2s, host, port, local_timeout if scope == "local" else hairpin_timeout)
            if reply.state == "answered":
                same = net.names_match(prof.hostname, reply.name)
                result.update(state="answered" if same else "mismatch", hostname=reply.name,
                              error=None if same else "A different server answered on this port.")
            elif reply.state == "timeout":
                result.update(state="timeout", error=reply.error)
            else:
                result.update(state="error", error=reply.error)
        cache.query[scope] = result
        save_cache(pid, cache)
        return build(pid, prof, cache)

    # ----- firewall -------------------------------------------------------------------------------------
    @router.post("/profiles/{pid}/firewall/helper")
    async def firewall_helper(pid: str, request: Request) -> Any:
        prof = eng.get_profile(pid)
        if prof is None:
            return not_found()
        body = await _json_body(request)
        if isinstance(body, JSONResponse):
            return body
        if eng.os_name != "windows":
            return err(409, "unsupported", "the firewall helper is for Windows; on Linux open the ports with your "
                                           "distribution's firewall tool (ufw, firewalld)")
        if not prof.install_root:
            return err(409, "no_install_root", "this server has no install folder yet")
        try:
            path = await asyncio.to_thread(net.write_firewall_helper, prof.install_root, prof.identity,
                                           prof.ports.game_udp, prof.ports.query_udp)
        except (OSError, ValueError) as exc:
            return err(500, "write_failed", f"could not write the helper: {exc}")
        cache = load_cache(pid)
        cache.firewall["helper_path"] = str(path)
        save_cache(pid, cache)
        revealed = False
        if body.get("reveal"):
            try:
                revealer(str(path))
                revealed = True
            except OSError as exc:
                log.warning("could not open Explorer for the firewall helper: %s", exc)
        return {"helper_path": str(path), "revealed": revealed, "firewall": cache.firewall}

    @router.get("/profiles/{pid}/firewall")
    async def firewall_state(pid: str) -> Any:
        prof = eng.get_profile(pid)
        if prof is None:
            return not_found()
        state = await asyncio.to_thread(net.firewall_rule_state, prof.identity,
                                        (prof.ports.game_udp, prof.ports.query_udp), firewall_runner, eng.os_name)
        cache = load_cache(pid)
        cache.firewall.update({k: state[k] for k in ("state", "checked_at", "error")})
        save_cache(pid, cache)
        return {**cache.firewall, "ports": state.get("ports")}

    # ----- RCON password ----------------------------------------------------------------------------------
    @router.post("/profiles/{pid}/rcon-password/reveal")
    async def reveal_rcon(pid: str) -> Any:
        # No request body is read on this route; the secret is only ever in this one response.
        if eng.get_profile(pid) is None:
            return not_found()
        now = clock()
        q = reveals[pid]
        while q and now - q[0] >= REVEAL_WINDOW_S:
            q.popleft()
        if len(q) >= REVEAL_LIMIT:
            wait = max(1, int(REVEAL_WINDOW_S - (now - q[0])) + 1)
            resp = err(429, "rate_limited", f"Shown {REVEAL_LIMIT} times this minute. Try again in {wait} s.",
                       {"retry_after_s": wait})
            resp.headers["Retry-After"] = str(wait)
            return resp
        q.append(now)
        password = eng.rcon_secret_get(pid)
        if password is None:
            return err(404, "no_rcon_password", "no RCON password is set for this server yet")
        return JSONResponse({"password": password}, headers={"Cache-Control": "no-store", "Pragma": "no-cache",
                                                             "X-HB-Secret": "1"})

    @router.post("/profiles/{pid}/rcon-password")
    async def rotate_rcon(pid: str) -> Any:
        if eng.get_profile(pid) is None:
            return not_found()
        if eng.is_running(pid):
            return err(409, "server_running", "stop the server before generating a new RCON password "
                                              "(the running game keeps the old one until it restarts)")
        busy = eng.busy_reason(pid)
        if busy:
            return err(409, "server_busy", f"wait until it finishes: {busy}")
        eng.rcon_secret_set(pid, secrets.token_urlsafe(18))
        log.info("RCON password regenerated for profile %s", pid)      # the event, never the value
        return {"ok": True, "rcon_password_set": True, "changed_at": net.utc_iso(),
                "message": "New RCON password saved. The server uses it from its next start."}

    return router
