"""Schedules: restart / wipe / update / backup at a local time, with in-game warnings.

Plain-English rules:
- Times are in the schedule's own IANA time zone (e.g. America/New_York), so "04:00" stays 04:00 local across
  daylight-saving changes. Epic Rust showed 04:00 but ran it in UTC; we do not.
- DST: a local time that does not exist (spring forward, e.g. 02:30) runs at the first valid minute after the gap
  (03:00). A local time that happens twice (fall back, 01:30) runs ONCE, at the first one.
- Every run is written to a ledger keyed by (schedule, occurrence time) BEFORE it is enqueued. The database refuses
  a second row with the same key, so an occurrence can never fire twice - even across engine restarts.
- Missed runs (engine was off): wipes are always skipped (never a surprise wipe at boot); restarts/updates follow
  the schedule's missed_policy ("skip" default, or "run_once" = one catch-up run, never a burst).
- The scheduler never touches processes. It only sends `say` warnings and enqueues normal operations.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import logging
from typing import TYPE_CHECKING
from zoneinfo import ZoneInfo

from .models import Schedule, ScheduleRule, iso

if TYPE_CHECKING:
    from .engine import Engine

log = logging.getLogger(__name__)
UTC = dt.timezone.utc


def resolve_local(naive: dt.datetime, tz: ZoneInfo) -> dt.datetime:
    """Turn a wall-clock time into a real instant (UTC), applying the DST rules above."""
    first = naive.replace(tzinfo=tz, fold=0)
    u0 = first.astimezone(UTC)
    if u0.astimezone(tz).replace(tzinfo=None) == naive:
        return u0                                   # normal or ambiguous (fold=0 = first occurrence)
    # Non-existent (inside a spring-forward gap): find the first instant whose local time is >= naive.
    u1 = naive.replace(tzinfo=tz, fold=1).astimezone(UTC)
    lo, hi = min(u0, u1), max(u0, u1)
    t = lo
    while t <= hi:
        if t.astimezone(tz).replace(tzinfo=None) >= naive:
            return t
        t += dt.timedelta(minutes=1)
    return hi


def _first_thursday(year: int, month: int) -> dt.date:
    d = dt.date(year, month, 1)
    return d + dt.timedelta(days=(3 - d.weekday()) % 7)


def candidate_days(rule: ScheduleRule, start: dt.date, count: int = 400):  # noqa: ANN201 - generator of dates
    d = start
    for _ in range(count):
        if rule.kind in ("daily", "every_hours"):
            yield d
        elif rule.kind == "weekly":
            if d.weekday() == rule.dow:
                yield d
        elif rule.kind == "monthly_first_thursday":
            if d == _first_thursday(d.year, d.month):
                yield d
        d += dt.timedelta(days=1)


def next_occurrence(rule: ScheduleRule, tz_name: str, after_utc: dt.datetime) -> dt.datetime:
    """The first occurrence strictly after `after_utc`, as an aware UTC datetime."""
    tz = ZoneInfo(tz_name)
    local_after = after_utc.astimezone(tz)
    hh, mm = (int(x) for x in rule.time.split(":"))
    start_day = local_after.date() - dt.timedelta(days=1)
    for day in candidate_days(rule, start_day):
        if rule.kind == "every_hours":
            times = [dt.time(h, 0) for h in range(0, 24, rule.hours or 24)]
        else:
            times = [dt.time(hh, mm)]
        for t in times:
            inst = resolve_local(dt.datetime.combine(day, t), tz)
            if inst > after_utc:
                return inst
    raise ValueError("no occurrence found within 400 days")


# Every action a schedule can have. "backup" (2026-10-28): a running server is stopped, backed up and started
# again (the existing backup operation), and the schedule keeps only its newest `keep_newest` backups.
SCHEDULE_ACTIONS = ("restart", "wipe_map", "wipe_full", "wipe_blueprints", "update", "backup")
DEFAULT_KEEP_NEWEST = 10
BACKUP_COPY = ("A running server is stopped, backed up and started again. This schedule keeps its newest "
               "{keep} backups; manual, pre-wipe and pre-restore backups are never removed by it.")


def keep_newest_of(s: object) -> int:
    """The schedule's keep_newest (default 10). Schedules saved before the field existed get the default."""
    from .backups import validate_keep_newest
    value = getattr(s, "keep_newest", None)
    return validate_keep_newest(DEFAULT_KEEP_NEWEST if value is None else value)


def backup_request(s: object) -> dict[str, object]:
    """What a scheduled backup passes to BackupManager.create (via the engine's backup operation).
    The archive is tagged kind="scheduled" + this schedule's id, so pruning only ever touches its own backups."""
    label = getattr(s, "label", "") or "backup"
    return {"label": f"scheduled: {label}", "kind": "scheduled", "schedule_id": getattr(s, "id"),
            "keep_newest": keep_newest_of(s)}


def warning_text(action: str, seconds: int) -> str:
    what = {"restart": "restart", "update": "update and restart", "wipe_map": "MAP WIPE",
            "wipe_full": "FULL WIPE", "wipe_blueprints": "BLUEPRINT WIPE",
            "backup": "restart for a backup"}.get(action, action)
    if seconds >= 120:
        span = f"{seconds // 60} minutes"
    elif seconds >= 60:
        span = "1 minute"
    else:
        span = "1 second" if seconds == 1 else f"{seconds} seconds"
    return f"Server {what} in {span}."


class Scheduler:
    def __init__(self, engine: "Engine", tick_s: float = 15.0, missed_grace_s: float = 120.0) -> None:
        self.engine = engine
        self.tick_s = tick_s
        self.missed_grace_s = missed_grace_s
        self._warned: set[tuple[str, str, int]] = set()
        self._task: asyncio.Task[None] | None = None

    def warned_until(self, schedule_id: str, occurrence_utc: str | None) -> int | None:
        """The smallest "seconds left" warning this scheduler already sent for one occurrence (None = none).
        Pass it to countdown.Countdown.run(warned_until=...) so players never get the same warning twice."""
        marks = [w for (sid, occ, w) in self._warned if sid == schedule_id and occ == occurrence_utc]
        return min(marks) if marks else None

    def refresh(self, s: Schedule, now: dt.datetime | None = None) -> Schedule:
        """Recompute next_utc / next_local for display and storage."""
        now = now or dt.datetime.now(UTC)
        nxt = next_occurrence(s.rule, s.tz, now)
        s.next_utc = iso(nxt)
        s.next_local = nxt.astimezone(ZoneInfo(s.tz)).isoformat(timespec="minutes")
        return s

    def start(self) -> None:
        self._task = asyncio.create_task(self._loop(), name="scheduler")

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except (asyncio.CancelledError, Exception):  # noqa: BLE001
                pass

    async def _loop(self) -> None:
        self.handle_missed()
        while True:
            try:
                await self.tick()
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 - a bad schedule must not stop the others
                log.exception("scheduler tick failed")
            await asyncio.sleep(self.tick_s)

    def handle_missed(self, now: dt.datetime | None = None) -> list[str]:
        """At engine start: decide what to do with occurrences that passed while the engine was off."""
        now = now or dt.datetime.now(UTC)
        notes: list[str] = []
        for s in self.engine.store.list_schedules():
            if not s.enabled or not s.next_utc:
                continue
            due = dt.datetime.fromisoformat(s.next_utc.replace("Z", "+00:00"))
            if due >= now - dt.timedelta(seconds=self.missed_grace_s):
                continue
            destructive = s.action.startswith("wipe")
            if destructive or s.missed_policy == "skip":
                self.engine.store.claim_occurrence(s.id, s.next_utc, "missed")
                notes.append(f"{s.id}: missed {s.action} at {s.next_utc} skipped")
            else:
                if self.engine.store.claim_occurrence(s.id, s.next_utc, "catch_up"):
                    self.engine.run_scheduled(s, catch_up=True)
                    notes.append(f"{s.id}: missed {s.action} run once now")
            self.engine.store.save_schedule(self.refresh(s, now))
        return notes

    async def tick(self, now: dt.datetime | None = None) -> None:
        now = now or dt.datetime.now(UTC)
        for s in self.engine.store.list_schedules():
            if not s.enabled:
                continue
            if not s.next_utc:
                self.engine.store.save_schedule(self.refresh(s, now))
                continue
            due = dt.datetime.fromisoformat(s.next_utc.replace("Z", "+00:00"))
            left = (due - now).total_seconds()
            for w in s.warnings:
                key = (s.id, s.next_utc, w)
                if 0 < left <= w and key not in self._warned and (left > w - max(self.tick_s * 2, 30)):
                    self._warned.add(key)
                    await self.engine.say(s.profile_id, warning_text(s.action, w))
            if left <= 0:
                if self.engine.store.claim_occurrence(s.id, s.next_utc, "fired"):
                    self.engine.run_scheduled(s)
                self.engine.store.save_schedule(self.refresh(s, now))
