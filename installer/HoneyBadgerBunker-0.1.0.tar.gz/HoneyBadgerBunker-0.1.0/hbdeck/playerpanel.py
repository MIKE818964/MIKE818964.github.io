"""The HoneyBadger Panel data file (WP45): build, validate, write and apply `panel.json`.

Plain-English map (docs/team/PANEL_PLAN_2026-10-28.md, WP45 + the frozen panel.json contract under WP44):

The in-game HoneyBadger Panel plugin (a separate repo, Builder A) reads ONE file:
    <install_root>/<framework>/data/HoneyBadgerPanel/panel.json
where <framework> is "carbon" or "oxide" (the plugin runs under a mod framework, so vanilla has no panel).
That file is the ONE source of truth: the Deck's live preview is driven by the exact same JSON the plugin reads,
so the preview can never drift from what players will see.

This module is pure engine logic (no FastAPI, no sockets) so it is easy to test:
- build_panel()         assembles the frozen panel.json dict from the profile, the engine's forced-wipe info and
                        the engine's connect strings (the owner NEVER types an address: the join lines come from
                        network.connect_info(), the wipe from wipe_calendar.forced_wipe_info()).
- validate_config()     checks the owner-editable fields (rules <= 10 lines, a safe alias, "r g b a" colours,
                        leaderboard rows 1-10, http(s)-or-empty URLs) and returns a normalised config.
- write_panel()         writes the file ATOMICALLY (os.replace, via profiles.atomic_write) and keeps up to 5
                        timestamped snapshots under a history/ folder (the WP47 snapshot pattern).
- write_new_revision()  bumps the integer `revision` and writes the new file.
- apply_revision()      sends `hbp.apply` over RCON and confirms by watching the console for
                        "[HoneyBadgerPanel] applied revision N"; on timeout or a stopped server it reports the
                        honest "saved; the panel updates when the server is running".

Every outside effect (the RCON send, the console read) is injected, so the tests use fakes and never a real server.
"""
from __future__ import annotations

import asyncio
import json
import re
import shutil
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Iterable

from .frameworks import detect_framework
from .models import utcnow
from .operations import OpError
from .profiles import atomic_write

# The panel.json shape version (bumped only if the FILE layout changes, not on every publish).
PANEL_SCHEMA = 1
# How many timestamped snapshots to keep under history/ (WP47 pattern).
SNAPSHOT_KEEP = 5

RULES_MAX = 10                 # the panel shows at most ten rule lines
LEADERBOARD_MIN = 1
LEADERBOARD_MAX = 10
# A chat command the plugin registers (default "info"): letters, digits and _ only, so it is a safe single token.
ALIAS_RE = re.compile(r"^[A-Za-z0-9_]{1,16}$")

# The console line the plugin prints after it re-reads the file (decision 1 in the plan). N is the revision.
APPLIED_MARKER = "[HoneyBadgerPanel] applied revision {revision}"
# What the Deck reports when the server is offline or did not confirm in time. Honest: it is saved, not live yet.
APPLY_PENDING_MESSAGE = "saved; the panel updates when the server is running"

# Default atomic-age theme as Rust CUI colours ("r g b a", each channel 0..1 - see HoneyBadgerDps.cs).
DEFAULT_THEME: dict[str, str] = {
    "background": "0.055 0.063 0.067 0.95",   # charcoal, like the DPS band
    "accent": "0.941 0.722 0.227 1",          # amber
    "text": "0.918 0.914 0.894 1",            # warm off-white
}


# =================================================================================================================
# Where the file lives (chosen by framework, never hard-coded)
# =================================================================================================================

def panel_framework(profile: Any) -> str:
    """Which mod framework this server runs: "carbon" or "oxide". The panel plugin needs one of them.

    Prefer the profile's own setting; if that is vanilla, fall back to whatever loader is actually on disk. Raise a
    plain OpError when neither applies, so the route can answer 409 (there is no framework to host the panel)."""
    fw = getattr(profile, "framework", None)
    if fw in ("carbon", "oxide"):
        return fw
    root = getattr(profile, "install_root", "") or ""
    detected = detect_framework(Path(root)) if root else None
    if detected in ("carbon", "oxide"):
        return detected
    raise OpError("this server has no mod framework (Carbon or Oxide), which the player panel needs", "no_framework")


def panel_data_dir(profile: Any) -> Path:
    """The plugin's data folder for this server: <install_root>/<framework>/data/HoneyBadgerPanel.

    Carbon keeps plugin data under carbon/data and Oxide under oxide/data (hbdeck/frameworks.py DATA_DIRS), so the
    folder is derived from the framework and the install root - never hard-coded to one loader."""
    root = getattr(profile, "install_root", "") or ""
    if not root:
        raise OpError("this server has no install folder yet", "no_install_root")
    return Path(root) / panel_framework(profile) / "data" / "HoneyBadgerPanel"


def panel_path(profile: Any) -> Path:
    """The panel.json file itself."""
    return panel_data_dir(profile) / "panel.json"


# =================================================================================================================
# Validation of the owner-editable fields
# =================================================================================================================

def _no_control(value: str, label: str) -> str:
    """Server config and a single CUI label are line based: a line break or NUL inside a value is never allowed."""
    if "\n" in value or "\r" in value or "\x00" in value:
        raise ValueError(f"the {label} cannot contain line breaks")
    return value


def _valid_url(value: Any, label: str) -> str:
    """An http(s) link, or empty. Never a bare word that a player cannot click."""
    v = str(value or "").strip()
    if not v:
        return ""
    if not re.match(r"^https?://", v, re.I):
        raise ValueError(f"the {label} must start with http:// or https:// (or be left empty)")
    return _no_control(v, label)


def parse_color(value: Any) -> tuple[float, float, float, float]:
    """Parse a Rust CUI colour string "r g b a" (four numbers, each 0..1). Raises ValueError on anything else."""
    parts = str(value or "").split()
    if len(parts) != 4:
        raise ValueError("a colour must be four numbers like \"0.9 0.7 0.2 1\" (red green blue alpha, each 0 to 1)")
    out: list[float] = []
    for p in parts:
        try:
            f = float(p)
        except (TypeError, ValueError) as exc:
            raise ValueError("a colour must be four numbers between 0 and 1") from exc
        if not 0.0 <= f <= 1.0:
            raise ValueError("every colour channel must be between 0 and 1")
        out.append(f)
    return out[0], out[1], out[2], out[3]


def _valid_color(value: Any, label: str) -> str:
    """Validate and normalise a colour to a tidy "r g b a" string."""
    r, g, b, a = parse_color(value)
    return " ".join(_num(x) for x in (r, g, b, a))


def _num(x: float) -> str:
    """A compact number: 1, 0.5, 0.941 (no trailing zeros, no exponent)."""
    return f"{x:.3f}".rstrip("0").rstrip(".") or "0"


def validate_config(raw: Any) -> dict[str, Any]:
    """Check and normalise the owner's panel settings. Raises ValueError with a plain-English message on bad input.

    Returns only the fields the owner controls; the engine-sourced fields (wipe, join strings) are added in
    build_panel() from the real engine data, never from this body."""
    if not isinstance(raw, dict):
        raise ValueError("the panel settings must be a JSON object")

    server_name = str(raw.get("server_name", "")).strip()
    if not server_name:
        raise ValueError("the server name shown on the panel cannot be empty")
    if len(server_name) > 120:
        raise ValueError("the server name is too long (at most 120 characters)")
    _no_control(server_name, "server name")

    rules_in = raw.get("rules", [])
    if isinstance(rules_in, str):
        lines = rules_in.splitlines()
    elif isinstance(rules_in, list):
        lines = [str(r) for r in rules_in]
    else:
        raise ValueError("rules must be a list of lines (or one text block)")
    rules = [ln.rstrip() for ln in lines if str(ln).strip() != ""]     # drop blank lines before counting
    if len(rules) > RULES_MAX:
        raise ValueError(f"the panel shows at most {RULES_MAX} rule lines; please shorten the list")
    for r in rules:
        _no_control(r, "a rule line")

    website_url = _valid_url(raw.get("website_url", ""), "website link")
    discord_url = _valid_url(raw.get("discord_url", ""), "Discord link")

    lb = raw.get("leaderboard") or {}
    if not isinstance(lb, dict):
        raise ValueError("the leaderboard setting must be an object")
    enabled = bool(lb.get("enabled", True))
    try:
        limit = int(lb.get("limit", LEADERBOARD_MAX))
    except (TypeError, ValueError) as exc:
        raise ValueError("the leaderboard row count must be a whole number") from exc
    if not LEADERBOARD_MIN <= limit <= LEADERBOARD_MAX:
        raise ValueError(f"the leaderboard shows between {LEADERBOARD_MIN} and {LEADERBOARD_MAX} rows")

    theme_in = raw.get("theme") or {}
    if not isinstance(theme_in, dict):
        raise ValueError("the theme must be an object with background, accent and text colours")
    theme = {key: _valid_color(theme_in.get(key, DEFAULT_THEME[key]), f"{key} colour")
             for key in ("background", "accent", "text")}

    alias = str(raw.get("alias", "info")).strip().lstrip("/")
    if not ALIAS_RE.match(alias):
        raise ValueError("the chat command can use letters, digits and _ only (at most 16 characters)")

    return {
        "server_name": server_name,
        "rules": rules,
        "website_url": website_url,
        "discord_url": discord_url,
        "leaderboard": {"enabled": enabled, "limit": limit},
        "theme": theme,
        "alias": alias,
    }


# =================================================================================================================
# Building the frozen panel.json
# =================================================================================================================

def default_config(profile: Any = None) -> dict[str, Any]:
    """Sensible starting settings for a server that has never published a panel yet."""
    name = (getattr(profile, "hostname", None) or getattr(profile, "name", None) or "HoneyBadger Server")
    url = getattr(profile, "url", "") or ""
    return {
        "server_name": name,
        "rules": [],
        "website_url": url,
        "discord_url": "",
        "leaderboard": {"enabled": True, "limit": LEADERBOARD_MAX},
        "theme": dict(DEFAULT_THEME),
        "alias": "info",
    }


def config_from_panel(panel: Any, profile: Any = None) -> dict[str, Any]:
    """Pull the owner-editable settings back out of a stored panel.json (for GET), with defaults for gaps."""
    cfg = default_config(profile)
    if not isinstance(panel, dict):
        return cfg
    if panel.get("server_name"):
        cfg["server_name"] = str(panel["server_name"])
    if isinstance(panel.get("rules"), list):
        cfg["rules"] = [str(r) for r in panel["rules"]]
    cfg["website_url"] = str(panel.get("website_url") or "")
    cfg["discord_url"] = str(panel.get("discord_url") or "")
    lb = panel.get("leaderboard")
    if isinstance(lb, dict):
        cfg["leaderboard"] = {"enabled": bool(lb.get("enabled", True)),
                              "limit": int(lb.get("limit", LEADERBOARD_MAX) or LEADERBOARD_MAX)}
    th = panel.get("theme")
    if isinstance(th, dict):
        for key in ("background", "accent", "text"):
            if th.get(key):
                cfg["theme"][key] = str(th[key])
    if panel.get("alias"):
        cfg["alias"] = str(panel["alias"])
    return cfg


def build_panel(profile: Any, *, forced_wipe: dict[str, Any] | None, connect: dict[str, Any] | None,
                config: dict[str, Any], revision: int) -> dict[str, Any]:
    """Assemble the exact panel.json the plugin reads. The join lines and the wipe come ONLY from the engine
    (connect / forced_wipe), so the owner never types an address and the preview cannot drift from the file."""
    fw = forced_wipe or {}
    cn = connect or {}
    return {
        "schema": PANEL_SCHEMA,
        "revision": int(revision),
        "server_name": config["server_name"],
        "rules": list(config["rules"]),
        # wipe: read-only, from wipe_calendar.forced_wipe_info(). The plugin ticks the countdown from wipe_target_utc.
        "wipe_target_utc": fw.get("next_utc"),
        "wipe_zone": fw.get("source_tz") or fw.get("tz"),
        # join: pre-built by network.connect_info(); null (unknown) when the address is not known - never invented.
        "join_lan": cn.get("lan_connect_command"),
        "join_public": cn.get("public_connect_command"),
        "website_url": config["website_url"],
        "discord_url": config["discord_url"],
        "theme": dict(config["theme"]),
        "leaderboard": dict(config["leaderboard"]),
        "alias": config["alias"],
    }


# =================================================================================================================
# Reading / writing the file (atomic, with snapshots)
# =================================================================================================================

def read_panel(profile: Any) -> dict[str, Any] | None:
    """The stored panel.json, or None if it was never published (or cannot be read)."""
    try:
        path = panel_path(profile)
    except OpError:
        return None
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _snapshot(path: Path, *, now: Callable[[], Any], keep: int) -> None:
    """Copy the current panel.json into history/ before it is overwritten, and keep only the newest `keep`."""
    hist = path.parent / "history"
    hist.mkdir(parents=True, exist_ok=True)
    stamp = now().strftime("%Y%m%dT%H%M%S_%f")
    shutil.copyfile(path, hist / f"panel-{stamp}.json")
    snaps = sorted(hist.glob("panel-*.json"))
    for old in snaps[:-keep] if keep > 0 else snaps:
        try:
            old.unlink()
        except OSError:
            pass


def write_panel(profile: Any, panel: dict[str, Any], *, platform: Any | None = None,
                now: Callable[[], Any] | None = None, keep: int = SNAPSHOT_KEEP) -> Path:
    """Write panel.json atomically (temp file + os.replace), snapshotting the previous version first."""
    now = now or utcnow
    path = panel_path(profile)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        _snapshot(path, now=now, keep=keep)
    atomic_write(path, json.dumps(panel, indent=2, ensure_ascii=False) + "\n", platform=platform)
    return path


def current_revision(profile: Any) -> int:
    """The revision of the stored panel.json, or 0 if none exists."""
    panel = read_panel(profile)
    if not panel:
        return 0
    try:
        return int(panel.get("revision", 0))
    except (TypeError, ValueError):
        return 0


def write_new_revision(profile: Any, config: dict[str, Any], *, forced_wipe: dict[str, Any] | None,
                       connect: dict[str, Any] | None, platform: Any | None = None,
                       now: Callable[[], Any] | None = None) -> tuple[dict[str, Any], int]:
    """Bump the revision, build the new panel from the config + engine facts, and write it. Returns (panel, rev)."""
    revision = current_revision(profile) + 1
    panel = build_panel(profile, forced_wipe=forced_wipe, connect=connect, config=config, revision=revision)
    write_panel(profile, panel, platform=platform, now=now)
    return panel, revision


# =================================================================================================================
# Applying a revision over RCON (confirm by watching the console)
# =================================================================================================================

def _pending(revision: int) -> dict[str, Any]:
    return {"applied": False, "revision": revision, "message": APPLY_PENDING_MESSAGE}


def _applied(revision: int) -> dict[str, Any]:
    return {"applied": True, "revision": revision, "message": f"applied revision {revision}"}


async def apply_revision(revision: int, *, online: bool, send: Callable[[str], Awaitable[str]],
                         tail: Callable[[], Iterable[str]], timeout_s: float = 8.0, interval_s: float = 0.25,
                         clock: Callable[[], float] = time.monotonic,
                         sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> dict[str, Any]:
    """Send `hbp.apply` and confirm by watching the console for "[HoneyBadgerPanel] applied revision N".

    `send` runs one RCON command and returns its reply text; `tail` returns the console lines seen since the send
    began. Both are injected, so tests drive this with no real server. On a stopped/offline server, a send failure,
    or a timeout, the result is the honest "saved; the panel updates when the server is running"."""
    marker = APPLIED_MARKER.format(revision=revision)
    if not online:
        return _pending(revision)
    try:
        reply = await send("hbp.apply")
    except Exception:  # noqa: BLE001 - any RCON failure means "not confirmed live", not an error to the owner
        return _pending(revision)
    if reply and marker in reply:
        return _applied(revision)
    deadline = clock() + timeout_s
    while clock() < deadline:
        for line in tail():
            if marker in line:
                return _applied(revision)
        await sleep(interval_s)
    for line in tail():                 # one last look after the deadline (the marker may have just landed)
        if marker in line:
            return _applied(revision)
    return _pending(revision)
