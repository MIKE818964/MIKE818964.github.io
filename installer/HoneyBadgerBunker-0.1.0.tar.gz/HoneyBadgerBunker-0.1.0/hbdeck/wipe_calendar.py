"""Facepunch's monthly forced wipe, worked out offline (no network, no keys).

The rule (verified live on Rust 2635 with `find wipetimer`, and on Facepunch's wiki page "server-wipe-timer"):
    wipetimer.wipedayofweek  = 4              (Thursday)
    wipetimer.wipehourofday  = 19             (19:00)
    wipetimer.wipetimezone   = Europe/London  (UK time: GMT in winter, BST in summer)
and the default frequency is "monthly", which means the FIRST Thursday of each month.
So the forced wipe is the first Thursday of the month at 19:00 London time. In winter that is 19:00 UTC; in
summer (British Summer Time) it is 18:00 UTC. zoneinfo knows the exact change-over dates, so we never hard-code
an offset.

Facepunch can add an extra, off-cycle wipe for a big update; that cannot be predicted and is not shown here.
This module is pure (no engine, no files): give it a time, it gives back the next wipe.
"""
from __future__ import annotations

import datetime as dt
from zoneinfo import ZoneInfo

FORCED_WIPE_TZ = "Europe/London"
FORCED_WIPE_HOUR = 19
THURSDAY = 3  # Python's weekday(): Monday = 0 ... Thursday = 3
RULE_TEXT = "first Thursday of each month at 19:00 UK time (Europe/London)"


def first_thursday(year: int, month: int) -> dt.date:
    """The first Thursday of a month. Example: 2026-11 -> 2026-11-05; 2027-04 -> 2027-04-01 (the 1st itself)."""
    first = dt.date(year, month, 1)
    return first + dt.timedelta(days=(THURSDAY - first.weekday()) % 7)


def forced_wipe_in_month(year: int, month: int, tz: str = FORCED_WIPE_TZ, hour: int = FORCED_WIPE_HOUR) -> dt.datetime:
    """That month's forced wipe as a UTC time (timezone-aware)."""
    day = first_thursday(year, month)
    local = dt.datetime(day.year, day.month, day.day, hour, 0, tzinfo=ZoneInfo(tz))
    return local.astimezone(dt.timezone.utc)


def next_forced_wipe(now: dt.datetime | None = None, tz: str = FORCED_WIPE_TZ,
                     hour: int = FORCED_WIPE_HOUR) -> dt.datetime:
    """The next forced wipe strictly after `now` (UTC-aware). At exactly 19:00 on wipe day the wipe is 'now',
    so the answer is next month's: a countdown never shows zero forever."""
    if now is None:
        now = dt.datetime.now(dt.timezone.utc)
    if now.tzinfo is None:
        raise ValueError("now must be timezone-aware (use UTC)")
    year, month = now.year, now.month
    # Look at this month first, then the next; two months always contain a future first Thursday.
    for _ in range(3):
        candidate = forced_wipe_in_month(year, month, tz, hour)
        if candidate > now:
            return candidate
        year, month = (year + 1, 1) if month == 12 else (year, month + 1)
    raise RuntimeError("no forced wipe found in three months")  # cannot happen; here so the loop is bounded


def _iso_utc(t: dt.datetime) -> str:
    return t.astimezone(dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def forced_wipe_info(now: dt.datetime | None = None, local_tz: dt.tzinfo | None = None) -> dict[str, str]:
    """What GET /engine returns as `forced_wipe`.

    next_utc    ISO UTC ("2026-11-05T19:00:00Z")
    next_local  the same moment in this PC's local time (or `local_tz` in tests), ISO with offset
    tz          the name of that local zone (Windows gives names like "Eastern Standard Time")
    source_tz   "Europe/London", the zone Facepunch's rule is written in
    rule        the rule in plain English
    """
    nxt = next_forced_wipe(now)
    local = nxt.astimezone(local_tz) if local_tz is not None else nxt.astimezone()   # no argument = this PC's zone
    tz_name = getattr(local_tz, "key", None) or local.tzname() or ""
    return {"next_utc": _iso_utc(nxt), "next_local": local.isoformat(timespec="seconds"), "tz": tz_name,
            "source_tz": FORCED_WIPE_TZ, "rule": RULE_TEXT}
