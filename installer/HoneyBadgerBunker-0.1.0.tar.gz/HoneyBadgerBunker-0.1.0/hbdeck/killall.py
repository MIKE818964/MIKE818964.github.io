"""Stop everything (guard G4): end every engine, game server, SteamCMD and helper that THIS data folder owns.

Used by `hbdeck kill-all --data <dir> [--list]`, the launcher's "Stop everything" menu line / `stopall` verb, and
POST /engine/kill-all. It works with no engine running at all (that is the point: it is the way out when the Deck
cannot open).

What counts as ours (never a "contains hbdeck" substring match):
- engines: the pid in engine.lock.json / engine.json / the registry, verified by pid + creation time AND a command
  line of `-m hbdeck serve --data <this folder>`;
- game servers: registry rows (pid + creation time + exact `+server.identity` token), or a process whose command line
  has the exact `+server.identity <id>` of one of this folder's profiles AND runs from that profile's server folder;
- SteamCMD / helpers: registry rows verified by pid + creation time.
- the Deck window ("shell"): the registry row `hbdeck shell` writes when the window opens (pid + creation time).
  It is ended LAST, after engines and servers: first a polite WM_CLOSE to its window (as if the user pressed X),
  then, only if it is still open after a short wait, the window process alone is terminated (never its process
  tree: the engine it started is its child and must finish its own graceful shutdown).
Anything matching an identity but running from a different folder is CONFLICTING (reported, never touched). A
process we cannot inspect is UNVERIFIABLE (reported, never touched).

Order (one deadline for all of it):
  1. barrier: hold <data>/killall.lock - no engine of this folder starts a server while it is held
  2. ask every live engine of this folder to shut down (HTTP), or `systemctl stop` its unit under systemd
     (otherwise Restart=on-failure would bring it straight back)
  3. graceful RCON "server.save" + "quit" for servers whose password we hold
  4. terminate, then kill, whatever verified target is still alive; verify death from the OS
  5. report survivors, permission failures, forced stops; exit code 1 if a verified target survived
  6. clean metadata only for processes verified dead, only while holding the needed locks; locks are never deleted
`--list` does steps "find" and "report" only: no lock, no signal, no file written or deleted.
"""
from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import subprocess
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import psutil

from . import guards
from .platform import LockBusy, current_platform, process_liveness
from .platform.base import Platform
from .profiles import canonical_path

DEFAULT_DEADLINE_S = guards.ENGINE_SHUTDOWN_BUDGET_S + 30


@dataclass
class Target:
    kind: str                      # engine | game | steamcmd | helper | shell
    pid: int
    create_time: float | None
    label: str
    source: str                    # registry | engine.json | engine.lock.json | process scan
    row_id: int | None = None
    profile_id: str | None = None
    identity: str | None = None
    rcon_port: int | None = None
    install_root: str | None = None
    systemd_unit: str | None = None
    outcome: str = "pending"       # graceful | closed | forced | survived | permission_denied | already_gone

    def as_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "pid": self.pid, "label": self.label, "source": self.source,
                "profile_id": self.profile_id, "identity": self.identity, "outcome": self.outcome,
                "systemd_unit": self.systemd_unit}


@dataclass
class KillAllReport:
    data_dir: str
    listed_only: bool = False
    targets: list[Target] = field(default_factory=list)
    conflicting: list[dict[str, Any]] = field(default_factory=list)
    unverifiable: list[dict[str, Any]] = field(default_factory=list)
    stale_rows: list[int] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    cleaned: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def survivors(self) -> list[Target]:
        return [t for t in self.targets if t.outcome in ("survived", "permission_denied")]

    @property
    def exit_code(self) -> int:
        if self.listed_only:
            return 0
        return 1 if (self.survivors or self.errors) else 0

    def summary(self) -> str:
        if self.listed_only:
            return f"{len(self.targets)} to stop, {len(self.conflicting)} conflicting, {len(self.unverifiable)} unverifiable"
        g = sum(t.outcome in ("graceful", "closed") for t in self.targets)
        f = sum(t.outcome == "forced" for t in self.targets)
        return (f"{g} stopped gracefully, {f} forced, {len(self.survivors)} still running"
                + (f", {len(self.conflicting)} conflicting left alone" if self.conflicting else ""))

    def as_dict(self) -> dict[str, Any]:
        return {"data_dir": self.data_dir, "listed_only": self.listed_only,
                "targets": [t.as_dict() for t in self.targets], "conflicting": self.conflicting,
                "unverifiable": self.unverifiable, "warnings": self.warnings, "cleaned": self.cleaned,
                "errors": self.errors, "survivors": [t.pid for t in self.survivors], "summary": self.summary(),
                "exit_code": self.exit_code}

    def text(self) -> str:
        lines = [f"HoneyBadger Bunker - Stop everything ({'list only, nothing was changed' if self.listed_only else 'done'})",
                 f"data folder: {self.data_dir}"]
        if not self.targets:
            lines.append("Nothing of this folder is running.")
        for t in self.targets:
            state = (("would be closed" if t.kind == "shell" else "would be stopped") if self.listed_only
                     else t.outcome.replace("_", " "))
            lines.append(f"  [{t.kind}] pid {t.pid} {t.label}: {state}")
        for c in self.conflicting:
            lines.append(f"  [left alone] pid {c.get('pid')} {c.get('why')}")
        for u in self.unverifiable:
            lines.append(f"  [cannot check] pid {u.get('pid')} {u.get('why')}")
        lines += [f"  WARNING: {w}" for w in self.warnings]
        lines += [f"  ERROR: {e}" for e in self.errors]
        if not self.listed_only:
            lines.append(self.summary())
        return "\n".join(lines)


# =====================================================================================================================
# reading this folder's records WITHOUT changing anything
# =====================================================================================================================
def _ro_connect(path: Path) -> sqlite3.Connection | None:
    """Open a SQLite file read-only without creating anything.

    First "mode=ro" (sees the newest rows even while an engine is writing them, through its WAL), then, when that
    is not possible (no engine: the WAL index file is gone and read-only mode may not recreate it), "immutable"
    (reads the main file as it is, takes no locks and writes nothing).
    """
    if not path.exists():
        return None
    base = path.resolve().as_uri()
    # No WAL file = everything is in the main file: "immutable" reads it without creating -wal/-shm files
    # (strictly inert, as --list must be). A WAL file present = an engine is (or was) writing: read through it.
    has_wal = Path(str(path) + "-wal").exists()
    for query in (("?mode=ro", "?immutable=1") if has_wal else ("?immutable=1",)):
        try:
            db = sqlite3.connect(base + query, uri=True, check_same_thread=False)
            db.row_factory = sqlite3.Row
            db.execute("SELECT 1 FROM sqlite_master LIMIT 1").fetchall()
            return db
        except sqlite3.Error:
            continue
    return None


def _registry_rows(data_dir: Path) -> list[dict[str, Any]]:
    db = _ro_connect(data_dir / "ownership.db")
    if db is None:
        return []
    try:
        return [dict(r) for r in db.execute("SELECT * FROM owned ORDER BY id").fetchall()]
    except sqlite3.Error:
        return []
    finally:
        db.close()


def _profiles(data_dir: Path) -> list[dict[str, Any]]:
    db = _ro_connect(data_dir / "state.db")
    if db is None:
        return []
    try:
        out = []
        for r in db.execute("SELECT id, data FROM profiles").fetchall():
            try:
                out.append(json.loads(r["data"]))
            except ValueError:
                continue
        return out
    except sqlite3.Error:
        return []
    finally:
        db.close()


def _secret(data_dir: Path, ref: str) -> bytes | None:
    db = _ro_connect(data_dir / "state.db")
    if db is None:
        return None
    try:
        rows = db.execute("SELECT blob FROM secrets WHERE ref=?", (ref,)).fetchall()
        return bytes(rows[0]["blob"]) if rows else None
    except sqlite3.Error:
        return None
    finally:
        db.close()


def _systemd_unit(pid: int) -> str | None:
    """The systemd service a process belongs to (Linux), from /proc/<pid>/cgroup."""
    if not sys.platform.startswith("linux"):
        return None
    try:
        text = Path(f"/proc/{pid}/cgroup").read_text()
    except OSError:
        return None
    for part in text.replace("\n", "/").split("/"):
        if part.endswith(".service") and part not in ("user@.service",) and not part.startswith("user@"):
            return part
    return None


def _cmdline(pid: int) -> list[str] | None:
    try:
        return psutil.Process(pid).cmdline()
    except psutil.Error:
        return None


def _runs_from(pid: int, install_root: str) -> bool | None:
    """Does this process run from the server folder (working directory or program inside it)? None = cannot tell."""
    root = canonical_path(install_root)
    try:
        p = psutil.Process(pid)
        cwd = canonical_path(p.cwd())
    except psutil.Error:
        return None
    if cwd == root or cwd.startswith(root + os.sep):
        return True
    try:
        exe = canonical_path(p.exe())
        return exe.startswith(root + os.sep)
    except psutil.Error:
        return None


def collect(data_dir: Path, *, exclude_pids: Iterable[int] = (), exclude_instance: str | None = None,
            include_engines: bool = True, process_iter: Any = None) -> KillAllReport:
    """Find everything this data folder owns that is alive. Changes NOTHING (used by --list too)."""
    data_dir = Path(data_dir).resolve()
    rep = KillAllReport(data_dir=str(data_dir))
    skip = {os.getpid(), *[int(p) for p in exclude_pids if p]}
    seen: set[int] = set()

    def add(t: Target) -> None:
        if t.pid in skip or t.pid in seen:
            return
        seen.add(t.pid)
        rep.targets.append(t)

    # ---- engines --------------------------------------------------------------------------------------------
    if include_engines:
        cands: list[tuple[Any, Any, str]] = []
        for name in ("engine.lock.json", "engine.json"):
            info = guards.read_json(data_dir / name) or {}
            if info.get("pid"):
                cands.append((info.get("pid"), info.get("create_time"), name))
        for row in _registry_rows(data_dir):
            if row["kind"] == "engine":
                cands.append((row["pid"], row["create_time"], "registry"))
        for pid, ct, source in cands:
            if int(pid) in skip or int(pid) in seen:
                continue
            verdict = guards.classify_engine_pid(pid, ct, data_dir)
            if verdict == "ours":
                add(Target("engine", int(pid), ct if ct else guards.create_time_of(int(pid)), "HoneyBadger Bunker engine",
                           source, systemd_unit=_systemd_unit(int(pid))))
            elif verdict == "unknown":
                rep.unverifiable.append({"pid": int(pid), "why": f"engine pid from {source}: access denied"})
    # ---- registry: game servers, SteamCMD, helpers ------------------------------------------------------------
    for row in _registry_rows(data_dir):
        kind, pid, ct = row["kind"], int(row["pid"]), row["create_time"]
        if kind == "engine" or pid in skip or (exclude_instance and row.get("instance") == exclude_instance):
            continue
        live = process_liveness(pid, ct)
        if live == "dead":
            rep.stale_rows.append(int(row["id"]))
            continue
        if live == "unknown":
            rep.unverifiable.append({"pid": pid, "why": f"registered {kind}: access denied"})
            continue
        if kind == "game":
            cmd = _cmdline(pid)
            if cmd is None:
                rep.unverifiable.append({"pid": pid, "why": "registered game server: command line not readable"})
                continue
            if not guards.token_matches(cmd, row.get("identity"), []):
                rep.stale_rows.append(int(row["id"]))      # same pid+time but not our world: not ours
                continue
        label = {"game": f"game server '{row.get('identity')}'", "steamcmd": f"SteamCMD for '{row.get('identity')}'",
                 "helper": "helper", "shell": "HoneyBadger Bunker window"}.get(kind, kind)
        add(Target(kind, pid, ct, label, "registry", row_id=int(row["id"]), profile_id=row.get("profile_id"),
                   identity=row.get("identity"), install_root=row.get("install_root")))
        if kind == "steamcmd":
            rep.warnings.append(f"SteamCMD (pid {pid}) is updating '{row.get('identity')}'. Ending it can leave a "
                                "half-finished download; run Update again afterwards.")
    # ---- process scan for this folder's profiles (orphans the registry lost) ------------------------------------
    profiles = _profiles(data_dir)
    for prof in profiles:
        identity = prof.get("identity")
        root = prof.get("install_root")
        if not identity or not root:
            continue
        ports = prof.get("ports") or {}
        res = guards.scan_server_processes(identity, [], ["RustDedicated.exe", "RustDedicated"],
                                           exclude_pids=skip, process_iter=process_iter)
        for m in res.matches:
            if m.pid in seen:
                continue
            if not any(r.startswith("identity") for r in m.reasons):
                continue
            here = _runs_from(m.pid, root)
            if here is None:
                rep.unverifiable.append({"pid": m.pid, "why": f"identity {identity}: folder not readable"})
            elif here:
                add(Target("game", m.pid, m.create_time, f"game server '{identity}' (found by scan)", "process scan",
                           profile_id=prof.get("id"), identity=identity, rcon_port=ports.get("rcon_tcp"),
                           install_root=root))
            else:
                rep.conflicting.append({"pid": m.pid, "why": f"uses identity '{identity}' but runs from another "
                                                             "folder (another Deck's server?)"})
        for u in res.unverifiable:
            rep.unverifiable.append({"pid": u.pid, "why": f"{u.name}: command line not readable"})
        if res.error:
            rep.errors.append(f"process scan failed: {res.error}")
    # rcon ports for registry game rows
    by_id = {p.get("id"): p for p in profiles}
    for t in rep.targets:
        if t.kind == "game" and t.rcon_port is None and t.profile_id in by_id:
            t.rcon_port = (by_id[t.profile_id].get("ports") or {}).get("rcon_tcp")
    rep.targets.sort(key=lambda t: t.kind == "shell")      # the window is always ended last (stable sort)
    return rep


# =====================================================================================================================
# acting
# =====================================================================================================================
async def rcon_save_and_quit(host: str, port: int, password: str, pid: int, create_time: float | None,
                             deadline_s: float) -> bool:
    """Ask a server to save and quit over WebRCON; True if the process then ended within the deadline."""
    from .rcon import RconClient, RconUnavailable
    if not port or not password:
        return False
    loop = asyncio.get_running_loop()
    end = loop.time() + max(1.0, deadline_s)
    client = RconClient(host, int(port), password, backoff_cap_s=1.0, connect_timeout_s=3.0, probation_s=0.2)
    client.start()
    try:
        if not await client.wait_ready(min(10.0, max(0.1, end - loop.time()))):
            return False
        try:
            await client.command("server.save", timeout=min(30.0, max(0.5, end - loop.time())))
        except (RconUnavailable, asyncio.TimeoutError):
            pass
        try:
            await client.command("quit", timeout=min(5.0, max(0.5, end - loop.time())), quiet_s=0.1)
        except Exception:  # noqa: BLE001 - the socket closes when it quits
            pass
        while loop.time() < end:
            if process_liveness(pid, create_time) == "dead":
                return True
            await asyncio.sleep(0.1)
        return process_liveness(pid, create_time) == "dead"
    finally:
        await client.stop()


def _ask_engine(data_dir: Path, t: Target, use_systemctl: bool, rep: KillAllReport) -> None:
    """Graceful engine stop: systemctl under systemd (or Restart=on-failure revives it), else HTTP shutdown."""
    if t.systemd_unit and use_systemctl:
        try:
            subprocess.Popen(["systemctl", "stop", "--no-block", t.systemd_unit], stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).wait(30)
            return
        except (OSError, subprocess.TimeoutExpired) as exc:
            rep.warnings.append(f"systemctl stop {t.systemd_unit} failed: {exc}")
    info = guards.read_json(data_dir / "engine.json") or {}
    if int(info.get("pid") or 0) != t.pid or not info.get("token"):
        return
    from .server import engine_request
    try:
        engine_request(info, "POST", "/engine/shutdown", timeout=5)
    except Exception as exc:  # noqa: BLE001 - it will be terminated in step 4
        rep.warnings.append(f"engine pid {t.pid} did not answer the shutdown request ({exc})")


def _end(platform: Platform, t: Target, until: float) -> None:
    """Terminate -> kill -> verify one target (and everything it started)."""
    if process_liveness(t.pid, t.create_time) == "dead":
        if t.outcome == "pending":
            t.outcome = "already_gone"
        return
    try:
        platform.terminate_tree(t.pid)
        if not platform.wait_dead(t.pid, t.create_time, max(0.5, min(10.0, until - time.monotonic()))):
            platform.kill_tree(t.pid)
    except psutil.AccessDenied:
        t.outcome = "permission_denied"
        return
    except Exception:  # noqa: BLE001
        pass
    if platform.wait_dead(t.pid, t.create_time, max(0.5, min(10.0, until - time.monotonic()))):
        t.outcome = "forced"
    else:
        try:
            psutil.Process(t.pid).kill()
        except psutil.AccessDenied:
            t.outcome = "permission_denied"
            return
        except psutil.Error:
            pass
        t.outcome = "forced" if platform.wait_dead(t.pid, t.create_time, 2) else "survived"


WM_CLOSE = 0x0010


def _windows_of(pid: int) -> list[int]:
    """Handles of the visible top-level windows that belong to process `pid` (Windows only; [] elsewhere)."""
    if os.name != "nt":
        return []
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.windll.user32
    found: list[int] = []
    proc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def each(hwnd, _lparam):  # noqa: ANN001 - ctypes callback
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value == pid and user32.IsWindowVisible(hwnd):
            found.append(int(hwnd))
        return True
    user32.EnumWindows(proc(each), 0)
    return found


def _post_message(hwnd: int, msg: int) -> bool:
    import ctypes
    return bool(ctypes.windll.user32.PostMessageW(hwnd, msg, 0, 0))


def close_window_of(pid: int, *, finder: Any = None, poster: Any = None) -> int:
    """Ask every window of process `pid` to close (WM_CLOSE, the same message the X button sends).
    Returns how many windows were asked. finder/poster are injectable for tests."""
    finder = finder or _windows_of
    poster = poster or _post_message
    asked = 0
    for hwnd in finder(pid):
        try:
            if poster(hwnd, WM_CLOSE):
                asked += 1
        except OSError:
            continue
    return asked


def end_shell(t: Target, until: float, data_dir: Path, *, closer: Any = None, wait_s: float = 10.0) -> None:
    """End the Deck window: WM_CLOSE first and wait (bounded); then terminate/kill THAT process only.

    Its process tree is never killed: the engine was started by the window, so it is the window's child, and it
    must be left to finish (or to be ended by step 2 above), never be killed as a side effect of closing a window."""
    closer = closer or close_window_of
    try:
        asked = closer(t.pid)
    except Exception:  # noqa: BLE001 - no window API: fall through to terminate
        asked = 0
    budget = max(0.5, min(wait_s, until - time.monotonic()))
    if asked:
        end = time.monotonic() + budget
        while time.monotonic() < end:
            if process_liveness(t.pid, t.create_time) == "dead":
                t.outcome = "closed"
                return
            time.sleep(0.1)
    for action in ("terminate", "kill"):
        try:
            proc = psutil.Process(t.pid)
            if t.create_time and abs(proc.create_time() - t.create_time) >= 1.0:
                t.outcome = "already_gone"          # the pid now belongs to another program: never touch it
                return
            getattr(proc, action)()
            proc.wait(timeout=max(0.5, min(5.0, until - time.monotonic())))
        except psutil.AccessDenied:
            t.outcome = "permission_denied"
            return
        except psutil.NoSuchProcess:
            pass
        except psutil.TimeoutExpired:
            continue
        if process_liveness(t.pid, t.create_time) == "dead":
            t.outcome = "forced"
            return
    t.outcome = "survived"


def kill_all(data_dir: Path, *, list_only: bool = False, deadline_s: float = DEFAULT_DEADLINE_S,
             exclude_pids: Iterable[int] = (), exclude_instance: str | None = None, include_engines: bool = True,
             platform: Platform | None = None, use_systemctl: bool = True, process_iter: Any = None) -> KillAllReport:
    data_dir = Path(data_dir).resolve()
    if list_only:
        rep = collect(data_dir, exclude_pids=exclude_pids, exclude_instance=exclude_instance,
                      include_engines=include_engines, process_iter=process_iter)
        rep.listed_only = True
        return rep
    plat = platform or current_platform()
    until = time.monotonic() + max(1.0, deadline_s)
    barrier = plat.lock(guards.barrier_path(data_dir))
    try:
        barrier.acquire()
    except LockBusy:
        rep = KillAllReport(data_dir=str(data_dir))
        rep.errors.append("Stop everything is already running for this folder")
        return rep
    try:
        rep = collect(data_dir, exclude_pids=exclude_pids, exclude_instance=exclude_instance,
                      include_engines=include_engines, process_iter=process_iter)
        # 2. engines first: they save and stop their own servers
        engines = [t for t in rep.targets if t.kind == "engine"]
        for t in engines:
            _ask_engine(data_dir, t, use_systemctl, rep)
        for t in engines:
            if plat.wait_dead(t.pid, t.create_time, max(0.0, until - time.monotonic() - 15)):
                t.outcome = "graceful"
        # 3. graceful RCON quit for servers still alive whose password we hold
        games = [t for t in rep.targets if t.kind == "game" and process_liveness(t.pid, t.create_time) != "dead"]
        for t in rep.targets:
            if t.kind == "game" and t not in games and t.outcome == "pending":
                t.outcome = "graceful"              # its engine stopped it
        jobs = []
        for t in games:
            pw = None
            blob = _secret(data_dir, f"{t.profile_id}:rcon") if t.profile_id else None
            if blob is not None:
                try:
                    pw = plat.unprotect(blob).decode()
                except Exception:  # noqa: BLE001 - another user's DPAPI secret: no graceful path
                    pw = None
            if pw and t.rcon_port:
                jobs.append((t, pw))
        if jobs:
            budget = max(1.0, min(60.0, until - time.monotonic() - 15))

            async def graceful_all() -> list[bool]:
                return await asyncio.gather(*(rcon_save_and_quit("127.0.0.1", t.rcon_port, pw, t.pid, t.create_time,
                                                                 budget) for t, pw in jobs))
            try:
                results = asyncio.run(graceful_all())
            except Exception as exc:  # noqa: BLE001
                rep.warnings.append(f"graceful RCON stop failed: {exc}")
                results = [False] * len(jobs)
            for (t, _pw), ok in zip(jobs, results):
                if ok:
                    t.outcome = "graceful"
        # 4. terminate whatever verified target is still alive; the Deck window (shell) last of all
        for t in sorted(rep.targets, key=lambda x: x.kind == "shell"):
            if process_liveness(t.pid, t.create_time) == "dead":
                if t.outcome == "pending":
                    t.outcome = "already_gone"
                continue
            if t.kind == "shell":
                end_shell(t, until, data_dir)
            else:
                _end(plat, t, until)
        # 6. metadata cleanup (only for verified-dead processes, only with the locks held)
        _cleanup(data_dir, plat, rep)
        return rep
    finally:
        barrier.release()


def _cleanup(data_dir: Path, plat: Platform, rep: KillAllReport) -> None:
    dead_rows = list(rep.stale_rows)
    dead_rows += [t.row_id for t in rep.targets if t.row_id and process_liveness(t.pid, t.create_time) == "dead"]
    if (data_dir / "ownership.db").exists() and dead_rows:
        from .registry import OwnershipRegistry
        reg = OwnershipRegistry(data_dir / "ownership.db")
        try:
            for rid in dead_rows:
                reg.remove_row(rid)
            rep.cleaned.append(f"{len(dead_rows)} registry row(s)")
        finally:
            reg.close()
    # engine.json: only when no engine holds the folder and its pid is verified gone (or re-used by another program)
    lk = plat.lock(data_dir / "engine.lock") if (data_dir / "engine.lock").exists() else None
    held = False
    if lk is not None:
        try:
            lk.acquire()
            held = True
        except LockBusy:
            held = False
    if lk is None or held:
        try:
            info = guards.read_json(data_dir / "engine.json")
            if info and guards.classify_engine_pid(info.get("pid"), info.get("create_time"), data_dir) in ("dead", "other"):
                (data_dir / "engine.json").unlink()
                rep.cleaned.append("engine.json")
        except OSError:
            pass
        finally:
            if lk is not None and held:
                lk.release()
    # pid files in the server folders: only with that folder's lock, only for a verified-dead pid
    for prof in _profiles(data_dir):
        root = prof.get("install_root")
        rec = guards.read_pid_file(Path(root)) if root else None
        if not rec:
            continue
        if rec.get("pid") and process_liveness(rec.get("pid"), rec.get("create_time")) != "dead":
            continue
        flk = plat.lock(Path(root) / "hbdeck.lock")
        try:
            flk.acquire()
        except (LockBusy, OSError):
            continue
        try:
            if guards.remove_pid_file_if(Path(root), rec.get("run_id")):
                rep.cleaned.append(str(guards.pid_file(Path(root))))
        finally:
            flk.release()


def offline_status(data_dir: Path) -> KillAllReport:
    """For `hbdeck status` with no engine: what of this folder is still running (= orphans)."""
    return collect(data_dir)
