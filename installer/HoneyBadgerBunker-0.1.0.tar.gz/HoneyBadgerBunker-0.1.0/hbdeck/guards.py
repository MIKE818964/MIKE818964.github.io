"""Process guards: the small, testable building blocks that keep "one engine per folder" and "one server per world".

Background (28 Oct 2026): three RustDedicated processes and two engines were found running at once. The plan in
docs/team/guards/GUARD_PLAN_2026-10-28.md fixes that with four guards. This module holds the pieces they share:

- Engine singleton (G2): the kernel file lock <data>/engine.lock is THE gate. Who holds it is written next to it in
  <data>/engine.lock.json (pid, process creation time, engine instance id, data folder, port) AFTER the lock is
  taken. A held lock means "refuse", even when the other engine's web page does not answer.
- Heartbeat (G2): <data>/heartbeat.json is rewritten every 30 s while the engine runs and marked clean on a normal
  exit. Found unclean at the next start = the last session crashed or was killed.
- Server singleton (G3): a pid file <install>/hbdeck.pid ("starting" before the spawn, then the real pid), a scan
  of every process command line for the EXACT tokens `+server.identity <id>` / `+server.port <n>` (never a
  substring match), and machine-wide reservation locks per identity and per port.
- Stop everything (G4): the kill-all barrier lock <data>/killall.lock; while it is held no engine starts a server.

Everything that decides "is that process ours?" uses pid + creation time + exact command-line tokens. A process
we are not allowed to inspect (access denied) is UNKNOWN, and unknown is treated as "may be running".
"""
from __future__ import annotations

import json
import os
import re
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Iterator

import psutil

from .platform import LockBusy, process_liveness
from .platform.base import FileLock, Platform
from .profiles import atomic_write, canonical_path

# ----- shared numbers and texts -----------------------------------------------------------------------------------
EXIT_ALREADY_RUNNING = 3                 # CLI and launcher exit code when this data folder already has an engine
HEARTBEAT_INTERVAL_S = 30.0
OPS_QUIESCE_S = 30.0                     # engine shutdown: time for running jobs to stop (file work finishes first)
SERVER_STOP_CAP_S = 270.0                # engine shutdown: one server's save+quit budget is capped at this
ESCALATION_RESERVE_S = 30.0              # engine shutdown: terminate -> kill -> verify after the save budget
ENGINE_SHUTDOWN_BUDGET_S = OPS_QUIESCE_S + SERVER_STOP_CAP_S + ESCALATION_RESERVE_S   # 330 s; systemd waits +45 s

ALREADY_RUNNING_TEXT = ("HoneyBadger Bunker is already running from this folder (pid {pid}, port {port}). "
                        "Use that window, or run `hbdeck stop` first.")

PORT_TOKENS = ("+server.port", "+rcon.port", "+server.queryport", "+app.port")
IDENTITY_TOKEN = "+server.identity"


def already_running_message(pid: Any, port: Any) -> str:
    return ALREADY_RUNNING_TEXT.format(pid=pid if pid else "unknown", port=port if port else "unknown")


class EngineAlreadyRunning(RuntimeError):
    """Another engine owns this data folder. str(exc) is the exact sentence the user sees (exit code 3)."""

    def __init__(self, pid: Any = None, port: Any = None, reason: str = "") -> None:
        self.pid, self.port, self.reason = pid, port, reason
        super().__init__(already_running_message(pid, port))


def now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def read_json(path: Path) -> dict[str, Any] | None:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def create_time_of(pid: int) -> float | None:
    try:
        return psutil.Process(pid).create_time()
    except psutil.Error:
        return None


# =====================================================================================================================
# G2: is that pid an engine of OURS? (stale-pid rule)
# =====================================================================================================================
def _arg_after(cmdline: list[str], flag: str) -> str | None:
    for i, a in enumerate(cmdline):
        if a == flag and i + 1 < len(cmdline):
            return cmdline[i + 1]
        if a.startswith(flag + "="):
            return a.split("=", 1)[1]
    return None


def is_engine_cmdline(cmdline: list[str], data_dir: Path | None = None) -> bool:
    """True when this command line is `<python> -m hbdeck serve ...` (optionally for exactly this data folder).

    Exact tokens only: "-m" followed by the token "hbdeck", and the token "serve". A program that merely has the
    word hbdeck somewhere in a path is NOT an engine.
    """
    module = any(cmdline[i] == "-m" and cmdline[i + 1] == "hbdeck" for i in range(len(cmdline) - 1))
    launcher = any(Path(a).name.lower() == "hb_launch.pyw" for a in cmdline)
    if not (module or launcher) or "serve" not in cmdline:
        return False
    if data_dir is None:
        return True
    d = _arg_after(cmdline, "--data")
    return d is not None and canonical_path(d) == canonical_path(data_dir)


def classify_engine_pid(pid: Any, create_time: Any, data_dir: Path | None = None) -> str:
    """"ours" (a live engine of ours), "dead", "other" (pid re-used by another program) or "unknown".

    Rule (Hermes): pid alive AND command line is our engine AND creation time within 1 s of the stored one.
    Access denied anywhere = "unknown" (the caller treats unknown as alive).
    """
    if not pid:
        return "dead"
    try:
        p = psutil.Process(int(pid))
        ct = p.create_time()
        if create_time is not None and abs(ct - float(create_time)) >= 1.0:
            return "other"
        if p.status() == psutil.STATUS_ZOMBIE:
            return "dead"
        cmd = p.cmdline()
    except psutil.NoSuchProcess:
        return "dead"
    except (psutil.AccessDenied, psutil.Error):
        return "unknown"
    if not cmd:
        return "unknown"
    return "ours" if is_engine_cmdline(cmd, data_dir) else "other"


# =====================================================================================================================
# G2: engine lock owner record + heartbeat
# =====================================================================================================================
def owner_file(data_dir: Path) -> Path:
    return Path(data_dir) / "engine.lock.json"


def write_owner(data_dir: Path, info: dict[str, Any]) -> None:
    atomic_write(owner_file(data_dir), json.dumps(info, indent=1))


def read_owner(data_dir: Path) -> dict[str, Any] | None:
    return read_json(owner_file(data_dir))


def engine_lock_held(platform: Platform, data_dir: Path) -> bool:
    """Is <data>/engine.lock held by a live process right now? (try to take it; give it straight back)"""
    path = Path(data_dir) / "engine.lock"
    if not path.exists():
        return False
    lk = platform.lock(path)
    try:
        lk.acquire()
    except LockBusy:
        return True
    lk.release()
    return False


def claim_folder(platform: Platform, data_dir: Path) -> FileLock:
    """Take <data>/engine.lock - THE gate for "one engine per data folder" - and return it (held).

    Raises EngineAlreadyRunning (exit code 3) when another live engine owns the folder, even if its web page does
    not answer. Touches nothing else: the database is opened only after this succeeded, so a losing second engine
    never reaches state.db.
    """
    data_dir = Path(data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    lk = platform.lock(data_dir / "engine.lock")
    try:
        lk.acquire()
    except LockBusy as exc:
        info = read_owner(data_dir) or {}
        port = info.get("port") or (read_json(data_dir / "engine.json") or {}).get("port")
        raise EngineAlreadyRunning(info.get("pid"), port, "engine.lock is held") from exc
    # We hold the kernel lock. Extra evidence: does the old owner record name a LIVE engine of ours that somehow
    # does not hold the lock (an older build, a network folder)? Then refuse too. Access denied counts as alive.
    # A dead pid, or a pid now used by another program (creation time differs), is just stale.
    prev = read_owner(data_dir) or {}
    if prev.get("pid") and prev.get("pid") != os.getpid():
        verdict = classify_engine_pid(prev.get("pid"), prev.get("create_time"), data_dir)
        if verdict in ("ours", "unknown"):
            lk.release()
            raise EngineAlreadyRunning(prev.get("pid"), prev.get("port"), f"owner record says {verdict}")
    return lk


def heartbeat_file(data_dir: Path) -> Path:
    return Path(data_dir) / "heartbeat.json"


def write_heartbeat(data_dir: Path, pid: int, instance: str, clean: bool = False) -> None:
    try:
        atomic_write(heartbeat_file(data_dir), json.dumps({"pid": pid, "instance": instance, "at": now_iso(),
                                                           "clean": clean}))
    except OSError:
        pass


def last_session_from_heartbeat(data_dir: Path) -> dict[str, Any] | None:
    """What the previous session's heartbeat says, or None when there was none. {"clean": bool, "at", "pid"}."""
    hb = read_json(heartbeat_file(data_dir))
    if hb is None:
        return None
    return {"clean": bool(hb.get("clean")), "ended_at": hb.get("at"), "pid": hb.get("pid")}


# =====================================================================================================================
# G3: pid file in the server folder
# =====================================================================================================================
def pid_file(install_root: Path) -> Path:
    return Path(install_root) / "hbdeck.pid"


def write_pid_file(install_root: Path, record: dict[str, Any], platform: Platform | None = None) -> None:
    """Atomic: a reader sees the old record or the new one, never half of one."""
    atomic_write(pid_file(install_root), json.dumps(record, indent=1), platform)


def read_pid_file(install_root: Path) -> dict[str, Any] | None:
    return read_json(pid_file(install_root))


def remove_pid_file_if(install_root: Path, run_id: str | None) -> bool:
    """Delete the pid file only when it belongs to `run_id` (another run's record is never removed)."""
    rec = read_pid_file(install_root)
    if rec is None or (run_id is not None and rec.get("run_id") != run_id):
        return False
    try:
        pid_file(install_root).unlink()
        return True
    except OSError:
        return False


# =====================================================================================================================
# G3: exact-token command-line scan
# =====================================================================================================================
@dataclass
class ProcInfo:
    pid: int
    create_time: float | None
    name: str
    cmdline: list[str] | None          # None = the OS would not let us read it
    reasons: list[str] = field(default_factory=list)

    def as_dict(self) -> dict[str, Any]:
        return {"pid": self.pid, "create_time": self.create_time, "name": self.name, "reasons": list(self.reasons)}


@dataclass
class ScanResult:
    matches: list[ProcInfo] = field(default_factory=list)       # exact identity/port token matches
    unverifiable: list[ProcInfo] = field(default_factory=list)  # game-named processes we could not inspect
    error: str | None = None                                    # the scan itself failed

    @property
    def clear(self) -> bool:
        return not self.matches and not self.unverifiable and self.error is None


DENIED = object()      # marker psutil puts in .info when the OS refused to tell us a value


def iter_processes(process_iter: Callable[..., Iterable[Any]] | None = None) -> Iterator[ProcInfo]:
    """Every process with name, creation time and command line (cmdline None when access is denied).

    process_iter: tests pass a fake; each item has .pid and either an .info dict (like psutil's) or name() /
    create_time() / cmdline() methods that may raise psutil.AccessDenied.
    """
    if process_iter is None:
        it: Iterable[Any] = psutil.process_iter(["name", "create_time", "cmdline"], ad_value=DENIED)
    else:
        it = process_iter()
    for p in it:
        try:
            pid = int(p.pid)
            info = getattr(p, "info", None)
            if isinstance(info, dict):
                name, ct, cmd = info.get("name"), info.get("create_time"), info.get("cmdline")
                name = "" if name is DENIED or name is None else str(name)
                ct = None if ct is DENIED else ct
                cmd = None if cmd is DENIED else list(cmd or [])
            else:
                try:
                    name = p.name()
                except psutil.AccessDenied:
                    name = ""
                try:
                    ct = p.create_time()
                except psutil.AccessDenied:
                    ct = None
                try:
                    cmd = list(p.cmdline())
                except psutil.AccessDenied:
                    cmd = None
        except (psutil.NoSuchProcess, psutil.ZombieProcess):
            continue
        yield ProcInfo(pid, ct, name, cmd)


def _same(a: str, b: str) -> bool:
    # server identity = a folder name; Windows folder names ignore case
    return a.casefold() == b.casefold() if sys.platform == "win32" else a == b


def token_matches(cmdline: list[str], identity: str | None, ports: Iterable[int]) -> list[str]:
    """Reasons this command line belongs to our world: EXACT `+server.identity <id>` / `+server.port <n>` pairs.

    "+server.identityX", "x+server.identity", or the pair inside one quoted argument do NOT match.
    """
    want_ports = {str(int(p)) for p in ports if p}
    out: list[str] = []
    for i in range(len(cmdline) - 1):
        a, v = cmdline[i], cmdline[i + 1]
        if identity and a == IDENTITY_TOKEN and _same(v, identity):
            out.append(f"identity {v}")
        elif a in PORT_TOKENS and v in want_ports:
            out.append(f"{a[1:]} {v}")
    return out


# Tests only: several test runs may share one PC, and each run's fake servers must not look like survivors to the
# other run. tests/conftest.py sets this to "only processes whose command line mentions this run's temp folder".
# The product never sets it (None = every process on the machine is scanned).
SCAN_FILTER: Callable[[ProcInfo], bool] | None = None


def scan_server_processes(identity: str | None, ports: Iterable[int], exe_names: Iterable[str],
                          *, exclude_pids: Iterable[int] = (), process_iter: Callable[..., Iterable[Any]] | None = None
                          ) -> ScanResult:
    """Find any process (ours, an orphan, another Deck's) already using this identity or these ports.

    exe_names: the game's program names (RustDedicated.exe / RustDedicated). A process with one of those names whose
    command line we cannot read is reported as UNVERIFIABLE: it may be our world, so the caller refuses to start.
    Other unreadable processes (system services) are ignored - they cannot be a game server.
    """
    res = ScanResult()
    names = {n.lower() for n in exe_names}
    names |= {Path(n).stem.lower() for n in names}
    skip = {os.getpid(), *[int(x) for x in exclude_pids if x]}
    ports = list(ports)
    try:
        for p in iter_processes(process_iter):
            if p.pid in skip:
                continue
            if SCAN_FILTER is not None and p.cmdline and not SCAN_FILTER(p):
                continue
            is_game_named = p.name.lower() in names
            if p.cmdline is None or (is_game_named and not p.cmdline):
                if is_game_named:
                    p.reasons.append("command line not readable")
                    res.unverifiable.append(p)
                continue
            reasons = token_matches(p.cmdline, identity, ports)
            if reasons:
                p.reasons = reasons
                res.matches.append(p)
    except Exception as exc:  # noqa: BLE001 - a scan that fails cannot prove "nothing is running"
        res.error = f"{type(exc).__name__}: {exc}"
    return res


# =====================================================================================================================
# G3: machine-wide reservations (one lock file per identity and per port)
# =====================================================================================================================
def machine_reservations_dir() -> Path:
    """Where identity/port reservation locks live. Machine-wide on purpose: two Decks with DIFFERENT data folders
    must still not start the same world or the same port at the same time. HB_RESERVATIONS_DIR overrides it."""
    env = os.environ.get("HB_RESERVATIONS_DIR")
    if env:
        return Path(env)
    if sys.platform == "win32":
        base = os.environ.get("ProgramData") or r"C:\ProgramData"
        return Path(base) / "HoneyBadger" / "Bunker" / "reservations"
    return Path(tempfile.gettempdir()) / "honeybadger-bunker-reservations"


SAFE_KEY = re.compile(r"[^a-z0-9._-]+")


def reservation_keys(identity: str, ports: Iterable[tuple[str, int]]) -> list[str]:
    """Sorted lock names: everyone takes them in the same order, so two starts can never deadlock."""
    keys = {"identity-" + SAFE_KEY.sub("_", identity.casefold())}
    keys |= {f"port-{proto}-{int(port)}" for proto, port in ports}
    return sorted(keys)


class ReservationBusy(RuntimeError):
    def __init__(self, key: str, holder: dict[str, Any] | None) -> None:
        self.key, self.holder = key, holder or {}
        super().__init__(f"{key} is reserved by another HoneyBadger Bunker (pid {self.holder.get('pid', 'unknown')})")


class Reservations:
    """The set of reservation locks one supervisor holds while its server may be running."""

    def __init__(self, platform: Platform, directory: Path) -> None:
        self.platform = platform
        self.directory = Path(directory)
        self.held: dict[str, FileLock] = {}

    def acquire(self, keys: list[str], owner: dict[str, Any]) -> None:
        """Take every key (sorted order). On any failure release what this call took and raise ReservationBusy."""
        if os.name != "nt":
            try:
                self.directory.mkdir(parents=True, exist_ok=True)
                os.chmod(self.directory, 0o1777)   # several users may share it; sticky bit protects their files
            except OSError:
                pass
        else:
            self.directory.mkdir(parents=True, exist_ok=True)
        taken: list[str] = []
        try:
            for key in sorted(keys):
                if key in self.held:
                    continue
                lk = self.platform.lock(self.directory / f"{key}.lock")
                try:
                    lk.acquire()
                except (LockBusy, PermissionError) as exc:
                    raise ReservationBusy(key, read_json(self.directory / f"{key}.owner.json")) from exc
                self.held[key] = lk
                taken.append(key)
                try:
                    atomic_write(self.directory / f"{key}.owner.json", json.dumps({**owner, "at": now_iso()}))
                except OSError:
                    pass
        except BaseException:
            for key in taken:
                self._release(key)
            raise

    def _release(self, key: str) -> None:
        lk = self.held.pop(key, None)
        if lk is not None:
            lk.release()

    def release_all(self) -> None:
        for key in list(self.held):
            self._release(key)

    @property
    def keys(self) -> list[str]:
        return sorted(self.held)


# =====================================================================================================================
# G4: the kill-all barrier
# =====================================================================================================================
def barrier_path(data_dir: Path) -> Path:
    return Path(data_dir) / "killall.lock"


def barrier_active(platform: Platform, data_dir: Path) -> bool:
    """True while `hbdeck kill-all` holds <data>/killall.lock: no server may be started in this folder then."""
    path = barrier_path(data_dir)
    if not path.exists():
        return False
    lk = platform.lock(path)
    try:
        lk.acquire()
    except LockBusy:
        return True
    lk.release()
    return False


def new_run_id() -> str:
    """A per-run identifier that cannot collide (the old one had one-second resolution)."""
    return uuid.uuid4().hex


def classify_pid(pid: Any, create_time: Any) -> str:
    """"alive" / "dead" / "unknown" for a stored (pid, creation time) pair."""
    return process_liveness(int(pid) if pid else None, create_time)
