"""The desktop window: a pywebview (Edge WebView2) window that shows the engine's web UI.

The window is only a viewer. Closing it does NOT stop the engine or any server; the engine keeps running in the
background and the next `hbdeck shell` simply re-attaches to it.
"""
from __future__ import annotations

from . import APP_NAME


def open_window(url: str, width: int = 1280, height: int = 820) -> None:
    import webview  # pywebview (BSD licence); imported here so the engine never needs it

    webview.create_window(APP_NAME, url, width=width, height=height, min_size=(980, 640),
                          background_color="#FAF6EE", text_select=True)
    webview.start()          # blocks until the window is closed; the engine process is untouched
