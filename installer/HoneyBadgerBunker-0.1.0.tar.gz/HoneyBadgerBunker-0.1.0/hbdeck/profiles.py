"""Profiles and state: the SQLite database (state.db) plus rendering of the game's config files.

state.db is the ONE source of truth for what the user wants (profiles, schedules, plugins...). It is opened by
exactly one engine at a time (the engine holds a lock file next to it) and every write goes through this module.

Config files: Rust reads server/<identity>/cfg/server.cfg at boot. Users (and other tools) may hand-edit that file,
so we never just overwrite it: we replace only the lines for settings the Deck manages, keep every other line and
comment exactly as it was, and write the result atomically (temp file + rename, so a crash cannot leave half a file).
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import tempfile
import threading
from pathlib import Path
from typing import Any, Iterable

from .models import Admin, Operation, Profile, Schedule, iso, utcnow

SCHEMA_VERSION = 1
MANAGED_HEADER = "// --- managed by HoneyBadger Bunker (edit these in the Deck) ---"

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS profiles (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, game TEXT NOT NULL, identity TEXT NOT NULL,
    install_root TEXT NOT NULL UNIQUE, data TEXT NOT NULL, created TEXT NOT NULL, updated TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS secrets (ref TEXT PRIMARY KEY, blob BLOB NOT NULL);
CREATE TABLE IF NOT EXISTS schedules (
    id TEXT PRIMARY KEY, profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS occurrences (
    schedule_id TEXT NOT NULL, occurrence_utc TEXT NOT NULL, state TEXT NOT NULL, updated TEXT NOT NULL,
    detail TEXT, PRIMARY KEY (schedule_id, occurrence_utc));
CREATE TABLE IF NOT EXISTS operations (
    id TEXT PRIMARY KEY, profile_id TEXT, kind TEXT NOT NULL, state TEXT NOT NULL, data TEXT NOT NULL,
    started TEXT);
CREATE INDEX IF NOT EXISTS operations_profile ON operations(profile_id, started);
CREATE TABLE IF NOT EXISTS receipts (
    profile_id TEXT NOT NULL, kind TEXT NOT NULL, data TEXT NOT NULL, PRIMARY KEY (profile_id, kind));
CREATE TABLE IF NOT EXISTS plugins (
    id TEXT PRIMARY KEY, profile_id TEXT NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS runtime (profile_id TEXT PRIMARY KEY, data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS kv (key TEXT PRIMARY KEY, value TEXT NOT NULL);
"""


class Store:
    """Thread-safe access to state.db (one connection, one lock: a single writer by construction)."""

    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._db = sqlite3.connect(str(self.path), check_same_thread=False, isolation_level=None)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.execute("PRAGMA journal_mode=WAL")
            self._db.execute("PRAGMA foreign_keys=ON")
            self._db.executescript(SCHEMA)
            self._db.execute("INSERT OR IGNORE INTO meta(key, value) VALUES ('schema_version', ?)", (str(SCHEMA_VERSION),))

    def close(self) -> None:
        with self._lock:
            self._db.close()

    def _exec(self, sql: str, args: Iterable[Any] = ()) -> sqlite3.Cursor:
        with self._lock:
            return self._db.execute(sql, tuple(args))

    def _all(self, sql: str, args: Iterable[Any] = ()) -> list[sqlite3.Row]:
        with self._lock:
            return self._db.execute(sql, tuple(args)).fetchall()

    # ----- profiles ----------------------------------------------------------------------------------------
    def list_profiles(self) -> list[Profile]:
        return [Profile.model_validate_json(r["data"]) for r in self._all("SELECT data FROM profiles ORDER BY created")]

    def get_profile(self, profile_id: str) -> Profile | None:
        rows = self._all("SELECT data FROM profiles WHERE id=?", (profile_id,))
        return Profile.model_validate_json(rows[0]["data"]) if rows else None

    def save_profile(self, profile: Profile) -> Profile:
        now = iso(utcnow())
        if not profile.created:
            profile.created = now
        profile.updated = now
        canon = canonical_path(profile.install_root)
        with self._lock:
            clash = self._db.execute("SELECT id, install_root FROM profiles WHERE id != ?", (profile.id,)).fetchall()
            for r in clash:
                if canonical_path(r["install_root"]) == canon:
                    raise ValueError("another profile already manages that install folder")
            self._db.execute(
                "INSERT INTO profiles(id, name, game, identity, install_root, data, created, updated) "
                "VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name, game=excluded.game, "
                "identity=excluded.identity, install_root=excluded.install_root, data=excluded.data, "
                "updated=excluded.updated",
                (profile.id, profile.name, profile.game, profile.identity, profile.install_root,
                 profile.model_dump_json(), profile.created, profile.updated))
        return profile

    def delete_profile(self, profile_id: str) -> None:
        with self._lock:
            self._db.execute("DELETE FROM profiles WHERE id=?", (profile_id,))
            self._db.execute("DELETE FROM runtime WHERE profile_id=?", (profile_id,))
            self._db.execute("DELETE FROM receipts WHERE profile_id=?", (profile_id,))
            self._db.execute("DELETE FROM secrets WHERE ref LIKE ?", (f"{profile_id}:%",))

    # ----- secrets (stored protected by the platform: DPAPI on Windows) -------------------------------------
    def set_secret(self, ref: str, blob: bytes) -> None:
        self._exec("INSERT INTO secrets(ref, blob) VALUES (?, ?) ON CONFLICT(ref) DO UPDATE SET blob=excluded.blob",
                   (ref, blob))

    def get_secret(self, ref: str) -> bytes | None:
        rows = self._all("SELECT blob FROM secrets WHERE ref=?", (ref,))
        return bytes(rows[0]["blob"]) if rows else None

    # ----- schedules + durable occurrence ledger -------------------------------------------------------------
    def list_schedules(self, profile_id: str | None = None) -> list[Schedule]:
        if profile_id:
            rows = self._all("SELECT data FROM schedules WHERE profile_id=?", (profile_id,))
        else:
            rows = self._all("SELECT data FROM schedules")
        return [Schedule.model_validate_json(r["data"]) for r in rows]

    def get_schedule(self, sid: str) -> Schedule | None:
        rows = self._all("SELECT data FROM schedules WHERE id=?", (sid,))
        return Schedule.model_validate_json(rows[0]["data"]) if rows else None

    def save_schedule(self, s: Schedule) -> Schedule:
        self._exec("INSERT INTO schedules(id, profile_id, data) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET "
                   "data=excluded.data", (s.id, s.profile_id, s.model_dump_json()))
        return s

    def delete_schedule(self, sid: str) -> None:
        self._exec("DELETE FROM schedules WHERE id=?", (sid,))

    def claim_occurrence(self, schedule_id: str, occurrence_utc: str, state: str = "fired") -> bool:
        """Record that an occurrence ran. Returns False if it was already recorded (= never fire twice)."""
        cur = self._exec("INSERT OR IGNORE INTO occurrences(schedule_id, occurrence_utc, state, updated) "
                         "VALUES (?,?,?,?)", (schedule_id, occurrence_utc, state, iso(utcnow())))
        return cur.rowcount == 1

    def set_occurrence_state(self, schedule_id: str, occurrence_utc: str, state: str, detail: str | None = None) -> None:
        self._exec("UPDATE occurrences SET state=?, detail=?, updated=? WHERE schedule_id=? AND occurrence_utc=?",
                   (state, detail, iso(utcnow()), schedule_id, occurrence_utc))

    def occurrences(self, schedule_id: str) -> list[dict[str, Any]]:
        return [dict(r) for r in self._all("SELECT * FROM occurrences WHERE schedule_id=? ORDER BY occurrence_utc",
                                           (schedule_id,))]

    # ----- operations --------------------------------------------------------------------------------------
    def save_operation(self, op: Operation) -> None:
        self._exec("INSERT INTO operations(id, profile_id, kind, state, data, started) VALUES (?,?,?,?,?,?) "
                   "ON CONFLICT(id) DO UPDATE SET state=excluded.state, data=excluded.data, started=excluded.started",
                   (op.id, op.profile_id, op.kind, op.state, op.model_dump_json(), op.started))

    def get_operation(self, op_id: str) -> Operation | None:
        rows = self._all("SELECT data FROM operations WHERE id=?", (op_id,))
        return Operation.model_validate_json(rows[0]["data"]) if rows else None

    def list_operations(self, profile_id: str | None = None, limit: int = 50) -> list[Operation]:
        if profile_id:
            rows = self._all("SELECT data FROM operations WHERE profile_id=? ORDER BY rowid DESC LIMIT ?",
                             (profile_id, limit))
        else:
            rows = self._all("SELECT data FROM operations ORDER BY rowid DESC LIMIT ?", (limit,))
        return [Operation.model_validate_json(r["data"]) for r in rows]

    def mark_interrupted_operations(self) -> int:
        """After an engine restart, any operation still 'running' was interrupted: mark it failed honestly."""
        n = 0
        for r in self._all("SELECT data FROM operations WHERE state IN ('running','queued')"):
            op = Operation.model_validate_json(r["data"])
            op.state = "failed"
            op.error = "interrupted: the engine stopped while this was running"
            op.finished = iso(utcnow())
            self.save_operation(op)
            n += 1
        return n

    # ----- receipts (files a framework/plugin install owns) --------------------------------------------------
    def save_receipt(self, profile_id: str, kind: str, data: dict[str, Any]) -> None:
        self._exec("INSERT INTO receipts(profile_id, kind, data) VALUES (?,?,?) ON CONFLICT(profile_id, kind) "
                   "DO UPDATE SET data=excluded.data", (profile_id, kind, json.dumps(data)))

    def get_receipt(self, profile_id: str, kind: str) -> dict[str, Any] | None:
        rows = self._all("SELECT data FROM receipts WHERE profile_id=? AND kind=?", (profile_id, kind))
        return json.loads(rows[0]["data"]) if rows else None

    def delete_receipt(self, profile_id: str, kind: str) -> None:
        self._exec("DELETE FROM receipts WHERE profile_id=? AND kind=?", (profile_id, kind))

    # ----- plugins -----------------------------------------------------------------------------------------
    def list_plugin_records(self, profile_id: str) -> list[dict[str, Any]]:
        return [json.loads(r["data"]) for r in self._all("SELECT data FROM plugins WHERE profile_id=?", (profile_id,))]

    def save_plugin_record(self, profile_id: str, rec: dict[str, Any]) -> None:
        self._exec("INSERT INTO plugins(id, profile_id, data) VALUES (?,?,?) ON CONFLICT(id) DO UPDATE SET "
                   "data=excluded.data", (rec["id"], profile_id, json.dumps(rec)))

    def delete_plugin_record(self, plugin_id: str) -> None:
        self._exec("DELETE FROM plugins WHERE id=?", (plugin_id,))

    # ----- runtime (observed facts that must survive an engine restart: breaker, build id, last pid) --------
    def get_runtime(self, profile_id: str) -> dict[str, Any]:
        rows = self._all("SELECT data FROM runtime WHERE profile_id=?", (profile_id,))
        return json.loads(rows[0]["data"]) if rows else {}

    def update_runtime(self, profile_id: str, **fields: Any) -> dict[str, Any]:
        with self._lock:
            data = self.get_runtime(profile_id)
            data.update(fields)
            self._db.execute("INSERT INTO runtime(profile_id, data) VALUES (?,?) ON CONFLICT(profile_id) DO UPDATE "
                             "SET data=excluded.data", (profile_id, json.dumps(data)))
            return data

    # ----- generic key/value (manifest sequence, engine settings) ------------------------------------------
    def get_kv(self, key: str, default: Any = None) -> Any:
        rows = self._all("SELECT value FROM kv WHERE key=?", (key,))
        return json.loads(rows[0]["value"]) if rows else default

    def set_kv(self, key: str, value: Any) -> None:
        self._exec("INSERT INTO kv(key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                   (key, json.dumps(value)))


def canonical_path(p: str | Path) -> str:
    """Normalise a folder path so C:\\X\\ and c:/x compare equal (Windows is case-insensitive)."""
    real = os.path.realpath(str(p))
    return os.path.normcase(real.rstrip("\\/"))


# =====================================================================================================
# Config file rendering
# =====================================================================================================

CFG_LINE_RE = re.compile(r"^\s*(?P<key>[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)+)\s*(?P<value>.*?)\s*$")


def parse_cfg_line(line: str) -> tuple[str, str] | None:
    """'server.hostname "My Server"' -> ('server.hostname', 'My Server'). Comments/blank lines -> None."""
    s = line.strip()
    if not s or s.startswith("//") or s.startswith("#"):
        return None
    m = CFG_LINE_RE.match(s)
    if not m:
        return None
    value = m.group("value")
    if len(value) >= 2 and value[0] == value[-1] == '"':
        value = value[1:-1]
    return m.group("key").lower(), value


def cfg_quote(value: str) -> str:
    if value != "" and re.fullmatch(r"[A-Za-z0-9_.:/\-]+", value):
        return value
    return f'"{value}"'


def render_server_cfg(existing: str, values: dict[str, str | None]) -> str:
    """Merge managed values into an existing server.cfg, preserving every unmanaged line and comment.

    - A managed key already in the file: its FIRST line is rewritten in place; later duplicates are removed
      (a duplicate further down would silently win, because Rust runs the file top to bottom).
    - A managed key with value None: all its lines are removed.
    - Managed keys not yet in the file are appended under one header comment.
    """
    want = {k.lower(): v for k, v in values.items()}
    seen: set[str] = set()
    out: list[str] = []
    header_present = False
    for raw in existing.splitlines():
        parsed = parse_cfg_line(raw)
        if parsed is None or parsed[0] not in want:
            if raw.strip() == MANAGED_HEADER:
                if header_present:
                    continue                     # never two headers
                header_present = True
            out.append(raw)
            continue
        key = parsed[0]
        if key in seen or want[key] is None:
            continue
        seen.add(key)
        out.append(f"{key} {cfg_quote(want[key] or '')}")
    missing = [k for k, v in want.items() if v is not None and k not in seen]
    if missing:
        while out and not out[-1].strip():
            out.pop()
        if not header_present:
            if out:
                out.append("")
            out.append(MANAGED_HEADER)
        for k in missing:
            out.append(f"{k} {cfg_quote(want[k] or '')}")
    return "\n".join(out) + "\n"


def strip_cfg_keys(text: str, keys: Iterable[str]) -> str:
    """Remove every line whose FIRST word is one of `keys` (case-insensitive). Comments and other lines stay.

    Used when the user removes an option: its line must go, even a junk line that is not a valid setting
    (for example `values "{...}"`), which the normal render would keep as "added by hand"."""
    drop = {k.lower() for k in keys}
    out = [raw for raw in text.splitlines()
           if not (raw.strip() and not raw.strip().startswith(("//", "#")) and raw.split()[0].lower() in drop)]
    return "\n".join(out) + ("\n" if out else "")


def split_cfg(text: str, managed_keys: Iterable[str]) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    """For the raw view: which lines the Deck manages and which belong to the user."""
    keys = {k.lower() for k in managed_keys}
    managed: list[dict[str, str]] = []
    unmanaged: list[dict[str, str]] = []
    for raw in text.splitlines():
        parsed = parse_cfg_line(raw)
        if parsed is None:
            continue
        (managed if parsed[0] in keys else unmanaged).append({"name": parsed[0], "value": parsed[1]})
    return managed, unmanaged


USERS_RE = re.compile(r'^\s*(?P<role>ownerid|moderatorid)\s+(?P<id>\d+)(?:\s+"(?P<name>[^"]*)")?(?:\s+"(?P<reason>[^"]*)")?')


def parse_users_cfg(text: str) -> list[Admin]:
    admins: list[Admin] = []
    for raw in text.splitlines():
        m = USERS_RE.match(raw)
        if not m:
            continue
        try:
            admins.append(Admin(steamid64=m.group("id"), role="owner" if m.group("role") == "ownerid" else "moderator",
                                name=(m.group("name") or "").replace("\n", " ")))
        except ValueError:
            continue
    return admins


def render_users_cfg(existing: str, admins: list[Admin]) -> str:
    """users.cfg: the Deck's admin list replaces all ownerid/moderatorid lines; anything else is kept."""
    out = [raw for raw in existing.splitlines() if not USERS_RE.match(raw)]
    while out and not out[-1].strip():
        out.pop()
    for a in admins:
        role = "ownerid" if a.role == "owner" else "moderatorid"
        out.append(f'{role} {a.steamid64} "{a.name}" "added by HoneyBadger Bunker"')
    return "\n".join(out) + ("\n" if out else "")


def atomic_write(path: Path, text: str, platform: Any | None = None) -> None:
    """Write a text file so it is either fully old or fully new, never half written."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        if platform is not None:
            platform.restrict_permissions(Path(tmp))
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
