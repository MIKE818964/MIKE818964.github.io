"""In-process event bus: the engine publishes, every connected UI WebSocket receives.

Each subscriber gets its own bounded queue. A slow or frozen browser tab can never block the engine: if its queue
is full, the oldest events for that subscriber are dropped (the next status frame brings it up to date anyway).
Console lines only go to subscribers that asked for that profile ({"type": "subscribe", "profile_id": ...}).
"""
from __future__ import annotations

import asyncio
from typing import Any


class Subscriber:
    def __init__(self, maxsize: int = 2000) -> None:
        self.queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=maxsize)
        self.profiles: set[str] = set()
        self.dropped = 0

    def offer(self, event: dict[str, Any]) -> None:
        try:
            self.queue.put_nowait(event)
        except asyncio.QueueFull:
            try:
                self.queue.get_nowait()          # drop the oldest
                self.dropped += 1
                self.queue.put_nowait(event)
            except (asyncio.QueueEmpty, asyncio.QueueFull):
                pass


class EventBus:
    def __init__(self) -> None:
        self._subs: set[Subscriber] = set()

    def subscribe(self) -> Subscriber:
        s = Subscriber()
        self._subs.add(s)
        return s

    def unsubscribe(self, s: Subscriber) -> None:
        self._subs.discard(s)

    @property
    def count(self) -> int:
        return len(self._subs)

    def publish(self, event: dict[str, Any]) -> None:
        if event.get("type") == "console":
            pid = event.get("profile_id")
            for s in list(self._subs):
                if pid in s.profiles:
                    s.offer(event)
            return
        for s in list(self._subs):
            s.offer(event)
