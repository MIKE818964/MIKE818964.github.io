"""Background operations ("jobs") with named steps, one at a time per profile.

Every change to a server (install, start, stop, wipe, backup...) runs as an Operation:
- it gets an id at once, so the API can answer 202 immediately and the UI can follow it;
- it runs inside that profile's queue (an asyncio lock), so two changes to the same server never overlap -
  whether they came from the UI, the scheduler or the updater;
- each step is saved to state.db BEFORE it starts, so after a crash we can say exactly where it stopped.
"""
from __future__ import annotations

import asyncio
import contextlib
import logging
import time
from typing import TYPE_CHECKING, Any, AsyncIterator, Awaitable, Callable, TypeVar

from .models import Operation, OperationBrief, Step, iso, utcnow

if TYPE_CHECKING:
    from .engine import Engine

log = logging.getLogger(__name__)


class OpError(Exception):
    """An expected failure with a plain-English message for the user (no stack trace needed)."""

    def __init__(self, message: str, code: str = "operation_failed", detail: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.detail = detail or {}


class OpContext:
    """Handed to each operation function: report steps/progress and write lines to the profile console."""

    def __init__(self, runner: "OperationRunner", op: Operation) -> None:
        self.runner = runner
        self.op = op
        self._last_save = 0.0

    @contextlib.asynccontextmanager
    async def step(self, name: str) -> AsyncIterator[Step]:
        st = Step(name=name, state="running", started=iso(utcnow()))
        self.op.steps.append(st)
        self.runner.changed(self.op, persist=True)
        self.log(f"{self.op.kind}: {name}")
        try:
            yield st
        except asyncio.CancelledError:
            st.state = "cancelled"
            st.finished = iso(utcnow())
            self.runner.changed(self.op, persist=True)
            raise
        except Exception as exc:
            st.state = "failed"
            st.detail = st.detail or str(exc)
            st.finished = iso(utcnow())
            self.runner.changed(self.op, persist=True)
            raise
        else:
            if st.state == "running":
                st.state = "done"
            st.finished = iso(utcnow())
            self.runner.changed(self.op, persist=True)

    def skip(self, name: str, why: str) -> None:
        self.op.steps.append(Step(name=name, state="skipped", detail=why, started=iso(utcnow()), finished=iso(utcnow())))
        self.runner.changed(self.op, persist=True)

    def detail(self, text: str, percent: float | None = None) -> None:
        if self.op.steps:
            self.op.steps[-1].detail = text
        if percent is not None:
            self.op.percent = round(max(0.0, min(100.0, percent)), 2)
        now = time.monotonic()
        persist = now - self._last_save > 2.0
        if persist:
            self._last_save = now
        self.runner.changed(self.op, persist=persist)

    def log(self, text: str, level: str | None = None) -> None:
        if self.op.profile_id:
            self.runner.engine.console(self.op.profile_id).append("system", text, level)


OpFunc = Callable[[OpContext], Awaitable[None]]
NOT_CANCELLABLE = frozenset({"kill_all"})
T = TypeVar("T")


async def uncancellable(aw: Awaitable[T]) -> T:
    """Finish `aw` even if our caller is cancelled; honour the cancel only after it has completed.

    Used for steps that must never stop halfway (file replacement, extraction + its receipt). A cancel request is
    remembered, we keep waiting, and CancelledError is raised once the work is done. If the work itself failed,
    that error is raised instead - it is the truth about the files.
    """
    work = asyncio.ensure_future(aw)
    cancel_requested = False
    while True:
        try:
            # shield(): cancelling us does NOT cancel `work`; it only interrupts this await.
            result = await asyncio.shield(work)
            break
        except asyncio.CancelledError:
            if work.cancelled():
                # The WORK itself was cancelled (event-loop shutdown cancels every task, not just us). Nothing is
                # left to wait for; without this check shield() would raise again forever (Codex round 2, P1).
                raise
            if work.done() and not work.cancelled():
                # the work had already finished when the cancel arrived: keep its result (or raise its error)
                exc = work.exception()
                if exc is not None:
                    raise exc from None
                result = work.result()
                cancel_requested = True
                break
            cancel_requested = True       # remember it, keep waiting for the work to finish
    if cancel_requested:
        raise asyncio.CancelledError()
    return result


async def run_blocking(func: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """Run blocking FILE work (restore, wipe, backup zip, archive extraction) in a worker thread, uncancellably.

    Why not plain `await asyncio.to_thread(...)`? Cancelling that await only stops the WAITING - the worker thread
    cannot be stopped and keeps replacing or deleting files. The operation would then finish as "cancelled",
    release the profile lock, and the next operation (a start, another restore...) would run on half-written files.
    Through uncancellable() the profile lock stays held until the worker has returned.
    """
    return await uncancellable(asyncio.to_thread(func, *args, **kwargs))


class OperationRunner:
    def __init__(self, engine: "Engine") -> None:
        self.engine = engine
        self._locks: dict[str, asyncio.Lock] = {}
        self._tasks: dict[str, asyncio.Task[None]] = {}
        self._current: dict[str, Operation] = {}
        self._ops: dict[str, Operation] = {}
        self.closed = False          # set when the engine starts shutting down: nothing new is accepted

    def lock_for(self, profile_id: str | None) -> asyncio.Lock:
        key = profile_id or "_engine"
        if key not in self._locks:
            self._locks[key] = asyncio.Lock()
        return self._locks[key]

    def changed(self, op: Operation, persist: bool = True) -> None:
        if persist:
            self.engine.store.save_operation(op)
        self.engine.events.publish({"type": "operation", "operation": op.model_dump(mode="json")})
        if op.profile_id:
            self.engine.publish_status(op.profile_id)

    def current(self, profile_id: str) -> Operation | None:
        return self._current.get(profile_id)

    def brief(self, profile_id: str) -> OperationBrief | None:
        op = self._current.get(profile_id)
        if op is None:
            return None
        step = op.steps[-1] if op.steps else None
        label = None
        if step:
            label = step.name + (f" ({step.detail})" if step.detail else "")
        return OperationBrief(id=op.id, kind=op.kind, step=label, percent=op.percent)

    def get(self, op_id: str) -> Operation | None:
        return self._ops.get(op_id) or self.engine.store.get_operation(op_id)

    def submit(self, profile_id: str | None, kind: str, fn: OpFunc, params: dict[str, Any] | None = None) -> Operation:
        if self.closed:
            raise OpError("HoneyBadger Bunker is shutting down; nothing new can be started now", "engine_stopping")
        op = Operation(profile_id=profile_id, kind=kind, params=params or {})  # type: ignore[arg-type]
        # Cancel is always honoured safely (file steps finish first, see run_blocking), except Stop everything,
        # which ends this engine itself.
        op.cancellable = kind not in NOT_CANCELLABLE
        self._ops[op.id] = op
        self.changed(op)
        self._tasks[op.id] = asyncio.create_task(self._run(op, fn), name=f"op-{kind}-{op.id[:8]}")
        return op

    async def _run(self, op: Operation, fn: OpFunc) -> None:
        ctx = OpContext(self, op)
        lock = self.lock_for(op.profile_id)
        try:
            async with lock:
                op.state = "running"
                op.started = iso(utcnow())
                if op.profile_id:
                    self._current[op.profile_id] = op
                self.changed(op)
                await fn(ctx)
                op.state = "done"
                op.percent = 100.0 if op.percent is not None else None
        except asyncio.CancelledError:
            op.state = "cancelled"
            op.error = "cancelled"
            op.error_code = "cancelled"
        except OpError as exc:
            op.state = "failed"
            op.error = str(exc)
            op.error_code = exc.code
            ctx.log(f"{op.kind} failed: {exc}", "error")
        except Exception as exc:  # noqa: BLE001 - report anything unexpected honestly instead of hanging
            log.exception("operation %s failed", op.kind)
            op.state = "failed"
            op.error = f"{type(exc).__name__}: {exc}"
            op.error_code = "internal_error"
            ctx.log(f"{op.kind} failed: {op.error}", "error")
        finally:
            op.finished = iso(utcnow())
            op.cancellable = False
            op.progress = None if op.state == "done" else op.progress
            if op.profile_id and self._current.get(op.profile_id) is op:
                del self._current[op.profile_id]
            self._tasks.pop(op.id, None)
            # The engine keeps durable outcome facts (e.g. "the last install failed", shown on the Deck until a
            # retry succeeds). Called before the final frame so the status published with it is already right.
            hook = getattr(self.engine, "operation_finished", None)
            if hook is not None:
                try:
                    hook(op)
                except Exception:  # noqa: BLE001 - bookkeeping must never hide the operation's own result
                    log.exception("operation_finished hook failed for %s", op.id)
            self.changed(op)

    def cancel(self, op_id: str) -> bool:
        task = self._tasks.get(op_id)
        if task is None or task.done():
            return False
        task.cancel()
        return True

    async def wait(self, op_id: str, timeout: float | None = None) -> Operation:
        task = self._tasks.get(op_id)
        if task is not None:
            await asyncio.wait_for(asyncio.shield(task), timeout)
        op = self.get(op_id)
        assert op is not None
        return op

    async def drain(self, timeout: float = 30) -> None:
        tasks = [t for t in self._tasks.values() if not t.done()]
        if tasks:
            await asyncio.wait(tasks, timeout=timeout)

    def close(self) -> None:
        """Refuse every new operation from now on (synchronous: the engine calls it before its first await)."""
        self.closed = True

    async def quiesce(self, timeout: float = 30) -> list[str]:
        """Engine shutdown: cancel every queued and running operation and wait (bounded) for them to end.

        Cancelling is safe: steps that must never stop halfway (file replacement, extraction) run through
        run_blocking()/uncancellable() and finish first. A cancelled "restart afterwards" tail never starts a
        server, because the supervisor refuses every spawn once the engine is stopping. Returns the ids of the
        operations still running when the time ran out (normally none).
        """
        self.close()
        tasks = {oid: t for oid, t in self._tasks.items() if not t.done()}
        for t in tasks.values():
            t.cancel()
        if tasks:
            await asyncio.wait(list(tasks.values()), timeout=timeout)
        return [oid for oid, t in tasks.items() if not t.done()]
