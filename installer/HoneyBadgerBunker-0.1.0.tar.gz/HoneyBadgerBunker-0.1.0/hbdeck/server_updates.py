"""Is there a newer Rust build or framework release? (Rust server + Carbon/Oxide discovery, not Bunker's own updates.)

Bunker's own signed update manifest lives in updates.py. This module only answers "what is installed, what is
offered, and can we trust that answer". Plain-English rules (docs/team/basics/BASICS_PLAN_2026-10-28.md, B + E):

Where the numbers come from (data model, checked 2026-10-28):
- Installed Rust build: steamapps/appmanifest_258550.acf, key "buildid" (a real file reads "buildid" "26139947").
- Offered Rust build: https://api.steamcmd.net/v1/info/<app> -> data.<app>.depots.branches.<branch>.buildid and
  .timeupdated (Unix seconds as a string). steamcmd.net is a THIRD-PARTY service (free, no key), not Valve; the
  UI must say so, which is why every answer carries `source`. Captured live 2026-10-28: public 26139947,
  staging 26261951 (tests/fixtures/steamcmd_net_258550.json).
- Fallback: `steamcmd +app_info_print <app>` (same depots.branches block, Valve KeyValues text) run through an
  injected runner that holds the SteamCMD-root lock (steamcmd.app_info_print_text) and never during an operation.
- Valve's UpToDateCheck is NOT used: it does not report a build id for this app.
- Framework releases: the GitHub REST API (60 requests/hour per IP without a token; we read X-RateLimit-Remaining
  and X-RateLimit-Reset and stop asking until the reset). Carbon's download tag `production_build` is MOVED to each
  new release, so a tag name alone cannot tell two releases apart: we record release id, asset id, asset
  updated_at and the asset's sha256 `digest` (GitHub sends it; captured live 2026-10-28).

Honesty rules:
- Unknown is None. A failed check NEVER becomes "up to date": the last good answer is kept and marked stale, and
  a stale "no update" is reported as available=None (we do not know), never False.
- Release timing never proves compatibility. "confirmed" needs evidence that this exact framework revision ran on
  this exact Rust build (runtime evidence from the server itself).
- One cache per engine/app/branch (not per profile): hourly with jitter, no checks while an operation runs,
  concurrent checks share one request, errors back off exponentially, a manual "Check now" obeys the same limit.

UpdateInfo dict (Shared seams, exact names): installed, latest, available, source, checked_at, stale, error,
installed_revision, latest_revision. framework_update adds compatibility + compatibility_reason.
"""
from __future__ import annotations

import asyncio
import datetime as dt
import json
import os
import random
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Callable

from .steamcmd import manifest_branch, parse_app_info_branches, read_appmanifest

RUST_APP_ID = 258550
STEAMCMD_NET_URL = "https://api.steamcmd.net/v1/info/{app}"
SOURCE_STEAMCMD_NET = "steamcmd.net"
SOURCE_APP_INFO = "steamcmd app_info_print"
SOURCE_GITHUB = "github"

# The exact release our downloader uses (frameworks.py downloads .../releases/download/production_build/...), so
# Carbon is asked for that tag, not "latest" (which today is the same release but could drift to another one).
GITHUB_RELEASE_URLS = {
    "carbon": "https://api.github.com/repos/CarbonCommunity/Carbon/releases/tags/production_build",
    "oxide": "https://api.github.com/repos/OxideMod/Oxide.Rust/releases/latest",
}
# Which release asset is "ours" on each OS (the same names frameworks.ARCHIVE_NAMES downloads).
FRAMEWORK_ASSETS = {("carbon", "windows"): "Carbon.Windows.Release.zip",
                    ("carbon", "linux"): "Carbon.Linux.Release.tar.gz",
                    ("oxide", "windows"): "Oxide.Rust.zip",
                    ("oxide", "linux"): "Oxide.Rust-linux.zip"}

VERIFY_COPY = "SteamCMD may update official files to the {branch} branch; your world and settings are kept"
VERIFY_NOTE = ("This is not a scan that freezes your current build: changed official files are replaced with "
               "Steam's copies, and the framework is installed again afterwards.")


def utc_iso(epoch: float | None) -> str | None:
    """Unix seconds -> "2026-10-28T01:05:00Z" (or None)."""
    if epoch is None:
        return None
    return dt.datetime.fromtimestamp(epoch, dt.timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


# ------------------------------------------------------------------------------------------------------------
# HTTP (injected in tests; nothing here runs at import time)
# ------------------------------------------------------------------------------------------------------------

@dataclass
class FetchResult:
    status: int
    headers: dict[str, str]          # lower-case names
    body: bytes


Fetch = Callable[[str, dict[str, str]], Awaitable[FetchResult]]


class UpdateCheckError(RuntimeError):
    """The check did not produce an answer (network, HTTP status, unexpected reply shape, missing branch)."""


class RateLimited(UpdateCheckError):
    """The upstream says "not now". `retry_at` = Unix seconds when asking again is allowed (None = unknown)."""

    def __init__(self, message: str, retry_at: float | None) -> None:
        super().__init__(message)
        self.retry_at = retry_at


async def http_get(url: str, headers: dict[str, str]) -> FetchResult:
    """Production fetcher: one GET with a 15 s timeout, run in a worker thread. HTTP errors are RETURNED (their
    status and headers matter for rate limits); only network failures raise."""
    def _get() -> FetchResult:
        req = urllib.request.Request(url, headers={"User-Agent": "HoneyBadgerBunker", **headers})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:     # noqa: S310 - fixed https URLs only
                return FetchResult(resp.status, {k.lower(): v for k, v in resp.headers.items()},
                                   resp.read(4 << 20))
        except urllib.error.HTTPError as exc:
            return FetchResult(exc.code, {k.lower(): v for k, v in (exc.headers or {}).items()},
                               exc.read(1 << 20) if exc.fp else b"")
        except (urllib.error.URLError, OSError) as exc:
            raise UpdateCheckError(f"network error: {getattr(exc, 'reason', exc)}") from exc
    return await asyncio.to_thread(_get)


# ------------------------------------------------------------------------------------------------------------
# Rust: installed and offered builds
# ------------------------------------------------------------------------------------------------------------

def installed_build(install_root: Path | str, branch: str = "public", app_id: int = RUST_APP_ID) -> dict[str, Any]:
    """What Steam says is installed: {buildid, branch, error}. buildid None = not installed / unreadable.

    If the install is on a different branch than the profile asks for, buildid is still reported but `error`
    says so: comparing it with the other branch's latest build would be meaningless.
    """
    state = read_appmanifest(Path(install_root), app_id)
    if state is None:
        return {"buildid": None, "branch": None, "error": "no readable appmanifest (not installed yet?)"}
    bid = state.get("buildid")
    bid = str(bid) if isinstance(bid, str) and bid.isdigit() and bid != "0" else None
    on_branch = manifest_branch(state)
    err = None if bid else "the appmanifest has no build id"
    if bid and on_branch != branch:
        err = f"installed from the '{on_branch}' branch, but this server is set to '{branch}'"
    return {"buildid": bid, "branch": on_branch, "error": err}


def parse_steamcmd_net(body: bytes, app_id: int, branch: str) -> dict[str, Any]:
    """Pick one branch out of a steamcmd.net /v1/info reply. Raises UpdateCheckError for anything unexpected."""
    try:
        data = json.loads(body)
    except (TypeError, ValueError) as exc:
        raise UpdateCheckError("steamcmd.net sent something that is not JSON") from exc
    if not isinstance(data, dict) or data.get("status") != "success":
        raise UpdateCheckError(f"steamcmd.net did not report success (status={data.get('status')!r})"
                               if isinstance(data, dict) else "steamcmd.net reply is not a JSON object")
    try:
        branches = data["data"][str(app_id)]["depots"]["branches"]
    except (KeyError, TypeError) as exc:
        raise UpdateCheckError("steamcmd.net reply has no depots.branches for this app") from exc
    return _pick_branch(branches, branch, SOURCE_STEAMCMD_NET)


def _pick_branch(branches: Any, branch: str, source: str) -> dict[str, Any]:
    if not isinstance(branches, dict):
        raise UpdateCheckError(f"{source}: branches is not a table")
    b = branches.get(branch)
    if not isinstance(b, dict):
        raise UpdateCheckError(f"{source}: branch '{branch}' not found (offered: {', '.join(sorted(branches))})")
    bid = b.get("buildid")
    if not (isinstance(bid, (str, int)) and str(bid).isdigit() and str(bid) != "0"):
        raise UpdateCheckError(f"{source}: branch '{branch}' has no build id")
    ts = b.get("timeupdated")
    return {"buildid": str(bid), "timeupdated": int(ts) if str(ts or "").isdigit() else None, "source": source}


async def latest_build(app_id: int = RUST_APP_ID, branch: str = "public", fetch: Fetch = http_get) -> dict[str, Any]:
    """Newest build Steam offers on `branch`, from steamcmd.net. {buildid, timeupdated, source}. Raises on failure."""
    res = await fetch(STEAMCMD_NET_URL.format(app=app_id), {"Accept": "application/json"})
    if res.status == 429:
        retry = res.headers.get("retry-after")
        raise RateLimited("steamcmd.net asked us to slow down (HTTP 429)",
                          time.time() + float(retry) if retry and retry.isdigit() else None)
    if res.status != 200:
        raise UpdateCheckError(f"steamcmd.net answered HTTP {res.status}")
    return parse_steamcmd_net(res.body, app_id, branch)


async def latest_build_via_steamcmd(app_id: int, branch: str, run: Callable[[int], Awaitable[str]]) -> dict[str, Any]:
    """Fallback: parse `app_info_print` text. `run(app_id)` must hold the SteamCMD-root lock and must never be called
    while an operation runs (production: steamcmd.app_info_print_text). Raises UpdateCheckError on failure."""
    try:
        text = await run(app_id)
    except UpdateCheckError:
        raise
    except Exception as exc:  # noqa: BLE001 - busy lock, timeout, exit code: all mean "no answer this time"
        raise UpdateCheckError(f"steamcmd app_info_print failed: {exc}") from exc
    try:
        branches = parse_app_info_branches(text, app_id)
    except ValueError as exc:
        raise UpdateCheckError(f"steamcmd app_info_print: {exc}") from exc
    return _pick_branch(branches, branch, SOURCE_APP_INFO)


# ------------------------------------------------------------------------------------------------------------
# Frameworks: GitHub releases
# ------------------------------------------------------------------------------------------------------------

class GitHubRateLimit:
    """ONE shared budget for every GitHub request this engine makes (60/hour without a token, per IP).

    After each reply we remember X-RateLimit-Remaining and X-RateLimit-Reset. When the budget is spent we refuse
    locally (RateLimited) until the reset time, without sending anything.
    """

    def __init__(self, clock: Callable[[], float] = time.time, reserve: int = 0) -> None:
        self.clock = clock
        self.reserve = reserve
        self.remaining: int | None = None
        self.reset_at: float | None = None

    def before_request(self) -> None:
        if self.remaining is not None and self.remaining <= self.reserve and self.reset_at is not None \
                and self.clock() < self.reset_at:
            raise RateLimited("GitHub request budget used up; waiting for the reset", self.reset_at)

    def after_response(self, res: FetchResult) -> None:
        rem, reset = res.headers.get("x-ratelimit-remaining"), res.headers.get("x-ratelimit-reset")
        if rem is not None and rem.strip().isdigit():
            self.remaining = int(rem)
        if reset is not None and reset.strip().isdigit():
            self.reset_at = float(reset)
        if res.status in (403, 429) and (self.remaining == 0 or res.headers.get("retry-after")):
            retry = res.headers.get("retry-after")
            retry_at = self.clock() + float(retry) if retry and retry.strip().isdigit() else self.reset_at
            raise RateLimited(f"GitHub rate limit reached (HTTP {res.status})", retry_at)


SHARED_GITHUB_LIMIT = GitHubRateLimit()

VERSION_RE = re.compile(r"v?(\d+(?:\.\d+){1,3})")


def parse_github_release(body: bytes, framework: str, asset_name: str) -> dict[str, Any]:
    """Identity of one release + our asset. Raises UpdateCheckError when the asset is missing or the shape is odd."""
    try:
        rel = json.loads(body)
    except (TypeError, ValueError) as exc:
        raise UpdateCheckError("GitHub sent something that is not JSON") from exc
    if not isinstance(rel, dict) or not isinstance(rel.get("id"), int) or not isinstance(rel.get("assets"), list):
        raise UpdateCheckError("GitHub reply is not a release")
    asset = next((a for a in rel["assets"] if isinstance(a, dict) and a.get("name") == asset_name), None)
    if asset is None or not isinstance(asset.get("id"), int):
        raise UpdateCheckError(f"release {rel.get('tag_name')} has no asset named {asset_name}")
    # Carbon names its release "Production Build — v2.0.262" under the moving tag; Oxide tags "2.0.7839".
    version = None
    for text in (rel.get("name"), rel.get("tag_name")):
        m = VERSION_RE.search(str(text or ""))
        if m:
            version = m.group(1)
            break
    digest = asset.get("digest") if isinstance(asset.get("digest"), str) else None
    info = {"framework": framework, "release_id": rel["id"], "tag": rel.get("tag_name"), "name": rel.get("name"),
            "version": version, "published_at": rel.get("published_at"), "asset_id": asset["id"],
            "asset_name": asset_name, "asset_updated_at": asset.get("updated_at"), "digest": digest,
            "size": asset.get("size"), "source": SOURCE_GITHUB}
    info["revision"] = release_revision(info)
    return info


def release_revision(rel: dict[str, Any] | None) -> str | None:
    """A string that changes whenever the downloadable file changes: the sha256 digest when GitHub gives one,
    otherwise the asset id + its updated_at. None when neither is known."""
    if not rel:
        return None
    if rel.get("digest"):
        return str(rel["digest"])
    if rel.get("asset_id") is not None:
        return f"asset {rel['asset_id']} updated {rel.get('asset_updated_at') or 'unknown'}"
    return None


async def framework_latest(framework: str, os_name: str, fetch: Fetch = http_get,
                           limit: GitHubRateLimit = SHARED_GITHUB_LIMIT) -> dict[str, Any]:
    """Newest release identity for carbon or oxide on this OS. Raises UpdateCheckError / RateLimited."""
    if framework not in GITHUB_RELEASE_URLS:
        raise UpdateCheckError(f"no release source for framework '{framework}'")
    limit.before_request()
    res = await fetch(GITHUB_RELEASE_URLS[framework], {"Accept": "application/vnd.github+json",
                                                       "X-GitHub-Api-Version": "2022-11-28"})
    limit.after_response(res)
    if res.status != 200:
        raise UpdateCheckError(f"GitHub answered HTTP {res.status}")
    return parse_github_release(res.body, framework, FRAMEWORK_ASSETS[(framework, os_name)])


def installed_framework_revision(receipt: dict[str, Any] | None) -> str | None:
    """What we installed, from the frameworks receipt (state.db). Prefers the release identity recorded at install
    time; else the sha256 of the archive we unpacked (comparable with GitHub's digest)."""
    if not receipt:
        return None
    rel = receipt.get("release")
    if isinstance(rel, dict):
        rev = release_revision(rel)
        if rev:
            return rev
    if receipt.get("archive_sha256"):
        return f"sha256:{receipt['archive_sha256']}"
    return None


def framework_available(receipt: dict[str, Any] | None, latest: dict[str, Any] | None) -> bool | None:
    """Did the downloadable framework file change since we installed it? None when we cannot tell."""
    if not receipt or not latest:
        return None
    if latest.get("digest") and receipt.get("archive_sha256"):
        return latest["digest"].lower() != f"sha256:{receipt['archive_sha256']}".lower()
    rel = receipt.get("release")
    if isinstance(rel, dict) and rel.get("asset_id") is not None and latest.get("asset_id") is not None:
        if rel.get("digest") and latest.get("digest"):
            return rel["digest"] != latest["digest"]
        return (rel.get("asset_id"), rel.get("asset_updated_at")) != (latest["asset_id"], latest.get("asset_updated_at"))
    return None


# ------------------------------------------------------------------------------------------------------------
# The cache: hourly, jittered, deferred during operations, coalesced, persisted, backed off
# ------------------------------------------------------------------------------------------------------------

@dataclass
class _Entry:
    value: dict[str, Any] | None = None       # last SUCCESSFUL answer
    checked_at: float | None = None           # when that success happened (Unix seconds)
    attempted_at: float | None = None         # last try, good or bad
    error: str | None = None                  # last try's error (None after a success)
    failures: int = 0                         # errors in a row (drives the backoff)
    next_allowed: float = 0.0                 # no upstream request before this time
    deferred: bool = False                    # a check was skipped because an operation was running

    def to_json(self) -> dict[str, Any]:
        return {"value": self.value, "checked_at": self.checked_at, "attempted_at": self.attempted_at,
                "error": self.error, "failures": self.failures, "next_allowed": self.next_allowed}


@dataclass
class UpdateCache:
    """One cache for every update source of one engine, saved to `path` (a JSON file under the data folder).

    Keys look like "rust:258550:public" or "framework:carbon:windows". `check()` is the only way to ask upstream.
    """
    path: Path | None
    interval_s: float = 3600.0
    jitter_s: float = 300.0
    backoff_s: tuple[float, ...] = (60.0, 300.0, 900.0, 3600.0, 6 * 3600.0)
    clock: Callable[[], float] = time.time
    rng: Callable[[float, float], float] = random.uniform
    _entries: dict[str, _Entry] = field(default_factory=dict)
    _inflight: dict[str, asyncio.Future[Any]] = field(default_factory=dict)
    requests: int = 0                         # upstream requests actually made (tests read this)

    def __post_init__(self) -> None:
        self._load()

    # ----- persistence ------------------------------------------------------------------------------------
    def _load(self) -> None:
        if self.path is None:
            return
        try:
            raw = json.loads(Path(self.path).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        if not isinstance(raw, dict):
            return
        for key, e in raw.items():
            if isinstance(e, dict):
                self._entries[key] = _Entry(value=e.get("value") if isinstance(e.get("value"), dict) else None,
                                            checked_at=e.get("checked_at"), attempted_at=e.get("attempted_at"),
                                            error=e.get("error"), failures=int(e.get("failures") or 0),
                                            next_allowed=float(e.get("next_allowed") or 0.0))

    def _save(self) -> None:
        if self.path is None:
            return
        p = Path(self.path)
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            tmp = p.with_suffix(p.suffix + ".tmp")
            tmp.write_text(json.dumps({k: e.to_json() for k, e in self._entries.items()}, indent=1),
                           encoding="utf-8")
            os.replace(tmp, p)
        except OSError:
            pass                              # the cache is an optimisation; failing to save must not fail a check

    # ----- reading -----------------------------------------------------------------------------------------
    def snapshot(self, key: str, *, from_cache: bool = True) -> dict[str, Any]:
        """What we know for `key` right now, without asking anyone."""
        e = self._entries.get(key) or _Entry()
        now = self.clock()
        stale = e.value is not None and (e.error is not None or
                                         (e.checked_at is not None and now - e.checked_at > 2 * self.interval_s))
        return {"value": e.value, "checked_at": utc_iso(e.checked_at), "attempted_at": utc_iso(e.attempted_at),
                "error": e.error, "stale": stale, "deferred": e.deferred, "from_cache": from_cache,
                "next_check_at": utc_iso(e.next_allowed) if e.next_allowed else None}

    # ----- asking upstream ----------------------------------------------------------------------------------
    async def check(self, key: str, fetch: Callable[[], Awaitable[dict[str, Any]]], *, busy: bool = False,
                    manual: bool = False) -> dict[str, Any]:
        """Return the answer for `key`, asking upstream only when allowed.

        busy=True (an operation is running): never ask; mark the key deferred and return what we have.
        manual=True ("Check now"): same upstream limit as the timer - a click cannot hammer the source.
        Two callers at once share one request.
        """
        e = self._entries.setdefault(key, _Entry())
        if busy:
            e.deferred = True
            return self.snapshot(key)
        if self.clock() < e.next_allowed:
            return self.snapshot(key)         # within the hour (or backing off): the cached answer stands
        running = self._inflight.get(key)
        if running is not None:
            await asyncio.shield(running)
            return self.snapshot(key, from_cache=False)
        fut: asyncio.Future[Any] = asyncio.get_running_loop().create_future()
        self._inflight[key] = fut
        try:
            await self._ask(key, e, fetch)
        finally:
            self._inflight.pop(key, None)
            fut.set_result(None)
        return self.snapshot(key, from_cache=False)

    async def _ask(self, key: str, e: _Entry, fetch: Callable[[], Awaitable[dict[str, Any]]]) -> None:
        now = self.clock()
        e.attempted_at = now
        e.deferred = False
        self.requests += 1
        try:
            value = await fetch()
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - every failure keeps the last good value and backs off
            e.error = str(exc) or exc.__class__.__name__
            e.failures += 1
            wait = self.backoff_s[min(e.failures - 1, len(self.backoff_s) - 1)]
            e.next_allowed = now + wait
            retry_at = getattr(exc, "retry_at", None)
            if isinstance(retry_at, (int, float)) and retry_at > e.next_allowed:
                e.next_allowed = float(retry_at)
        else:
            e.value, e.checked_at, e.error, e.failures = value, now, None, 0
            e.next_allowed = now + self.interval_s + self.rng(0.0, self.jitter_s)
        self._save()


# ------------------------------------------------------------------------------------------------------------
# Turning cache answers into the status fields (Shared seams)
# ------------------------------------------------------------------------------------------------------------

def rust_update_info(installed: dict[str, Any], snap: dict[str, Any]) -> dict[str, Any]:
    """UpdateInfo for the Rust server. `installed` = installed_build(), `snap` = UpdateCache snapshot."""
    latest_v = snap.get("value") or {}
    inst, latest = installed.get("buildid"), latest_v.get("buildid")
    available: bool | None = None
    if inst and latest and not installed.get("error"):
        available = latest != inst            # Steam treats any different build id on the branch as the update
        if snap.get("stale") and available is False:
            available = None                  # an old "no update" after a failed check is NOT "up to date"
    error = snap.get("error") or installed.get("error")
    return {"installed": inst, "latest": latest, "available": available,
            "source": latest_v.get("source"), "checked_at": snap.get("checked_at"), "stale": bool(snap.get("stale")),
            "error": error, "installed_revision": None, "latest_revision": None}


def framework_update_info(receipt: dict[str, Any] | None, snap: dict[str, Any]) -> dict[str, Any]:
    """UpdateInfo for Carbon/Oxide (compatibility is added by compatibility())."""
    latest = snap.get("value")
    available = framework_available(receipt, latest)
    if snap.get("stale") and available is False:
        available = None
    return {"installed": (receipt or {}).get("version"), "latest": (latest or {}).get("version"),
            "available": available, "source": (latest or {}).get("source"), "checked_at": snap.get("checked_at"),
            "stale": bool(snap.get("stale")), "error": snap.get("error"),
            "installed_revision": installed_framework_revision(receipt),
            "latest_revision": release_revision(latest)}


def compatibility(rust_update: dict[str, Any] | None, framework_update: dict[str, Any] | None,
                  evidence: dict[str, Any] | None = None) -> dict[str, Any]:
    """confirmed | incompatible | unknown, with the reason in plain English.

    `evidence` is what the running server itself proved: {"rust_build", "framework_revision", "loaded": bool,
    "seen_at"} (e.g. Carbon answered `c.version` after a boot on that build). Only evidence for the EXACT pair
    that would run after the update counts. Release dates and "came out an hour later" never do.
    """
    if not framework_update or not rust_update:
        return {"compatibility": "unknown", "compatibility_reason": "no framework information"}
    rust_after = rust_update.get("latest") if rust_update.get("available") else rust_update.get("installed")
    fw_after = (framework_update.get("latest_revision") if framework_update.get("available")
                else framework_update.get("installed_revision"))
    if rust_after is None or fw_after is None:
        return {"compatibility": "unknown",
                "compatibility_reason": "the Rust build or the framework release is unknown, so nothing is proven"}
    if evidence and evidence.get("rust_build") == rust_after and evidence.get("framework_revision") == fw_after:
        if evidence.get("loaded") is True:
            return {"compatibility": "confirmed",
                    "compatibility_reason": f"this framework release loaded on Rust build {rust_after}"
                                            + (f" (seen {evidence['seen_at']})" if evidence.get("seen_at") else "")}
        if evidence.get("loaded") is False:
            return {"compatibility": "incompatible",
                    "compatibility_reason": f"this framework release failed to load on Rust build {rust_after}"}
    if rust_update.get("available") and framework_update.get("available"):
        reason = ("Rust update available. A new framework release was detected; compatibility with this Rust "
                  "build is unverified.")
    elif rust_update.get("available"):
        reason = ("Rust update available. No newer framework release was detected; plugins may stop working "
                  "until the framework catches up.")
    elif framework_update.get("available"):
        reason = "A new framework release was detected; it has not run on this Rust build yet."
    else:
        reason = "not yet seen running on this Rust build"
    return {"compatibility": "unknown", "compatibility_reason": reason}


def update_plan(rust_update: dict[str, Any] | None, framework_update: dict[str, Any] | None,
                framework_installed: bool) -> dict[str, Any]:
    """Which update button applies.

    update_all             - Rust update (and, on a modded server, the framework again) - nothing to warn about.
    rust_only_with_caution - Rust update on a modded server whose framework compatibility is not confirmed:
                             the user must acknowledge before we go ahead (requires_ack).
    framework_only         - only the framework release moved.
    none                   - nothing known to update (or we do not know).
    """
    rust_av = (rust_update or {}).get("available")
    fw_av = (framework_update or {}).get("available") if framework_installed else None
    if rust_av is True:
        if not framework_installed:
            return {"plan": "update_all", "requires_ack": False, "reason": "Rust update available."}
        compat = (framework_update or {}).get("compatibility", "unknown")
        if compat == "confirmed":
            return {"plan": "update_all", "requires_ack": False,
                    "reason": "Rust update available; the framework is confirmed for that build."}
        return {"plan": "rust_only_with_caution", "requires_ack": True,
                "reason": ((framework_update or {}).get("compatibility_reason")
                           or "framework compatibility with the new Rust build is unverified")}
    if fw_av is True:
        return {"plan": "framework_only", "requires_ack": False, "reason": "Only the framework release changed."}
    if rust_av is None:
        return {"plan": "none", "requires_ack": False, "reason": "Update status is unknown right now."}
    return {"plan": "none", "requires_ack": False, "reason": "No update detected."}


def verify_steps(framework: str, branch: str = "public") -> dict[str, Any]:
    """The stopped-only Verify operation, as data the integrator turns into steps (engine._install_steps already
    does validate -> framework re-apply -> write config; Verify must refuse while the server runs or is busy)."""
    steps = [{"name": "Check the server is stopped", "kind": "preflight", "requires": "stopped_and_idle"},
             {"name": "Check game files with SteamCMD (validate)", "kind": "steamcmd_validate", "validate": True,
              "branch": branch}]
    if framework in ("carbon", "oxide"):
        steps.append({"name": f"Install {framework.capitalize()} again", "kind": "framework_reapply",
                      "framework": framework})
    steps.append({"name": "Write server config", "kind": "write_config"})
    return {"kind": "verify", "stopped_only": True, "restart_after": False, "steps": steps,
            "copy": VERIFY_COPY.format(branch=branch), "note": VERIFY_NOTE}


# ------------------------------------------------------------------------------------------------------------
# Framework health (expected / detected / receipt / runtime evidence)
# ------------------------------------------------------------------------------------------------------------

CARBON_VERSION_RE = re.compile(r"^Carbon (?P<version>\d+(?:\.\d+)+)")


def parse_runtime_marker(text: str) -> dict[str, Any] | None:
    """Runtime evidence from a console reply. Carbon's `c.version` reply (captured live 2026-10-27):
    "Carbon 2.0.262.0/windows/2026.10.01.0 [production] [production_build] on Rust 134/2635.289.1 (...)".
    Returns {"framework", "version"} or None when the text is not recognised."""
    m = CARBON_VERSION_RE.match((text or "").strip())
    if m:
        return {"framework": "carbon", "version": m.group("version")}
    return None


def framework_health(expected: str, receipt: dict[str, Any] | None, detected_files: dict[str, bool] | None,
                     runtime_marker: dict[str, Any] | None = None, detected: str | None = None) -> dict[str, Any]:
    """{expected, detected, state: ok|missing|mismatch|unknown, runtime_verified, reason}.

    detected_files = frameworks.probe_files(): which loader files are on disk (None = could not look).
    Files on disk only mean "should load"; runtime_verified needs the server itself to report the framework.
    """
    if detected_files is None:
        return {"expected": expected, "detected": None, "state": "unknown", "runtime_verified": False,
                "reason": "the server folder could not be checked"}
    if detected is None:
        detected = detected_from_files(detected_files)
    runtime_ok = bool(runtime_marker and runtime_marker.get("framework") == expected and expected != "vanilla")
    if expected == "vanilla":
        if detected:
            return {"expected": expected, "detected": detected, "state": "mismatch", "runtime_verified": False,
                    "reason": f"set to vanilla, but {detected} files are present, so {detected} will load"}
        return {"expected": expected, "detected": None, "state": "ok", "runtime_verified": False,
                "reason": "no mod framework expected or found"}
    if detected and detected != expected:
        return {"expected": expected, "detected": detected, "state": "mismatch", "runtime_verified": False,
                "reason": f"set to {expected}, but {detected} is installed"}
    missing = [name for name, present in detected_files.items() if name.startswith(expected + ":") and not present]
    if missing or not detected:
        names = ", ".join(n.split(":", 1)[1] for n in missing) or "loader files"
        return {"expected": expected, "detected": detected, "state": "missing", "runtime_verified": False,
                "reason": f"{expected} files are missing: {names}. Reinstall the framework."}
    if receipt is None:
        reason = f"{expected} files are present (not installed by the Bunker)"
    else:
        reason = f"{expected} files are present"
    if runtime_ok:
        reason += f"; the server reported {expected} {runtime_marker.get('version') or ''}".rstrip()
    else:
        reason += "; not yet seen loading (start the server to confirm)"
    return {"expected": expected, "detected": detected, "state": "ok", "runtime_verified": runtime_ok,
            "reason": reason}


def detected_from_files(files: dict[str, bool]) -> str | None:
    """Which framework the probe saw (the key DLL of each loader)."""
    if files.get("carbon:carbon/managed/Carbon.Preloader.dll"):
        return "carbon"
    if files.get("oxide:RustDedicated_Data/Managed/Oxide.Rust.dll"):
        return "oxide"
    return None


# ------------------------------------------------------------------------------------------------------------
# The service the engine holds (engine.server_updates)
# ------------------------------------------------------------------------------------------------------------

class ServerUpdateService:
    """Owns the shared cache + GitHub budget for one engine. Profiles are plain objects with install_root, branch,
    framework (and game; Rust's app id 258550 is the default).

    status(...) reads only the cache (safe for every status frame); check(...) may ask upstream (POST
    /updates/check and the hourly timer). `steamcmd_runner(app_id) -> text` is the app_info_print fallback.
    """

    def __init__(self, data_dir: Path | str | None, *, fetch: Fetch = http_get,
                 steamcmd_runner: Callable[[int], Awaitable[str]] | None = None,
                 cache: UpdateCache | None = None, github_limit: GitHubRateLimit | None = None) -> None:
        path = Path(data_dir) / "cache" / "server_updates.json" if data_dir is not None else None
        self.cache = cache or UpdateCache(path)
        self.fetch = fetch
        self.steamcmd_runner = steamcmd_runner
        self.github_limit = github_limit or SHARED_GITHUB_LIMIT

    @staticmethod
    def rust_key(app_id: int, branch: str) -> str:
        return f"rust:{app_id}:{branch}"

    @staticmethod
    def framework_key(framework: str, os_name: str) -> str:
        return f"framework:{framework}:{os_name}"

    async def _rust_fetch(self, app_id: int, branch: str, busy: bool) -> dict[str, Any]:
        try:
            return await latest_build(app_id, branch, self.fetch)
        except UpdateCheckError as first:
            if self.steamcmd_runner is None or busy:
                raise
            try:
                return await latest_build_via_steamcmd(app_id, branch, self.steamcmd_runner)
            except UpdateCheckError as second:
                raise UpdateCheckError(f"{first}; fallback: {second}") from second

    def _parts(self, profile: Any, receipt: dict[str, Any] | None, os_name: str,
               rust_snap: dict[str, Any], fw_snap: dict[str, Any] | None,
               evidence: dict[str, Any] | None) -> dict[str, Any]:
        branch = getattr(profile, "branch", "public") or "public"
        app_id = _app_id(profile)
        rust = rust_update_info(installed_build(profile.install_root, branch, app_id), rust_snap)
        fw_name = getattr(profile, "framework", "vanilla")
        fw_installed = fw_name in ("carbon", "oxide")
        if fw_installed and fw_snap is not None:
            fw = framework_update_info(receipt, fw_snap)
        else:
            fw = {"installed": None, "latest": None, "available": None, "source": None, "checked_at": None,
                  "stale": False, "error": None if not fw_installed else "not checked yet",
                  "installed_revision": None, "latest_revision": None}
        fw.update(compatibility(rust, fw, evidence) if fw_installed else
                  {"compatibility": "unknown", "compatibility_reason": "no mod framework on this server"})
        return {"rust_update": rust, "framework_update": fw,
                "update_plan": update_plan(rust, fw, fw_installed)}

    def status(self, profile: Any, *, receipt: dict[str, Any] | None, os_name: str,
               evidence: dict[str, Any] | None = None) -> dict[str, Any]:
        branch = getattr(profile, "branch", "public") or "public"
        fw_name = getattr(profile, "framework", "vanilla")
        rust_snap = self.cache.snapshot(self.rust_key(_app_id(profile), branch))
        fw_snap = self.cache.snapshot(self.framework_key(fw_name, os_name)) if fw_name in ("carbon", "oxide") \
            else None
        return self._parts(profile, receipt, os_name, rust_snap, fw_snap, evidence)

    async def check(self, profile: Any, *, receipt: dict[str, Any] | None, os_name: str, busy: bool,
                    manual: bool = False, evidence: dict[str, Any] | None = None) -> dict[str, Any]:
        branch = getattr(profile, "branch", "public") or "public"
        app_id = _app_id(profile)
        fw_name = getattr(profile, "framework", "vanilla")
        rust_snap = await self.cache.check(self.rust_key(app_id, branch),
                                           lambda: self._rust_fetch(app_id, branch, busy), busy=busy, manual=manual)
        fw_snap = None
        if fw_name in ("carbon", "oxide"):
            fw_snap = await self.cache.check(
                self.framework_key(fw_name, os_name),
                lambda: framework_latest(fw_name, os_name, self.fetch, self.github_limit), busy=busy, manual=manual)
        out = self._parts(profile, receipt, os_name, rust_snap, fw_snap, evidence)
        out["deferred"] = bool(rust_snap.get("deferred") or (fw_snap or {}).get("deferred"))
        return out


def _app_id(profile: Any) -> int:
    try:
        from .games import get_game
        return int(get_game(getattr(profile, "game", "rust")).app_id)
    except Exception:  # noqa: BLE001 - plain test objects without a game
        return RUST_APP_ID
