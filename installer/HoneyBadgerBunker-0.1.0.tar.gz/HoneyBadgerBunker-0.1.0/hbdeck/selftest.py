"""`python -m hbdeck selftest`: fast offline checks a support ticket can include (no network, no server needed).

Each check prints PASS or FAIL with one line of detail. Exit code 0 = all passed.
"""
from __future__ import annotations

import datetime as dt
import json
import sys
import tempfile
from pathlib import Path
from typing import Callable


def _checks() -> list[tuple[str, Callable[[], str]]]:
    from . import __version__
    from .games.rust import CATALOG, RustGame
    from .models import Ports, Profile, ScheduleRule
    from .profiles import render_server_cfg
    from .rcon import parse_serverinfo
    from .scheduler import next_occurrence
    from .steamcmd import build_app_update_argv, parse_progress, parse_success

    def argv() -> str:
        p = Profile(identity="selftest", install_root=str(Path(tempfile.gettempdir()) / "hb selftest"),
                    ports=Ports(game_udp=28015, query_udp=28017, rcon_tcp=28016))
        a = RustGame().build_argv(p, "windows", Path("run.log"), "pw")
        assert "-noconsole" in a and a[a.index("+rcon.web") + 1] == "1" and a[a.index("+app.port") + 1] == "1-"
        return f"{len(a)} arguments"

    def steam() -> str:
        a = build_app_update_argv(["steamcmd.exe"], "windows", Path("C:/s"), 258550)
        assert a.index("+force_install_dir") < a.index("+login")
        p = parse_progress(" Update state (0x61) downloading, progress: 99.79 (6099466815 / 6112039231)")
        assert p and p.percent == 99.79
        assert parse_success("Success! App '258550' fully installed.", 258550)
        return "argv order + progress + success"

    def serverinfo() -> str:
        msg = '{\r\n  "Hostname": "HB",\r\n  "Players": 2,\r\n  "MaxPlayers": 8,\r\n  "EntityCount": 1346,\r\n  "Framerate": 240.0}'
        info = parse_serverinfo(msg)
        assert info and info.players == 2 and info.entity_count == 1346 and info.framerate == 240.0
        return "PascalCase keys mapped"

    def cfg() -> str:
        out = render_server_cfg("// keep me\nmy.thing 1\nserver.port 1\n", {"server.port": "28015"})
        assert "// keep me" in out and "my.thing 1" in out and "server.port 28015" in out
        return "unmanaged lines kept"

    def schedule() -> str:
        rule = ScheduleRule(kind="daily", time="02:30")
        after = dt.datetime(2026, 3, 8, 0, 0, tzinfo=dt.timezone.utc)
        nxt = next_occurrence(rule, "America/New_York", after)
        assert nxt == dt.datetime(2026, 3, 8, 7, 0, tzinfo=dt.timezone.utc)   # 02:30 does not exist -> 03:00 EDT
        return "DST gap handled"

    def catalog() -> str:
        assert len(CATALOG) >= 40
        return f"{len(CATALOG)} options"

    def trust() -> str:
        from .updates import load_trusted_keys
        keys = load_trusted_keys()
        assert keys
        return ", ".join(keys)

    def version() -> str:
        return __version__

    return [("version", version), ("launch argv", argv), ("steamcmd parser", steam), ("serverinfo parser", serverinfo),
            ("server.cfg render", cfg), ("schedule DST", schedule), ("option catalog", catalog),
            ("update trust key", trust)]


def run() -> int:
    failed = 0
    results = []
    for name, fn in _checks():
        try:
            detail = fn()
            results.append({"check": name, "ok": True, "detail": detail})
            line = f"PASS  {name}: {detail}"
        except Exception as exc:  # noqa: BLE001
            failed += 1
            results.append({"check": name, "ok": False, "detail": repr(exc)})
            line = f"FAIL  {name}: {exc!r}"
        if sys.stdout is not None:
            print(line)
    if sys.stdout is not None:
        print(json.dumps({"passed": len(results) - failed, "failed": failed}))
    return 1 if failed else 0
