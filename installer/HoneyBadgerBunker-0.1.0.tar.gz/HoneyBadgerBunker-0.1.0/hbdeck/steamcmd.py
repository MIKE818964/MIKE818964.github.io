"""SteamCMD: download Valve's command-line Steam client and use it to install/update the game server.

Verified facts (docs/INSTALL_RECIPE.md sec 1 and the real logs in tests/fixtures/):
- Windows: steamcmd.zip -> steamcmd.exe. Linux: steamcmd_linux.tar.gz -> steamcmd.sh (needs 32-bit libs).
- The FIRST run only updates SteamCMD itself ("[ 56%] Downloading update (41370 of 41370 KB)...", "Update
  complete, launching") - so we run a separate bootstrap step first, then the real install.
- `+force_install_dir` MUST come before `+login anonymous`.
- Progress: " Update state (0x61) downloading, progress: 42.17 (1234 / 5678)". Success line:
  "Success! App '258550' fully installed." Exit code 8 + "Error! App ... state is 0x..." is transient: retry.
- Exit code 0 alone is NOT proof: we also require the success line, the server executable on disk, and a build id
  in steamapps/appmanifest_258550.acf.
- SteamCMD BUFFERS its stdout when it is piped (seen live 2026-10-27: a 50 s, 6 GB install printed all 20 progress
  lines at the very end). So while it runs we ALSO read progress from disk every 2 s - see read_disk_progress().
"""
from __future__ import annotations

import asyncio
import os
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from .archive import download, extract_any
from .console import LineDecoder
from .operations import run_blocking
from .platform import Platform

STEAMCMD_URLS = {
    "windows": "https://steamcdn-a.akamaihd.net/client/installer/steamcmd.zip",
    "linux": "https://steamcdn-a.akamaihd.net/client/installer/steamcmd_linux.tar.gz",
}
STEAMCMD_EXE = {"windows": "steamcmd.exe", "linux": "steamcmd.sh"}

PROGRESS_RE = re.compile(
    r"Update state \((?P<code>0x[0-9a-fA-F]+)\)\s*(?P<state>[^,]*),\s*progress:\s*(?P<pct>[0-9.]+)\s*"
    r"\((?P<done>\d+)\s*/\s*(?P<total>\d+)\)")
BOOTSTRAP_RE = re.compile(r"\[\s*(?P<pct>\d+)%\]\s*Downloading update \((?P<done>[\d,]+) of (?P<total>[\d,]+) KB\)")
SUCCESS_RE = re.compile(r"Success! App '(?P<app>\d+)' (fully installed|already up to date)")
ERROR_RE = re.compile(r"(?:ERROR!|Error!) (?P<msg>.+)")
BUILDID_RE = re.compile(r'"buildid"\s+"(?P<id>\d+)"')
# Byte counters Steam keeps in steamapps/appmanifest_<app>.acf while it works (real file, Rust 258550, 2026-10-27):
#   "BytesToDownload" "1837371616" / "BytesDownloaded"  = compressed bytes over the network (1.8 GB)
#   "BytesToStage"    "6104131185" / "BytesStaged"      = bytes written to disk (6.1 GB - the same total the stdout
#                                                          progress lines report, e.g. "(818696768 / 6104131185)")
ACF_BYTES_RE = re.compile(r'"(?P<key>BytesToDownload|BytesDownloaded|BytesToStage|BytesStaged)"\s+"(?P<val>\d+)"')


@dataclass
class Progress:
    """One parsed progress line."""
    phase: str              # "bootstrap" (SteamCMD updating itself) or the Steam state text ("downloading", ...)
    percent: float
    done: int               # bytes (or KB for bootstrap lines - see unit)
    total: int
    unit: str = "bytes"


def parse_progress(line: str) -> Progress | None:
    m = PROGRESS_RE.search(line)
    if m:
        return Progress(phase=m.group("state").strip() or "working", percent=float(m.group("pct")),
                        done=int(m.group("done")), total=int(m.group("total")))
    m = BOOTSTRAP_RE.search(line)
    if m:
        return Progress(phase="bootstrap", percent=float(m.group("pct")),
                        done=int(m.group("done").replace(",", "")), total=int(m.group("total").replace(",", "")),
                        unit="KB")
    return None


def parse_success(line: str, app_id: int) -> bool:
    m = SUCCESS_RE.search(line)
    return bool(m and int(m.group("app")) == app_id)


def parse_error(line: str) -> str | None:
    m = ERROR_RE.search(line)
    return m.group("msg").strip() if m else None


def read_build_id(install_dir: Path, app_id: int) -> str | None:
    """The installed depot build, from Steam's own receipt file."""
    acf = Path(install_dir) / "steamapps" / f"appmanifest_{app_id}.acf"
    try:
        m = BUILDID_RE.search(acf.read_text(encoding="utf-8", errors="replace"))
    except OSError:
        return None
    return m.group("id") if m else None


def _folder_bytes(folder: Path) -> int:
    """Total size of all files under a folder (0 if it does not exist). Files may vanish while we look: skip them."""
    total = 0
    for dirpath, _dirs, files in os.walk(folder):
        for name in files:
            try:
                total += os.stat(os.path.join(dirpath, name)).st_size
            except OSError:
                pass
    return total


def read_disk_progress(install_dir: Path, app_id: int) -> Progress | None:
    """Progress of a running SteamCMD download, read from disk instead of its (buffered) stdout.

    1. steamapps/appmanifest_<app>.acf: two counter pairs (see ACF_BYTES_RE). We return the pair that is further
       along (both are real Steam counters; which one Steam updates first is not documented) as
       phase "downloading" with percent/done/total in bytes.
    2. Before the manifest has counters: the size of steamapps/downloading/ (Steam's temporary download folder).
       There is no total yet, so total = 0 and percent = 0 (shown as "N MB downloaded").
    Returns None when neither is there yet. The caller decides whether a reading is news (see install_app).
    """
    steamapps = Path(install_dir) / "steamapps"
    try:
        text = (steamapps / f"appmanifest_{app_id}.acf").read_text(encoding="utf-8", errors="replace")
    except OSError:
        text = ""
    vals = {m.group("key"): int(m.group("val")) for m in ACF_BYTES_RE.finditer(text)}
    best: Progress | None = None
    for done_key, total_key in (("BytesStaged", "BytesToStage"), ("BytesDownloaded", "BytesToDownload")):
        total = vals.get(total_key, 0)
        if total <= 0 or done_key not in vals:
            continue
        done = min(vals[done_key], total)
        if best is None or done / total > best.done / best.total:
            best = Progress(phase="downloading", percent=round(done / total * 100, 2), done=done, total=total)
    if best is not None:
        return best
    size = _folder_bytes(steamapps / "downloading")
    if size > 0:
        return Progress(phase="downloading", percent=0.0, done=size, total=0)
    return None


def build_app_update_argv(steamcmd: list[str], os_name: str, install_dir: Path, app_id: int, branch: str = "public",
                          validate: bool = True) -> list[str]:
    """The SteamCMD command line as a list. +force_install_dir comes BEFORE +login (Valve requirement)."""
    argv = list(steamcmd)
    if os_name == "linux":
        argv += ["+@sSteamCmdForcePlatformType", "linux"]
    argv += ["+force_install_dir", str(install_dir), "+login", "anonymous", "+app_update", str(app_id)]
    if branch and branch != "public":
        argv += ["-beta", branch]
    if validate:
        argv.append("validate")
    argv.append("+quit")
    return argv


class SpeedMeter:
    """Turns successive byte counters into a smoothed MB/s figure for the progress bar."""

    def __init__(self) -> None:
        self._last: tuple[float, int] | None = None
        self.mb_per_s: float | None = None

    def update(self, done_bytes: int, now: float | None = None) -> float | None:
        now = time.monotonic() if now is None else now
        if self._last is not None:
            t0, b0 = self._last
            dt_s = now - t0
            if dt_s > 0 and done_bytes >= b0:
                inst = (done_bytes - b0) / dt_s / 1_000_000
                self.mb_per_s = inst if self.mb_per_s is None else 0.7 * self.mb_per_s + 0.3 * inst
        self._last = (now, done_bytes)
        return self.mb_per_s


async def run_streaming(platform: Platform, argv: list[str], on_line: Callable[[str, str], None],
                        cwd: Path | None = None, env: dict[str, str] | None = None,
                        tracker: "ProcessTracker | None" = None) -> int:
    """Run a program hidden and deliver every stdout/stderr line to on_line(stream, text). Returns exit code.

    Both pipes are drained until end-of-file at the same time; otherwise a full pipe could freeze the program.
    If we are cancelled (engine shutdown), the program and its children are killed and reaped - SteamCMD is never
    left running behind a Deck that has gone away. `tracker` records it in the ownership registry while it runs.
    """
    proc = await platform.spawn(argv, cwd=cwd, env=env)
    if tracker is not None:
        tracker.started(proc.pid, argv)
    try:
        return await _drain(proc, on_line)
    except BaseException:
        from .platform import kill_and_reap
        await asyncio.shield(kill_and_reap(proc, platform))
        raise
    finally:
        if tracker is not None:
            tracker.ended(proc.pid)


class ProcessTracker:
    """Hooks the engine passes in so every SteamCMD process lands in (and leaves) the ownership registry."""

    def __init__(self, on_start: Callable[[int, list[str]], None], on_end: Callable[[int], None]) -> None:
        self._on_start, self._on_end = on_start, on_end

    def started(self, pid: int, argv: list[str]) -> None:
        try:
            self._on_start(pid, argv)
        except Exception:  # noqa: BLE001 - bookkeeping must never break an install
            pass

    def ended(self, pid: int) -> None:
        try:
            self._on_end(pid)
        except Exception:  # noqa: BLE001
            pass


async def _drain(proc: asyncio.subprocess.Process, on_line: Callable[[str, str], None]) -> int:

    async def pump(stream: asyncio.StreamReader | None, name: str) -> None:
        if stream is None:
            return
        dec = LineDecoder()
        while True:
            chunk = await stream.read(65536)
            if not chunk:
                break
            for ln in dec.feed(chunk):
                on_line(name, ln)
        for ln in dec.flush():
            on_line(name, ln)

    await asyncio.gather(pump(proc.stdout, "stdout"), pump(proc.stderr, "stderr"))
    return await proc.wait()


class SteamCmdError(RuntimeError):
    pass


@dataclass
class InstallResult:
    build_id: str | None
    attempts: int


class SteamCmd:
    """One SteamCMD folder. `command` can be overridden (tests use a fake Python script)."""

    def __init__(self, root: Path, platform: Platform, command: list[str] | None = None,
                 tracker: ProcessTracker | None = None) -> None:
        self.root = Path(root)
        self.platform = platform
        self._override = command
        self.tracker = tracker

    def _track(self) -> dict:
        """Pass the registry tracker only when there is one (keeps run_streaming's plain signature usable)."""
        return {"tracker": self.tracker} if self.tracker is not None else {}

    @property
    def exe(self) -> Path:
        return self.root / STEAMCMD_EXE[self.platform.os_name]

    def command(self) -> list[str]:
        if self._override:
            return list(self._override)
        if self.platform.os_name == "linux":
            return ["bash", str(self.exe)]       # steamcmd.sh is a bash script; run it without a shell string
        return [str(self.exe)]

    def is_present(self) -> bool:
        return bool(self._override) or self.exe.is_file()

    async def ensure_downloaded(self, log: Callable[[str], None]) -> None:
        """Download and unpack SteamCMD itself if it is not there yet."""
        if self.is_present():
            return
        url = STEAMCMD_URLS[self.platform.os_name]
        archive = self.root / Path(url).name
        log(f"Downloading SteamCMD from {url}")
        await asyncio.to_thread(download, url, archive, max_bytes=200 << 20)
        files = await run_blocking(extract_any, archive, self.root)   # never stops half-unpacked
        log(f"Unpacked SteamCMD ({len(files)} files)")
        try:
            archive.unlink()
        except OSError:
            pass
        if self.platform.os_name == "linux":
            os.chmod(self.exe, 0o755)

    async def bootstrap(self, on_line: Callable[[str, str], None]) -> int:
        """First run: SteamCMD updates itself and exits. Running `+quit` once gets that out of the way."""
        return await run_streaming(self.platform, self.command() + ["+quit"], on_line, cwd=self.root,
                                   **self._track())

    async def install_app(self, install_dir: Path, app_id: int, exe_check: Callable[[], bool], *, branch: str = "public",
                          validate: bool = True, on_line: Callable[[str, str], None],
                          on_progress: Callable[[Progress, float | None], None] | None = None,
                          retries: int = 3, backoff_s: tuple[float, ...] = (5, 15, 30),
                          poll_s: float = 2.0) -> InstallResult:
        """Install or update an app, retrying transient failures. Raises SteamCmdError with the last error.

        Progress comes from two sources, merged so the bar only moves forward:
        - SteamCMD's own progress lines (exact, but often all delivered at the END because the pipe is buffered);
        - a disk poller every `poll_s` seconds (read_disk_progress), which keeps the bar alive meanwhile.
        For the download phase we report whichever source is further along (fraction done of its byte counters)
        and drop readings that would move the bar backwards, e.g. the late burst of old stdout lines.
        """
        install_dir.mkdir(parents=True, exist_ok=True)
        argv = build_app_update_argv(self.command(), self.platform.os_name, install_dir, app_id, branch, validate)
        last_error = "SteamCMD did not report success"
        for attempt in range(1, retries + 1):
            success = False
            errors: list[str] = []
            meters: dict[str, SpeedMeter] = {}   # one speed meter per source/unit, so MB/s never mixes scales
            track = {"best": -1.0, "download_over": False}

            def report(p: Progress, meter_key: str) -> None:
                if on_progress is None:
                    return
                speed = meters.setdefault(meter_key, SpeedMeter()).update(p.done * (1024 if p.unit == "KB" else 1))
                on_progress(p, speed)

            def handle(stream: str, line: str) -> None:
                nonlocal success
                on_line(stream, line)
                p = parse_progress(line)
                if p is not None:
                    if p.phase.startswith("download"):
                        frac = p.done / p.total if p.total else 0.0
                        if frac >= track["best"]:            # never move the bar backwards
                            track["best"] = frac
                            report(p, f"stdout:{p.total}")
                    else:
                        if p.phase.startswith(("verif", "commit")):
                            track["download_over"] = True    # the disk poller has nothing more to add
                        report(p, f"stdout:{p.phase}")
                if parse_success(line, app_id):
                    success = True
                err = parse_error(line)
                if err:
                    errors.append(err)

            async def poll_disk(baseline: Progress | None) -> None:
                last = baseline
                while not track["download_over"]:
                    await asyncio.sleep(poll_s)
                    if track["download_over"]:
                        break
                    p = await asyncio.to_thread(read_disk_progress, install_dir, app_id)
                    # Only NEWS counts: an unchanged reading is either the previous install's finished counters
                    # (an update starts with a "100 %" manifest on disk) or a stall - neither is progress.
                    if p is None or p == last:
                        continue
                    last = p
                    if p.total > 0:
                        frac = p.done / p.total
                        if frac >= 1.0 or frac <= track["best"]:
                            continue                         # finished counters, or behind what we already showed
                        track["best"] = frac
                        report(p, f"disk:{p.total}")
                    elif track["best"] < 0:                  # folder size only until a real total is known
                        report(p, "disk:folder")

            baseline = await asyncio.to_thread(read_disk_progress, install_dir, app_id)
            poller = asyncio.create_task(poll_disk(baseline), name="steamcmd-disk-progress")
            try:
                code = await run_streaming(self.platform, argv, handle, cwd=self.root, **self._track())
            finally:
                poller.cancel()
                await asyncio.gather(poller, return_exceptions=True)   # wait for it to stop; never raise from it
            build = read_build_id(install_dir, app_id)
            if success and exe_check() and build:
                return InstallResult(build_id=build, attempts=attempt)
            parts = [f"exit code {code}"]
            if errors:
                parts.append(errors[-1])
            if not success:
                parts.append("no success line")
            if not exe_check():
                parts.append("server executable missing")
            if not build:
                parts.append("no build id in appmanifest")
            last_error = "; ".join(parts)
            on_line("system", f"SteamCMD attempt {attempt} did not finish ({last_error})")
            if attempt < retries:
                await asyncio.sleep(backoff_s[min(attempt - 1, len(backoff_s) - 1)])
        raise SteamCmdError(last_error)


# ------------------------------------------------------------------------------------------------------------
# Metadata: which build is installed, and which build does Steam offer? (used by server_updates.py)
# ------------------------------------------------------------------------------------------------------------
# Valve "KeyValues" text is the format of appmanifest_<app>.acf and of `app_info_print`: quoted keys, quoted
# values, and { } blocks. Example (real appmanifest, Rust 258550, 2026-10-27):
#     "AppState" { "appid" "258550" ... "buildid" "26139947" ... "UserConfig" { } "MountedConfig" { } }
KV_TOKEN_RE = re.compile(r'"((?:[^"\\]|\\.)*)"|([{}])|(//[^\n]*)|(\S+)')


def parse_keyvalues(text: str) -> dict[str, Any]:
    """Turn KeyValues text into nested dicts of strings. Raises ValueError when the braces do not balance.

    Later duplicate keys overwrite earlier ones (Steam files do not repeat keys inside one block).
    """
    root: dict[str, Any] = {}
    stack: list[dict[str, Any]] = [root]
    pending_key: str | None = None
    for m in KV_TOKEN_RE.finditer(text):
        quoted, brace, comment, bare = m.groups()
        if comment is not None:
            continue
        if brace == "{":
            if pending_key is None:
                raise ValueError("a { block has no name")
            child: dict[str, Any] = {}
            stack[-1][pending_key] = child
            stack.append(child)
            pending_key = None
        elif brace == "}":
            if len(stack) == 1 or pending_key is not None:
                raise ValueError("unbalanced } in KeyValues text")
            stack.pop()
        else:
            token = quoted.replace('\\"', '"').replace("\\\\", "\\") if quoted is not None else bare
            if pending_key is None:
                pending_key = token
            else:
                stack[-1][pending_key] = token
                pending_key = None
    if len(stack) != 1 or pending_key is not None:
        raise ValueError("KeyValues text ended inside a block")
    return root


def read_appmanifest(install_dir: Path, app_id: int) -> dict[str, Any] | None:
    """The "AppState" block of steamapps/appmanifest_<app>.acf, or None if the file is missing or unreadable."""
    acf = Path(install_dir) / "steamapps" / f"appmanifest_{app_id}.acf"
    try:
        data = parse_keyvalues(acf.read_text(encoding="utf-8", errors="replace"))
    except (OSError, ValueError):
        return None
    state = data.get("AppState")
    return state if isinstance(state, dict) else None


def manifest_branch(state: dict[str, Any]) -> str:
    """Which branch an install is on. Steam writes "BetaKey" into UserConfig/MountedConfig for a beta branch;
    the real public install above has both blocks empty, so "no BetaKey" means "public".
    (The BetaKey spelling for a beta install is Steam's documented-by-use convention, not seen live here.)"""
    for block in ("MountedConfig", "UserConfig"):
        cfg = state.get(block)
        if isinstance(cfg, dict) and cfg.get("BetaKey"):
            return str(cfg["BetaKey"])
    return "public"


def build_app_info_argv(steamcmd: list[str], app_id: int) -> list[str]:
    """SteamCMD command line that prints the app's metadata (all branches and their build ids) and quits.
    `+app_info_update 1` refreshes SteamCMD's local metadata cache first, otherwise it can print stale data."""
    return list(steamcmd) + ["+login", "anonymous", "+app_info_update", "1", "+app_info_print", str(app_id), "+quit"]


def parse_app_info_branches(text: str, app_id: int) -> dict[str, dict[str, str]]:
    """Read `depots -> branches` out of `app_info_print <app>` output. Raises ValueError when it is not there.

    SteamCMD prints log lines first ("AppID : 258550, change number : ..."), then the block that starts with a
    line holding only "<app_id>" in quotes. The block has the same shape steamcmd.net serves as JSON:
    depots.branches.<branch>.buildid / timeupdated.
    """
    marker = f'"{app_id}"'
    lines = text.splitlines()
    start = next((i for i, ln in enumerate(lines) if ln.strip() == marker), None)
    if start is None:
        raise ValueError(f"app_info_print output has no block for app {app_id}")
    # Parse from the marker on; stop at the line that closes the block (brace depth back to zero).
    depth = 0
    end = None
    for i in range(start + 1, len(lines)):
        stripped = lines[i].strip()
        depth += stripped.count("{") - stripped.count("}")
        if depth == 0 and "}" in stripped:
            end = i
            break
    if end is None:
        raise ValueError("app_info_print output ended inside the app block")
    data = parse_keyvalues("\n".join(lines[start:end + 1]))
    app = data.get(str(app_id))
    branches = app.get("depots", {}).get("branches") if isinstance(app, dict) else None
    if not isinstance(branches, dict) or not branches:
        raise ValueError("app_info_print output has no depots.branches")
    return {name: dict(b) for name, b in branches.items() if isinstance(b, dict)}


async def app_info_print_text(steam: "SteamCmd", app_id: int, timeout_s: float = 120.0) -> str:
    """Run `steamcmd +app_info_print <app>` and return everything it printed on stdout.

    Safety rules (the caller, server_updates.py, relies on these):
    - It holds the SteamCMD-root lock (<steamcmd>/hbdeck-steamcmd.lock, the same lock install/update take), and
      only TRIES it once: if an install or update holds it, we raise SteamCmdError("busy") instead of waiting.
    - Never call it while an operation runs on the profile (the update cache defers checks during operations).
    - The process is reaped on timeout (run_streaming kills it when cancelled).
    """
    from .platform import LockBusy
    lock = steam.platform.lock(steam.root / "hbdeck-steamcmd.lock")
    try:
        lock.acquire()
    except LockBusy as exc:
        raise SteamCmdError("SteamCMD is busy with an install or update") from exc
    out: list[str] = []
    try:
        argv = build_app_info_argv(steam.command(), app_id)
        code = await asyncio.wait_for(
            run_streaming(steam.platform, argv, lambda stream, line: out.append(line) if stream == "stdout" else None,
                          cwd=steam.root, tracker=steam.tracker),
            timeout_s)
    except asyncio.TimeoutError as exc:
        raise SteamCmdError(f"app_info_print did not finish within {timeout_s:g} s") from exc
    finally:
        lock.release()
    if code != 0:
        raise SteamCmdError(f"app_info_print exited with code {code}")
    return "\n".join(out)
