"""One countdown for Stop, Restart, Update and scheduled actions: in-game warnings, then the action.

Plain-English rules (BASICS_PLAN Decision 4, Codex section D):
- Deadlines use a MONOTONIC clock (time.monotonic), so changing the PC clock or daylight saving cannot shorten or
  stretch a countdown.
- A 5-minute countdown warns at 300, 60 and 10 seconds left; a 1-minute one at 60 and 10; 0 = act now, no warning.
- Every warning names the action: "Server restarting in 5 minutes".
- A warning that could not be delivered (RCON dropped) is REPORTED, never silently counted as sent. The countdown
  keeps running: the user chose to wait, and the stop itself does not need RCON.
- cancel() before the deadline means the final action never runs.
- before_final() is called right before the action; the integrator rechecks the desired state there (did someone
  press Stop meanwhile? is the engine shutting down?). If it says no, the action is skipped.
- If players cannot be warned at all (no RCON), a countdown with warnings is REFUSED up front with RconUnavailable;
  the API answers 422 rcon_unavailable and the UI offers "Stop now" instead. A 0-second countdown never needs RCON.
- No double warnings: the scheduler may already have warned for the same moment. Pass the `warned_until` token it
  got (the smallest "seconds left" already announced) and those warnings are not repeated.

Usage (integrator, inside an operation):
    cd = Countdown(say=lambda text: engine.say(pid, text), can_say=lambda: rcon_ready(pid))
    result = await cd.run(warn_s, "restart", final=do_restart, before_final=still_wanted, warned_until=token)
"""
from __future__ import annotations

import asyncio
import inspect
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable

from .rcon import RconUnavailable

ALLOWED_WARN_S = (0, 60, 300)
STANDARD_MARKS = (300, 60, 10)

# What players read: "<phrase> in <time>".
PHRASES = {
    "stop": "Server stopping",
    "restart": "Server restarting",
    "update": "Server updating",
    "backup": "Server restarting for a backup",
    "wipe_map": "Map wipe",
    "wipe_full": "Full wipe",
    "wipe_blueprints": "Blueprint wipe",
}


def span_text(seconds: int) -> str:
    """300 -> "5 minutes", 60 -> "1 minute", 10 -> "10 seconds", 1 -> "1 second"."""
    if seconds >= 120 and seconds % 60 == 0:
        return f"{seconds // 60} minutes"
    if seconds == 60:
        return "1 minute"
    return "1 second" if seconds == 1 else f"{seconds} seconds"


def countdown_text(action: str, seconds: int) -> str:
    return f"{PHRASES.get(action, 'Server ' + action)} in {span_text(seconds)}"


def warning_marks(total_s: int) -> list[int]:
    """Seconds-left marks for a countdown: the start, then 300/60/10 below it. 300 -> [300, 60, 10]."""
    if total_s <= 0:
        return []
    return [int(total_s)] + [m for m in STANDARD_MARKS if m < total_s]


@dataclass
class WarningRecord:
    seconds_left: int
    text: str
    delivered: bool
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"seconds_left": self.seconds_left, "text": self.text, "delivered": self.delivered,
                "error": self.error}


@dataclass
class CountdownResult:
    state: str                                   # "done" | "cancelled" | "skipped" (before_final said no)
    warnings: list[WarningRecord] = field(default_factory=list)
    warned_until: int | None = None              # smallest seconds-left mark announced (pass to the next countdown)
    final_result: Any = None

    @property
    def failed_warnings(self) -> list[WarningRecord]:
        return [w for w in self.warnings if not w.delivered]

    def to_dict(self) -> dict[str, Any]:
        return {"state": self.state, "warnings": [w.to_dict() for w in self.warnings],
                "warned_until": self.warned_until, "failed_warnings": len(self.failed_warnings)}


class Countdown:
    """say(text) -> bool sends one in-game message (False / exception = not delivered).
    can_say() -> bool says whether RCON is up right now (used to refuse a countdown nobody would hear).
    clock / sleep are injectable so tests run a 5-minute countdown in microseconds."""

    def __init__(self, say: Callable[[str], Awaitable[bool]] | None,
                 clock: Callable[[], float] = time.monotonic,
                 sleep: Callable[[float], Awaitable[Any]] = asyncio.sleep, *,
                 can_say: Callable[[], bool] | None = None, poll_s: float = 0.5,
                 on_warning: Callable[[WarningRecord], None] | None = None) -> None:
        self.say = say
        self.clock = clock
        self.sleep = sleep
        self.can_say = can_say
        self.poll_s = poll_s
        self.on_warning = on_warning
        self._cancelled = False
        self._final_started = False
        self.deadline: float | None = None
        self.warned_until: int | None = None

    # ----- control -----------------------------------------------------------------------------------------
    def cancel(self) -> bool:
        """Stop the countdown. True if that prevented the final action; False if it had already started."""
        if self._final_started:
            return False
        self._cancelled = True
        return True

    @property
    def cancelled(self) -> bool:
        return self._cancelled

    def seconds_left(self) -> float | None:
        return None if self.deadline is None else max(0.0, self.deadline - self.clock())

    def check_can_warn(self, total_s: int) -> None:
        """Raise RconUnavailable when a countdown with warnings could not reach anyone. Call it BEFORE accepting
        the request (the API turns it into 422 rcon_unavailable)."""
        if total_s <= 0:
            return
        if self.say is None or (self.can_say is not None and not self.can_say()):
            raise RconUnavailable("players cannot be warned right now (RCON is not connected); use Stop instead")

    # ----- the countdown -----------------------------------------------------------------------------------
    async def run(self, total_s: int, action: str, final: Callable[[], Awaitable[Any]], *,
                  before_final: Callable[[], Any] | None = None, warned_until: int | None = None) -> CountdownResult:
        total_s = int(total_s)
        if total_s < 0:
            raise ValueError("a countdown cannot be negative")
        self.check_can_warn(total_s)
        self.deadline = self.clock() + total_s
        self.warned_until = warned_until
        result = CountdownResult(state="done", warned_until=warned_until)
        for mark in warning_marks(total_s):
            await self._wait_until(self.deadline - mark)
            if self._cancelled:
                result.state = "cancelled"
                return result
            if warned_until is not None and mark >= warned_until:
                continue                              # the scheduler already announced this one
            rec = await self._warn(action, mark)
            result.warnings.append(rec)
            result.warned_until = self.warned_until = mark
        await self._wait_until(self.deadline)
        if self._cancelled:
            result.state = "cancelled"
            return result
        if before_final is not None:
            ok = before_final()
            if inspect.isawaitable(ok):
                ok = await ok
            if not ok:
                result.state = "skipped"
                return result
            if self._cancelled:                       # cancelled while the recheck ran
                result.state = "cancelled"
                return result
        self._final_started = True
        result.final_result = await final()
        return result

    async def _wait_until(self, target: float) -> None:
        while not self._cancelled:
            left = target - self.clock()
            if left <= 0:
                return
            await self.sleep(min(left, self.poll_s))

    async def _warn(self, action: str, seconds_left: int) -> WarningRecord:
        text = countdown_text(action, seconds_left)
        try:
            ok = await self.say(text) if self.say is not None else False
            rec = WarningRecord(seconds_left, text, bool(ok), None if ok else "RCON did not deliver the message")
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001 - a failed warning is reported, the countdown goes on
            rec = WarningRecord(seconds_left, text, False, str(exc) or exc.__class__.__name__)
        if self.on_warning is not None:
            try:
                self.on_warning(rec)
            except Exception:  # noqa: BLE001 - reporting must never break the countdown
                pass
        return rec


def validate_warn_s(value: Any) -> int:
    """Request field `warn_s`: only 0, 60 or 300 (the dialog's choices). Raises ValueError otherwise."""
    try:
        v = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("warn_s must be 0, 60 or 300") from exc
    if v not in ALLOWED_WARN_S or isinstance(value, bool):
        raise ValueError("warn_s must be 0, 60 or 300")
    return v
