"""Run the engine as a local web server (what `python -m hbdeck serve` does).

Plain English: we create the Engine, wrap it in the FastAPI app, and let uvicorn serve it on 127.0.0.1. When
uvicorn is asked to stop (Ctrl+C, systemd stop, or POST /engine/shutdown) the app's shutdown hook stops every
running game server gracefully first.

Order that matters (process guards, 2026-10-28):
  1. take <data>/engine.lock FIRST. Held by someone else = exit code 3 with the "already running" sentence,
     before the database, the scheduler or any server is touched.
  2. bind the web port (the real socket, kept open and handed to uvicorn). No free port = clean up, exit 1.
  3. Windows: the engine joins its own kill-on-close Job Object, so every child is contained from birth.
  4. serve. engine.json (how the shell/CLI/UI find us) is written and autostart runs only once uvicorn listens.
"""
from __future__ import annotations

import asyncio
import json
import logging
import logging.handlers
import os
import socket
import sys
import urllib.request
from pathlib import Path
from typing import Any, Callable

from .ports import probe_free

DEFAULT_PORT = 27800
INSTANCE_HEADER = "X-HBDeck-Instance"
log = logging.getLogger("hbdeck")


def _out(text: str) -> None:
    if sys.stdout is not None:     # pythonw.exe has no stdout
        print(text, flush=True)


def setup_logging(data_dir: Path) -> None:
    logs = data_dir / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    fh = logging.handlers.RotatingFileHandler(logs / "engine.log", maxBytes=5 << 20, backupCount=3, encoding="utf-8")
    fh.setFormatter(fmt)
    root.addHandler(fh)
    if sys.stdout is not None:          # pythonw.exe has no console at all
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        root.addHandler(sh)


def choose_port(bind: str, wanted: int, tries: int = 50) -> int:
    """The wanted port if free, else the next free one (the real port is written to engine.json)."""
    for port in range(wanted, wanted + tries):
        if probe_free("tcp", port, bind):
            return port
    raise RuntimeError(f"no free TCP port between {wanted} and {wanted + tries - 1}")


def bind_socket(bind: str, wanted: int, tries: int = 50) -> tuple[socket.socket, int]:
    """Bind the real listening socket (not a probe that could race): the wanted port, else the next free one."""
    family = socket.AF_INET6 if ":" in bind else socket.AF_INET
    last: OSError | None = None
    for port in range(wanted, wanted + tries):
        s = socket.socket(family, socket.SOCK_STREAM)
        try:
            if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
                s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)   # Windows: nobody may share it
            s.bind((bind, port))
            s.listen(128)
            s.set_inheritable(False)
            return s, port
        except OSError as exc:
            last = exc
            s.close()
    raise RuntimeError(f"no free TCP port between {wanted} and {wanted + tries - 1} ({last})")


def run_server(data_dir: Path, port: int, bind: str,
               serve_fn: Callable[[Any, Any, socket.socket], None] | None = None) -> int:
    """Run the engine until it is asked to stop. Returns the process exit code.

    0 = clean exit, 3 = another engine already owns this data folder, 1 = startup failed (port, crash...).
    serve_fn replaces "uvicorn serves until stopped" (tests use it to exercise the lock + bind steps in a separate
    interpreter without starting any server).
    """
    from . import guards
    from .engine import Engine

    from .platform import current_platform

    setup_logging(data_dir)
    try:
        # 1. the lock, before anything else - the Engine (and so state.db) is created only once we own the folder
        folder_lock = guards.claim_folder(current_platform(), data_dir)
    except guards.EngineAlreadyRunning as exc:
        _out(str(exc))
        log.error("%s (%s)", exc, exc.reason)
        return guards.EXIT_ALREADY_RUNNING
    try:
        engine = Engine(data_dir)
    except BaseException:
        folder_lock.release()
        raise
    engine.adopt_claim(folder_lock)
    try:
        sock, engine.port = bind_socket(bind, port)      # 2. the real socket
    except (RuntimeError, OSError) as exc:
        _out(f"HoneyBadger Bunker could not open its web port: {exc}")
        log.error("could not bind: %s", exc)
        _release(engine)
        return 1
    engine._write_owner()                                 # now the owner record also names the port
    containment = engine.platform.contain_self()          # 3. children contained from birth
    log.info("child containment: %s", containment)
    engine.bind = bind
    rc = 1
    try:
        if serve_fn is not None:
            serve_fn(engine, None, sock)
            rc = 0
        else:
            import uvicorn

            from .api import create_app
            app = create_app(engine)
            config = uvicorn.Config(app, host=bind, port=engine.port, log_level="info", lifespan="on",
                                    log_config=None, access_log=False, ws="auto")
            server = uvicorn.Server(config)
            engine.request_exit = lambda: setattr(server, "should_exit", True)
            engine.listening = lambda: bool(server.started)
            log.info("HoneyBadger Bunker engine on http://%s:%s (data %s)", bind, engine.port, data_dir)
            asyncio.run(server.serve(sockets=[sock]))
            # A clean run = uvicorn listened and the engine went through its whole shutdown.
            rc = 0 if (server.started and engine.state == "exited") else 1
            if engine.state != "exited":
                log.error("the engine stopped without a complete shutdown (state %s)", engine.state)
    finally:
        try:
            sock.close()
        except OSError:
            pass
        _release(engine)
    return rc


def _close_quietly(engine: Any) -> None:
    for closer in (engine.store.close, engine.registry.close):
        try:
            closer()
        except Exception:  # noqa: BLE001
            pass


def _release(engine: Any) -> None:
    """Belt and braces after a failed or finished run: the engine lock must never outlive this function."""
    lk = getattr(engine, "_engine_lock", None)
    if lk is not None and lk.held:
        lk.release()
        engine._engine_lock = None
    _close_quietly(engine)


# ----- client helpers used by status / stop / shell / kill-all --------------------------------------------------

def read_engine_json(data_dir: Path) -> dict[str, Any] | None:
    try:
        return json.loads((data_dir / "engine.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


class NotOurEngine(RuntimeError):
    """Something answered on the port, but it is not the engine engine.json describes (a port squatter)."""


def engine_request(info: dict[str, Any], method: str, path: str, timeout: float = 5.0) -> Any:
    """Call the engine's API and PROVE it is the engine engine.json names (X-HBDeck-Instance must match)."""
    host = "127.0.0.1"
    req = urllib.request.Request(f"http://{host}:{info['port']}/api/v1{path}", method=method,
                                 headers={"Authorization": f"Bearer {info['token']}", "Content-Type": "application/json"},
                                 data=b"{}" if method == "POST" else None)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        want = info.get("instance")
        got = resp.headers.get(INSTANCE_HEADER)
        if want and got != want:
            raise NotOurEngine(f"port {info['port']} answered as {got!r}, not engine instance {want!r}")
        return json.loads(resp.read() or b"null")


def api_call(info: dict[str, Any], method: str, path: str, timeout: float = 5.0) -> Any:
    return engine_request(info, method, path, timeout)


def engine_alive(data_dir: Path) -> dict[str, Any] | None:
    info = read_engine_json(data_dir)
    if not info:
        return None
    try:
        engine_request(info, "GET", "/engine", timeout=3)
        return info
    except Exception:  # noqa: BLE001
        return None


def spawn_engine_detached(data_dir: Path) -> None:
    """Start `python -m hbdeck serve` in the background with no window, independent of this process."""
    import subprocess
    argv = [sys.executable, "-m", "hbdeck", "serve", "--data", str(data_dir)]
    kwargs: dict[str, Any] = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL,
                              "cwd": str(Path(__file__).resolve().parents[1])}
    if os.name == "nt":
        flags = 0x00000008 | 0x00000200 | 0x08000000      # DETACHED_PROCESS | NEW_PROCESS_GROUP | NO_WINDOW
        try:
            subprocess.Popen(argv, creationflags=flags | 0x01000000, **kwargs)   # + BREAKAWAY_FROM_JOB
            return
        except OSError:
            subprocess.Popen(argv, creationflags=flags, **kwargs)
            return
    subprocess.Popen(argv, start_new_session=True, **kwargs)
