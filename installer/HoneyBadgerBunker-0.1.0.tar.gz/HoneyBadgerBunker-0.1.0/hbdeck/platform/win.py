"""Windows implementation of the platform seam.

Key Windows facts used here:
- CREATE_NO_WINDOW (0x08000000) starts a console program with NO window at all. Its output still flows into our
  pipes, so the Deck console shows every line while the user never sees a black "cmd" box.
- A Job Object is a Windows container for processes. We create one with "kill on job close", so if the engine
  itself is killed or crashes, Windows ends every server it started instead of leaving orphans nobody manages.
  Containment is MANDATORY (process guards, 2026-10-28): a child that cannot be put in the job is killed at once.
  How a child gets into the job:
    1. `hbdeck serve` calls contain_self(): the engine joins its own job, and Windows puts every child the engine
       creates into that job AT CREATION (job membership is inherited by children). No gap at all.
    2. Otherwise (tests, or contain_self failed) the child is created SUSPENDED, put in the job, then resumed, so
       it never runs a single instruction outside the job.
  The job handle is not inheritable, so a child can never keep the job (and itself) alive after the engine dies.
- DPAPI (CryptProtectData) encrypts a secret with the current Windows user's key; only that user can decrypt it.
"""
from __future__ import annotations

import ctypes
import ctypes.wintypes as wt
import logging
import msvcrt
import os
from pathlib import Path
from typing import IO

from .base import Platform

log = logging.getLogger(__name__)

CREATE_NO_WINDOW = 0x08000000
CREATE_NEW_PROCESS_GROUP = 0x00000200
CREATE_SUSPENDED = 0x00000004
JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000
JobObjectExtendedLimitInformation = 9
PROCESS_SET_QUOTA = 0x0100
PROCESS_TERMINATE = 0x0001
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
THREAD_SUSPEND_RESUME = 0x0002
TH32CS_SNAPTHREAD = 0x00000004
HANDLE_FLAG_INHERIT = 0x00000001
INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value


class IO_COUNTERS(ctypes.Structure):
    _fields_ = [(n, ctypes.c_ulonglong) for n in ("ReadOperationCount", "WriteOperationCount", "OtherOperationCount",
                                                    "ReadTransferCount", "WriteTransferCount", "OtherTransferCount")]


class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                ("LimitFlags", wt.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wt.DWORD),
                ("Affinity", ctypes.c_size_t), ("PriorityClass", wt.DWORD), ("SchedulingClass", wt.DWORD)]


class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
    _fields_ = [("BasicLimitInformation", JOBOBJECT_BASIC_LIMIT_INFORMATION), ("IoInfo", IO_COUNTERS),
                ("ProcessMemoryLimit", ctypes.c_size_t), ("JobMemoryLimit", ctypes.c_size_t),
                ("PeakProcessMemoryUsed", ctypes.c_size_t), ("PeakJobMemoryUsed", ctypes.c_size_t)]


class THREADENTRY32(ctypes.Structure):
    _fields_ = [("dwSize", wt.DWORD), ("cntUsage", wt.DWORD), ("th32ThreadID", wt.DWORD),
                ("th32OwnerProcessID", wt.DWORD), ("tpBasePri", wt.LONG), ("tpDeltaPri", wt.LONG), ("dwFlags", wt.DWORD)]


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wt.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]


def _kernel32() -> ctypes.WinDLL:
    """kernel32 with full argument and return types declared (so 64-bit handles are never cut to 32 bits)."""
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateJobObjectW.restype = wt.HANDLE
    k.CreateJobObjectW.argtypes = [ctypes.c_void_p, wt.LPCWSTR]
    k.SetInformationJobObject.restype = wt.BOOL
    k.SetInformationJobObject.argtypes = [wt.HANDLE, ctypes.c_int, ctypes.c_void_p, wt.DWORD]
    k.QueryInformationJobObject.restype = wt.BOOL
    k.QueryInformationJobObject.argtypes = [wt.HANDLE, ctypes.c_int, ctypes.c_void_p, wt.DWORD,
                                            ctypes.POINTER(wt.DWORD)]
    k.AssignProcessToJobObject.restype = wt.BOOL
    k.AssignProcessToJobObject.argtypes = [wt.HANDLE, wt.HANDLE]
    k.IsProcessInJob.restype = wt.BOOL
    k.IsProcessInJob.argtypes = [wt.HANDLE, wt.HANDLE, ctypes.POINTER(wt.BOOL)]
    k.OpenProcess.restype = wt.HANDLE
    k.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
    k.GetCurrentProcess.restype = wt.HANDLE
    k.GetCurrentProcess.argtypes = []
    k.CloseHandle.restype = wt.BOOL
    k.CloseHandle.argtypes = [wt.HANDLE]
    k.SetHandleInformation.restype = wt.BOOL
    k.SetHandleInformation.argtypes = [wt.HANDLE, wt.DWORD, wt.DWORD]
    k.GetHandleInformation.restype = wt.BOOL
    k.GetHandleInformation.argtypes = [wt.HANDLE, ctypes.POINTER(wt.DWORD)]
    k.CreateToolhelp32Snapshot.restype = wt.HANDLE
    k.CreateToolhelp32Snapshot.argtypes = [wt.DWORD, wt.DWORD]
    k.Thread32First.restype = wt.BOOL
    k.Thread32First.argtypes = [wt.HANDLE, ctypes.POINTER(THREADENTRY32)]
    k.Thread32Next.restype = wt.BOOL
    k.Thread32Next.argtypes = [wt.HANDLE, ctypes.POINTER(THREADENTRY32)]
    k.OpenThread.restype = wt.HANDLE
    k.OpenThread.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
    k.ResumeThread.restype = wt.DWORD
    k.ResumeThread.argtypes = [wt.HANDLE]
    k.LocalFree.restype = ctypes.c_void_p
    k.LocalFree.argtypes = [ctypes.c_void_p]
    return k


def create_kill_on_close_job(k32: ctypes.WinDLL | None = None) -> int:
    """Create a Job Object that kills every member when its last handle closes. Raises OSError on any failure.

    The handle is explicitly marked NOT inheritable: if a child inherited it, the job would stay open as long as
    that child lives, and "kill on close" would never fire.
    """
    k = k32 or _kernel32()
    job = k.CreateJobObjectW(None, None)
    if not job:
        raise OSError(f"CreateJobObject failed (error {ctypes.get_last_error()})")
    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
    if not k.SetInformationJobObject(job, JobObjectExtendedLimitInformation, ctypes.byref(info), ctypes.sizeof(info)):
        err = ctypes.get_last_error()
        k.CloseHandle(job)
        raise OSError(f"SetInformationJobObject failed (error {err})")
    k.SetHandleInformation(job, HANDLE_FLAG_INHERIT, 0)
    return job


def query_job_limit_flags(job: int, k32: ctypes.WinDLL | None = None) -> int:
    """Read back the LimitFlags of a job (tests use this to prove KILL_ON_JOB_CLOSE is really set)."""
    k = k32 or _kernel32()
    info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
    got = wt.DWORD(0)
    if not k.QueryInformationJobObject(job, JobObjectExtendedLimitInformation, ctypes.byref(info),
                                       ctypes.sizeof(info), ctypes.byref(got)):
        raise OSError(f"QueryInformationJobObject failed (error {ctypes.get_last_error()})")
    return int(info.BasicLimitInformation.LimitFlags)


def handle_is_inheritable(handle: int, k32: ctypes.WinDLL | None = None) -> bool:
    k = k32 or _kernel32()
    flags = wt.DWORD(0)
    if not k.GetHandleInformation(handle, ctypes.byref(flags)):
        raise OSError(f"GetHandleInformation failed (error {ctypes.get_last_error()})")
    return bool(flags.value & HANDLE_FLAG_INHERIT)


def close_handle(handle: int, k32: ctypes.WinDLL | None = None) -> None:
    (k32 or _kernel32()).CloseHandle(handle)


def resume_all_threads(pid: int, k32: ctypes.WinDLL | None = None) -> int:
    """Resume every thread of a process created with CREATE_SUSPENDED. Returns how many threads were resumed.

    subprocess.Popen closes the main-thread handle it gets from CreateProcess, so we find the thread(s) again with
    a Toolhelp snapshot (a documented API) and call ResumeThread on each.
    """
    k = k32 or _kernel32()
    snap = k.CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0)
    if not snap or snap == INVALID_HANDLE_VALUE:
        raise OSError(f"CreateToolhelp32Snapshot failed (error {ctypes.get_last_error()})")
    resumed = 0
    try:
        te = THREADENTRY32()
        te.dwSize = ctypes.sizeof(te)
        ok = k.Thread32First(snap, ctypes.byref(te))
        while ok:
            if te.th32OwnerProcessID == pid:
                h = k.OpenThread(THREAD_SUSPEND_RESUME, False, te.th32ThreadID)
                if h:
                    try:
                        if k.ResumeThread(h) != 0xFFFFFFFF:
                            resumed += 1
                    finally:
                        k.CloseHandle(h)
            ok = k.Thread32Next(snap, ctypes.byref(te))
    finally:
        k.CloseHandle(snap)
    return resumed


class WindowsPlatform(Platform):
    os_name = "windows"

    def __init__(self) -> None:
        self._k32 = _kernel32()
        self._job: int | None = None
        self._self_contained = False

    # ----- paths -------------------------------------------------------------------------------------------
    def default_data_dir(self) -> Path:
        base = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(base) / "HoneyBadger" / "Bunker"

    # ----- processes ---------------------------------------------------------------------------------------
    def spawn_kwargs(self) -> dict:
        # NO window, and its own process group so a Ctrl+C in the engine's terminal is not forwarded to servers.
        flags = CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP
        if not self._self_contained:
            flags |= CREATE_SUSPENDED      # runs nothing until it is inside the job (see after_spawn)
        return {"creationflags": flags}

    def _ensure_job(self) -> int:
        """The engine's one kill-on-close job (created on first use). Raises OSError if Windows refuses."""
        if self._job is None:
            self._job = create_kill_on_close_job(self._k32)
        return self._job

    def contain_self(self) -> str:
        """Put the ENGINE itself into its kill-on-close job, so every child is born inside the job.

        Windows allows nested jobs (Windows 8 and later), so this works even when the engine was started from a
        terminal that has its own job. If it fails we fall back to suspended-create/assign/resume for each child.
        """
        try:
            job = self._ensure_job()
            if not self._k32.AssignProcessToJobObject(job, self._k32.GetCurrentProcess()):
                raise OSError(f"AssignProcessToJobObject(self) failed (error {ctypes.get_last_error()})")
        except OSError as exc:
            log.warning("engine could not join its own job (%s); children will be assigned one by one", exc)
            return "job-per-child"
        self._self_contained = True
        return "job-at-creation"

    def containment(self) -> str:
        return "job-at-creation" if self._self_contained else "job-per-child"

    def in_our_job(self, pid: int) -> bool:
        """Is this process a member of the engine's job?"""
        if self._job is None:
            return False
        h = self._k32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not h:
            return False
        try:
            res = wt.BOOL(0)
            if not self._k32.IsProcessInJob(h, self._job, ctypes.byref(res)):
                return False
            return bool(res.value)
        finally:
            self._k32.CloseHandle(h)

    def after_spawn(self, pid: int) -> None:
        """Make sure the new process is in the engine's job, then let it run. Raises OSError if it cannot be.

        Self-contained engine: the child inherited the job at creation; we only verify it. Otherwise the child was
        created suspended: assign it, then resume its threads.
        """
        job = self._ensure_job()
        if self._self_contained:
            if not self.in_our_job(pid):
                raise OSError(f"child {pid} was not created inside the engine's job")
            return
        h = self._k32.OpenProcess(PROCESS_SET_QUOTA | PROCESS_TERMINATE, False, pid)
        if not h:
            raise OSError(f"OpenProcess({pid}) failed (error {ctypes.get_last_error()})")
        try:
            if not self._k32.AssignProcessToJobObject(job, h):
                raise OSError(f"AssignProcessToJobObject({pid}) failed (error {ctypes.get_last_error()})")
        finally:
            self._k32.CloseHandle(h)
        if resume_all_threads(pid, self._k32) < 1:
            raise OSError(f"could not resume the suspended child {pid}")

    def terminate_tree(self, pid: int) -> None:
        # Windows has no SIGTERM for a window-less console program; the graceful path is RCON "quit".
        self.kill_tree(pid)

    # ----- locks -------------------------------------------------------------------------------------------
    def _lock_fh(self, fh: IO[bytes]) -> None:
        fh.seek(0)
        msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)

    def _unlock_fh(self, fh: IO[bytes]) -> None:
        fh.seek(0)
        try:
            msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
        except OSError:
            pass

    # ----- secrets -----------------------------------------------------------------------------------------
    def protect(self, data: bytes) -> bytes:
        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        buf = ctypes.create_string_buffer(data, len(data))
        blob_in = DATA_BLOB(len(data), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
        blob_out = DATA_BLOB()
        if not crypt32.CryptProtectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
            raise OSError(f"CryptProtectData failed ({ctypes.get_last_error()})")
        try:
            return b"dpapi:" + ctypes.string_at(blob_out.pbData, blob_out.cbData)
        finally:
            self._k32.LocalFree(blob_out.pbData)

    def unprotect(self, blob: bytes) -> bytes:
        if not blob.startswith(b"dpapi:"):
            return blob.removeprefix(b"plain:")
        raw = blob[len(b"dpapi:"):]
        crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
        buf = ctypes.create_string_buffer(raw, len(raw))
        blob_in = DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)))
        blob_out = DATA_BLOB()
        if not crypt32.CryptUnprotectData(ctypes.byref(blob_in), None, None, None, None, 0, ctypes.byref(blob_out)):
            raise OSError(f"CryptUnprotectData failed ({ctypes.get_last_error()})")
        try:
            return ctypes.string_at(blob_out.pbData, blob_out.cbData)
        finally:
            self._k32.LocalFree(blob_out.pbData)
