"""Pick the right operating-system adapter once: `from hbdeck.platform import current_platform`."""
from __future__ import annotations

import sys
from functools import lru_cache

from .base import FileLock, LockBusy, Platform, ProcessIdentity, kill_and_reap, process_liveness

__all__ = ["FileLock", "LockBusy", "Platform", "ProcessIdentity", "current_platform", "kill_and_reap",
           "process_liveness"]


@lru_cache(maxsize=1)
def current_platform() -> Platform:
    if sys.platform == "win32":
        from .win import WindowsPlatform
        return WindowsPlatform()
    from .linux import LinuxPlatform
    return LinuxPlatform()
