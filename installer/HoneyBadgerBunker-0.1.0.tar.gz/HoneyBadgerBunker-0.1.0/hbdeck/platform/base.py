"""The operating-system seam: everything that differs between Windows and Linux lives behind this one interface.

Business logic (supervisor, steamcmd, backups...) only ever calls these methods, so the same engine code runs on
both systems. The two real implementations are in win.py and linux.py.

What lives here:
- where data goes by default (state.db, logs, servers)
- starting a program HIDDEN (no console window, ever) with its output captured
- killing a whole process tree (the server plus anything it started)
- exclusive file locks (so two engines can never manage the same server)
- protecting secrets at rest (the RCON password)
"""
from __future__ import annotations

import asyncio
import os
import sys
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import IO, Callable

import psutil


class LockBusy(RuntimeError):
    """Raised when another process already holds a lock we need."""


@dataclass(frozen=True)
class ProcessIdentity:
    """A PID alone is not proof of identity (Windows and Linux re-use PIDs). PID + creation time is."""
    pid: int
    create_time: float

    def liveness(self) -> str:
        """"alive", "dead" or "unknown".

        "unknown" means the OS refused to tell us (access denied). The guards treat unknown as ALIVE: a process we
        cannot inspect might be a running server, and guessing "dead" is how two servers end up on one world.
        """
        return process_liveness(self.pid, self.create_time)

    def is_alive(self) -> bool:
        """True when the process is alive OR we cannot tell (access denied counts as alive, never as dead)."""
        return self.liveness() != "dead"


def process_liveness(pid: int | None, create_time: float | None) -> str:
    """Is THIS process (pid + creation time) still running? Returns "alive", "dead" or "unknown".

    A pid alone is not enough: Windows and Linux hand out the same pid again after a process ends. So a pid whose
    creation time differs from the one we stored by a second or more is a DIFFERENT process = ours is dead.
    """
    if not pid:
        return "dead"
    try:
        p = psutil.Process(int(pid))
        if create_time is not None and abs(p.create_time() - float(create_time)) >= 1.0:
            return "dead"                     # the pid was re-used by another program
        if p.status() == psutil.STATUS_ZOMBIE:
            return "dead"                     # exited, only waiting to be reaped by its parent
        return "alive" if p.is_running() else "dead"
    except psutil.NoSuchProcess:
        return "dead"
    except psutil.AccessDenied:
        return "unknown"
    except psutil.Error:
        return "unknown"


class FileLock:
    """An exclusive, non-blocking lock on a small file. Use with `with FileLock(path):`.

    The OS releases the lock automatically if our process dies, so a crash never leaves a stale lock behind.
    """

    def __init__(self, path: Path, platform: "Platform") -> None:
        self.path = Path(path)
        self._platform = platform
        self._fh: IO[bytes] | None = None

    def acquire(self) -> "FileLock":
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fh = open(self.path, "a+b")
        try:
            self._platform._lock_fh(fh)
        except OSError as exc:
            fh.close()
            raise LockBusy(f"{self.path} is locked by another process") from exc
        try:  # record who holds it (informational only)
            fh.seek(0)
            fh.truncate()
            fh.write(f"{os.getpid()}\n".encode())
            fh.flush()
        except OSError:
            pass
        self._fh = fh
        return self

    def release(self) -> None:
        if self._fh is not None:
            try:
                self._platform._unlock_fh(self._fh)
            finally:
                self._fh.close()
                self._fh = None

    @property
    def held(self) -> bool:
        return self._fh is not None

    def __enter__(self) -> "FileLock":
        return self.acquire()

    def __exit__(self, *exc: object) -> None:
        self.release()


class Platform(ABC):
    """One interface, two implementations (WindowsPlatform, LinuxPlatform)."""

    os_name: str = "unknown"          # "windows" or "linux" - the key games/ and frameworks/ use

    # ----- paths -------------------------------------------------------------------------------------------
    @abstractmethod
    def default_data_dir(self) -> Path:
        """Where state.db, logs, cache and secrets live when no --data folder is given."""

    def default_servers_dir(self, data_dir: Path) -> Path:
        """Where new servers are installed by default."""
        return data_dir / "servers"

    # ----- processes ---------------------------------------------------------------------------------------
    @abstractmethod
    def spawn_kwargs(self) -> dict:
        """Extra keyword arguments for asyncio.create_subprocess_exec that hide the window / detach the group."""

    async def spawn(self, argv: list[str], cwd: Path | None = None, env: dict[str, str] | None = None,
                    stdin_pipe: bool = False, gate: Callable[[], None] | None = None) -> asyncio.subprocess.Process:
        """Start a program hidden, with stdout and stderr captured as pipes.

        argv is a LIST (program first, then each argument as its own item). We never build a shell command string,
        so spaces, quotes and apostrophes in paths can never break or inject anything.

        gate: called right before the process is created, with NO await in between. If it raises, nothing is
        started. The supervisor passes "is the engine still allowed to start servers?" here, so a shutdown that
        began a microsecond earlier always wins (asyncio creates the process before its first real pause).
        """
        if gate is not None:
            gate()
        proc = await asyncio.create_subprocess_exec(
            *argv,
            cwd=str(cwd) if cwd else None,
            env=env,
            stdin=asyncio.subprocess.PIPE if stdin_pipe else asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            **self.spawn_kwargs(),
        )
        try:
            self.after_spawn(proc.pid)
        except BaseException:
            # Containment is mandatory: a child we cannot contain is killed and reaped, never left running.
            await kill_and_reap(proc, self)
            raise
        return proc

    def after_spawn(self, pid: int) -> None:
        """Hook: Windows checks/puts the new process into the engine's Job Object here (raises OSError on failure)."""

    def contain_self(self) -> str:
        """Tie every future child to THIS process's lifetime at creation time. Returns what was used.

        Windows: the engine joins its own kill-on-close Job Object (children inherit it the moment they are
        created). Linux: systemd's cgroup does this when we run as a service; otherwise only process groups.
        """
        return "none"

    def containment(self) -> str:
        """Short description of how our children are contained (stored in the ownership registry)."""
        return "none"

    @abstractmethod
    def terminate_tree(self, pid: int) -> None:
        """Politely ask a process tree to end (SIGTERM on Linux; Windows has no polite signal for hidden apps)."""

    def kill_tree(self, pid: int) -> None:
        """Forcefully end a process and every child it started."""
        try:
            parent = psutil.Process(pid)
        except psutil.NoSuchProcess:
            return
        procs = parent.children(recursive=True) + [parent]
        for p in procs:
            try:
                p.kill()
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        psutil.wait_procs(procs, timeout=10)

    def wait_dead(self, pid: int, create_time: float | None, timeout: float) -> bool:
        """Block up to `timeout` seconds until the process is verifiably gone. Unknown (access denied) = not gone."""
        import time
        end = time.monotonic() + max(0.0, timeout)
        while True:
            if process_liveness(pid, create_time) == "dead":
                return True
            if time.monotonic() >= end:
                return False
            time.sleep(0.05)

    def identity_of(self, pid: int) -> ProcessIdentity | None:
        try:
            return ProcessIdentity(pid, psutil.Process(pid).create_time())
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return None

    # ----- locks -------------------------------------------------------------------------------------------
    def lock(self, path: Path) -> FileLock:
        return FileLock(path, self)

    @abstractmethod
    def _lock_fh(self, fh: IO[bytes]) -> None: ...

    @abstractmethod
    def _unlock_fh(self, fh: IO[bytes]) -> None: ...

    # ----- secrets -----------------------------------------------------------------------------------------
    @abstractmethod
    def protect(self, data: bytes) -> bytes:
        """Encrypt/wrap a secret for storage on disk (DPAPI on Windows; file permissions on Linux)."""

    @abstractmethod
    def unprotect(self, blob: bytes) -> bytes: ...

    def restrict_permissions(self, path: Path) -> None:
        """Make a file readable by the current user only (best effort)."""

    def python_executable(self) -> str:
        return sys.executable


async def kill_and_reap(proc: asyncio.subprocess.Process, platform: "Platform", timeout: float = 10.0) -> None:
    """Kill a child we just created (and anything it started), then wait for it so no zombie is left."""
    if proc.returncode is None:
        try:
            platform.kill_tree(proc.pid)
        except Exception:  # noqa: BLE001 - fall back to the plain kill below
            pass
        try:
            proc.kill()
        except ProcessLookupError:
            pass
    try:
        await asyncio.wait_for(proc.wait(), timeout)
    except asyncio.TimeoutError:
        pass
