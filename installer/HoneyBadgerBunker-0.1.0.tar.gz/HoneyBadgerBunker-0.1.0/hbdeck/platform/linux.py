"""Linux implementation of the platform seam.

Key Linux facts used here:
- start_new_session=True puts the server in its own process group (and session, so it has no terminal). We can
  then signal the whole group at once: SIGTERM first, SIGKILL if it ignores us.
- flock() gives an exclusive advisory lock that the kernel drops if our process dies.
- Secrets are protected by file permissions (0600, owned by the service user). We do not pretend to "encrypt"
  with a key stored next to the file - that would be fake security.
"""
from __future__ import annotations

import fcntl  # type: ignore[import-not-found]  # Linux-only module
import os
import signal
from pathlib import Path
from typing import IO

from .base import Platform


class LinuxPlatform(Platform):
    os_name = "linux"

    def default_data_dir(self) -> Path:
        system = Path("/var/lib/honeybadger")
        if os.geteuid() == 0 or (system.exists() and os.access(system, os.W_OK)):
            return system
        xdg = os.environ.get("XDG_DATA_HOME") or str(Path.home() / ".local" / "share")
        return Path(xdg) / "honeybadger" / "bunker"

    def default_servers_dir(self, data_dir: Path) -> Path:
        srv = Path("/srv/honeybadger/servers")
        if data_dir == Path("/var/lib/honeybadger") and (srv.exists() or os.geteuid() == 0):
            return srv
        return data_dir / "servers"

    def spawn_kwargs(self) -> dict:
        return {"start_new_session": True}

    def contain_self(self) -> str:
        return self.containment()

    def containment(self) -> str:
        # Under systemd every process of the unit (engine, servers, SteamCMD) lives in the unit's cgroup, and
        # KillMode=mixed + SendSIGKILL=yes ends them all when the unit stops. Outside systemd a process group lets
        # us signal a server and its children together, but it does NOT die with the engine.
        return "systemd-cgroup" if os.environ.get("INVOCATION_ID") else "process-group"

    def terminate_tree(self, pid: int) -> None:
        try:
            os.killpg(os.getpgid(pid), signal.SIGTERM)
        except (ProcessLookupError, PermissionError):
            pass

    def kill_tree(self, pid: int) -> None:
        try:
            os.killpg(os.getpgid(pid), signal.SIGKILL)
        except (ProcessLookupError, PermissionError):
            pass
        super().kill_tree(pid)

    def _lock_fh(self, fh: IO[bytes]) -> None:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock_fh(self, fh: IO[bytes]) -> None:
        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)

    def protect(self, data: bytes) -> bytes:
        return b"plain:" + data

    def unprotect(self, blob: bytes) -> bytes:
        return blob.removeprefix(b"plain:")

    def restrict_permissions(self, path: Path) -> None:
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
