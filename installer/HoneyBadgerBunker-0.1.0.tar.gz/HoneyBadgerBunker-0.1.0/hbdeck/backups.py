"""Backups, restores and wipes.

A backup is ONE zip file: the whole server/<identity> folder (world, players, cfg) plus the framework's plugins,
configs and data. Inside it, hbdeck-backup.json lists every file with its sha256; next to it a small .json says
when it was made and the zip's own sha256 (so a damaged backup is detected before a restore uses it).

Safety rules (codex review failure mode 8):
- the server must be stopped (the supervisor proves it) and the profile's operation lock held;
- a wipe ALWAYS takes a backup first;
- wiped files are first MOVED to a quarantine folder on the same disk, then deleted only after the wipe succeeded;
- a restore unpacks into a fresh staging folder, checks it, and only then swaps it in (never mixes old + new).
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import zipfile
from pathlib import Path
from typing import Callable, Iterable

from .archive import extract_zip, sha256_file
from .frameworks import DATA_DIRS
from .games import get_game
from .games.rust import check_safe_identity_dir
from .models import BackupInfo, Profile, iso, new_id, utcnow
from .operations import OpError

MANIFEST_NAME = "hbdeck-backup.json"

# Every backup has a KIND, saved in its .json next to the zip ("kind", plus "schedule_id" for scheduled ones):
#   manual      - the user pressed Back up              } PROTECTED: no automatic clean-up ever deletes these
#   pre_wipe    - taken automatically before a wipe     }
#   pre_restore - the safety copy taken before a restore }
#   scheduled   - made by a backup schedule; that schedule keeps only its newest `keep_newest`
#   other       - anything else (e.g. "before switching to oxide"); the manager-wide retention applies
# Backups made before kinds existed have no "kind": we infer pre_wipe / pre_restore / manual from the labels the
# engine has always used, and treat the rest like "other", so old data keeps the manager-wide retention.
KINDS = ("manual", "pre_wipe", "pre_restore", "scheduled", "other")
PROTECTED_KINDS = frozenset({"manual", "pre_wipe", "pre_restore"})
DEFAULT_KEEP_NEWEST = 10
MAX_KEEP_NEWEST = 1000


def validate_keep_newest(value: object) -> int:
    """A schedule's keep_newest: a whole number from 1 to 1000 (0 would delete the backup just made)."""
    if isinstance(value, bool):
        raise OpError("keep_newest must be a whole number from 1 to 1000", "invalid_value")
    try:
        n = int(value)  # type: ignore[call-overload]
    except (TypeError, ValueError) as exc:
        raise OpError("keep_newest must be a whole number from 1 to 1000", "invalid_value") from exc
    if not 1 <= n <= MAX_KEEP_NEWEST or str(n) != str(value).strip():
        raise OpError("keep_newest must be a whole number from 1 to 1000", "invalid_value")
    return n


def infer_kind(meta: dict) -> str:
    """The kind of a backup from its .json (explicit "kind", or inferred from an old label)."""
    kind = meta.get("kind")
    if kind in KINDS:
        return str(kind)
    label = str(meta.get("label") or "").lower()
    if "before restoring" in label:
        return "pre_restore"
    if label.startswith("before ") and label.endswith("wipe"):
        return "pre_wipe"
    if label == "manual backup":
        return "manual"
    return "other"


class BackupManager:
    def __init__(self, data_dir: Path, retention: int = 20) -> None:
        self.data_dir = Path(data_dir)
        self.retention = retention

    def dir_for(self, profile: Profile) -> Path:
        return self.data_dir / "backups" / profile.id

    def list(self, profile: Profile) -> list[BackupInfo]:
        d = self.dir_for(profile)
        out: list[BackupInfo] = []
        if not d.exists():
            return out
        for meta in d.glob("*.json"):
            try:
                out.append(BackupInfo.model_validate_json(meta.read_text(encoding="utf-8")))
            except ValueError:
                continue
        return sorted(out, key=lambda b: b.id, reverse=True)

    def entries(self, profile: Profile) -> list[dict]:
        """Like list(), but plain dicts that also carry "kind", "protected" and "schedule_id" (newest first)."""
        return self._entries_in(self.dir_for(profile))

    @staticmethod
    def _entries_in(d: Path) -> list[dict]:
        out: list[dict] = []
        if not d.is_dir():
            return out
        for meta in d.glob("*.json"):
            try:
                raw = json.loads(meta.read_text(encoding="utf-8"))
                info = BackupInfo.model_validate(raw)
            except (OSError, ValueError):
                continue
            kind = infer_kind(raw)
            out.append({**info.model_dump(), "kind": kind, "protected": kind in PROTECTED_KINDS,
                        "schedule_id": raw.get("schedule_id"),
                        "recorded_kind": raw["kind"] if raw.get("kind") in KINDS else None})
        return sorted(out, key=lambda b: b["id"], reverse=True)

    def rows(self, profile: Profile, keep_of_schedule: Callable[[str], int | None] | None = None) -> list[dict]:
        """GET /profiles/{id}/backups: one row per backup with its protection rule (WP43).

        kind      = the kind written when the backup was made (manual | scheduled | pre_wipe | pre_restore | other),
                    or "unknown" for an archive made before kinds were recorded;
        protected = True when no automatic clean-up ever deletes it. For an "unknown" archive this follows the
                    label the engine has always used (what the clean-up really does), so it can still be True;
        keep_newest = how many of its group are kept: the schedule's number for scheduled (None if that schedule
                    is gone, then nothing prunes it), the manager-wide number for other/unknown, None if protected.
        """
        return self._public(self.entries(profile), keep_of_schedule)

    def _public(self, entries: list[dict], keep_of_schedule: Callable[[str], int | None] | None = None) -> list[dict]:
        out = []
        for e in entries:
            row = {k: v for k, v in e.items() if k != "recorded_kind"}
            row["kind"] = e.get("recorded_kind") or "unknown"
            if e["protected"]:
                row["keep_newest"] = None
            elif e["kind"] == "scheduled":
                sid = e.get("schedule_id")
                row["keep_newest"] = keep_of_schedule(sid) if (keep_of_schedule and sid) else None
            else:
                row["keep_newest"] = self.retention
            out.append(row)
        return out

    def _sources(self, profile: Profile) -> list[tuple[Path, str]]:
        """(folder on disk, name inside the zip) pairs that make up a backup."""
        root = Path(profile.install_root)
        game = get_game(profile.game)
        items = [(game.identity_dir(profile), f"server/{profile.identity}")]
        for fw_dirs in DATA_DIRS.values():
            for rel in fw_dirs:
                if (root / rel).is_dir():
                    items.append((root / rel, rel))
        return items

    def create(self, profile: Profile, label: str, log: Callable[[str], None], protect: str | None = None, *,
               kind: str | None = None, schedule_id: str | None = None,
               keep_newest: int | None = None) -> BackupInfo:
        """Write one backup zip. Clean-up runs only AFTER the new zip and its .json are safely on disk:
        a failed backup never deletes an old one.

        kind="scheduled" needs schedule_id; that schedule then keeps its newest `keep_newest` (default 10)
        scheduled backups. Protected kinds (manual / pre_wipe / pre_restore) are never deleted automatically.
        kind=None keeps the old behaviour (inferred from the label) for callers not yet passing a kind.
        """
        if kind is not None and kind not in KINDS:
            raise OpError(f"unknown backup kind '{kind}'", "bad_request")
        if kind == "scheduled":
            if not schedule_id:
                raise OpError("a scheduled backup needs its schedule id", "bad_request")
            keep_newest = validate_keep_newest(DEFAULT_KEEP_NEWEST if keep_newest is None else keep_newest)
        game = get_game(profile.game)
        ident = game.identity_dir(profile)
        if not ident.exists():
            raise OpError("nothing to back up yet: the server has never run", "nothing_to_backup")
        bid = utcnow().strftime("%Y%m%d-%H%M%S-%f")       # sortable, unique per microsecond
        d = self.dir_for(profile)
        d.mkdir(parents=True, exist_ok=True)
        tmp = d / f".{bid}.zip.part"
        try:
            info, nfiles = self._write_zip(profile, label, d, bid, tmp)
        except BaseException:
            try:
                tmp.unlink()                              # never leave a half-written zip behind
            except OSError:
                pass
            raise
        meta = info.model_dump()
        if kind is not None:
            meta["kind"] = kind
        if kind == "scheduled":
            meta["schedule_id"] = schedule_id
        (d / f"{bid}.json").write_text(json.dumps(meta, indent=1), encoding="utf-8")
        log(f"Backup {bid}: {nfiles} files, {info.size / 1e6:.1f} MB")
        # --- the archive is complete; only now may anything old be removed ---
        if kind == "scheduled":
            removed = self.prune_schedule(profile, str(schedule_id), int(keep_newest or DEFAULT_KEEP_NEWEST),
                                          protect=protect)
            if removed:
                log(f"Schedule kept its newest {keep_newest} backups; removed {len(removed)} older")
        self._retain(profile, protect=protect)
        return info

    def _write_zip(self, profile: Profile, label: str, d: Path, bid: str, tmp: Path) -> tuple[BackupInfo, int]:
        files: dict[str, str] = {}
        contents: list[str] = []
        with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            for folder, arc_root in self._sources(profile):
                contents.append(arc_root + "/")
                for path in sorted(folder.rglob("*")):
                    if path.is_symlink() or not path.is_file():
                        continue
                    rel = path.relative_to(folder).as_posix()
                    arc = f"{arc_root}/{rel}"
                    h = hashlib.sha256()
                    with open(path, "rb") as src, zf.open(arc, "w", force_zip64=True) as dst:
                        for chunk in iter(lambda: src.read(1 << 20), b""):
                            h.update(chunk)
                            dst.write(chunk)
                    files[arc] = h.hexdigest()
            zf.writestr(MANIFEST_NAME, json.dumps({"profile_id": profile.id, "identity": profile.identity,
                                                   "label": label, "created": iso(utcnow()), "files": files},
                                                  indent=1))
        final = d / f"{bid}.zip"
        os.replace(tmp, final)
        info = BackupInfo(id=bid, label=label or "backup", created=iso(utcnow()) or "", size=final.stat().st_size,
                          sha256=sha256_file(final), contents=contents)
        return info, len(files)

    def _retain(self, profile: Profile, protect: str | None = None) -> None:
        """Manager-wide retention: keep the newest `retention` backups that are neither protected nor owned by a
        schedule (schedules prune their own; protected kinds are never pruned)."""
        pool = [b for b in self.entries(profile) if not b["protected"] and b["kind"] != "scheduled"]
        for old in pool[self.retention:]:
            if protect and old["id"] == protect:
                continue      # the backup a restore is about to open must survive retention (Codex, tonight)
            self.delete(profile, old["id"])

    def prune_schedule(self, profile: Profile, schedule_id: str, keep_newest: int,
                       protect: str | None = None) -> list[str]:
        """Keep the newest `keep_newest` backups made by ONE schedule; delete its older ones. Returns removed ids.
        Only kind == "scheduled" with this schedule_id is ever touched."""
        keep_newest = validate_keep_newest(keep_newest)
        mine = [b for b in self.entries(profile) if b["kind"] == "scheduled" and b["schedule_id"] == schedule_id]
        removed: list[str] = []
        for old in mine[keep_newest:]:
            if protect and old["id"] == protect:
                continue
            self.delete(profile, old["id"])
            removed.append(old["id"])
        return removed

    def orphaned(self, profiles: Iterable[Profile]) -> list[dict]:
        """Backup folders whose profile no longer exists (the server was removed but its backups were kept).
        Backups are stored by profile id (backups/<profile id>/), so re-adding the same server folder makes a NEW
        id and would not see them; this list is how the UI shows them (GET /backups/orphaned)."""
        known = {p.id for p in profiles}
        root = self.data_dir / "backups"
        out: list[dict] = []
        if not root.is_dir():
            return out
        for d in sorted(root.iterdir()):
            if not d.is_dir() or d.name in known or d.name.startswith("."):
                continue
            items = self._entries_in(d)
            if not items:
                continue
            out.append({"profile_id": d.name, "identity": self._identity_of(d, items[0]["id"]),
                        "count": len(items), "total_bytes": sum(int(b.get("size") or 0) for b in items),
                        "newest": items[0]["created"], "backups": self._public(items)})
        return out

    @staticmethod
    def _identity_of(d: Path, backup_id: str) -> str | None:
        """The server identity recorded inside a backup's own manifest (None if it cannot be read)."""
        try:
            with zipfile.ZipFile(d / f"{backup_id}.zip") as zf:
                return json.loads(zf.read(MANIFEST_NAME)).get("identity")
        except (OSError, KeyError, ValueError, zipfile.BadZipFile):
            return None

    def delete(self, profile: Profile, backup_id: str) -> None:
        d = self.dir_for(profile)
        if "/" in backup_id or "\\" in backup_id or ".." in backup_id:
            raise OpError("bad backup id", "bad_request")
        found = False
        for suffix in (".zip", ".json"):
            p = d / f"{backup_id}{suffix}"
            if p.exists():
                p.unlink()
                found = True
        if not found:
            raise OpError("backup not found", "not_found")

    def restore(self, profile: Profile, backup_id: str, log: Callable[[str], None]) -> None:
        d = self.dir_for(profile)
        meta = d / f"{backup_id}.json"
        z = d / f"{backup_id}.zip"
        if "/" in backup_id or "\\" in backup_id or not meta.exists() or not z.exists():
            raise OpError("backup not found", "not_found")
        info = BackupInfo.model_validate_json(meta.read_text(encoding="utf-8"))
        if sha256_file(z) != info.sha256:
            raise OpError("this backup file is damaged (checksum mismatch); it was not restored", "backup_damaged")
        root = Path(profile.install_root)
        stage = root / f".hbdeck-restore-{backup_id}"
        if stage.exists():
            shutil.rmtree(stage)
        extract_zip(z, stage)
        manifest = json.loads((stage / MANIFEST_NAME).read_text(encoding="utf-8"))
        for arc, digest in manifest.get("files", {}).items():
            if sha256_file(stage / arc) != digest:
                shutil.rmtree(stage)
                raise OpError(f"backup content check failed for {arc}", "backup_damaged")
        quarantine = root / ".hbdeck-quarantine" / f"restore-{backup_id}"
        quarantine.mkdir(parents=True, exist_ok=True)
        for _folder, arc_root in self._sources(profile) + [(root / r, r) for r in self._zip_roots(stage)]:
            src = stage / arc_root
            dest = root / arc_root
            if not src.exists():
                continue
            if dest.exists():
                q = quarantine / arc_root
                q.parent.mkdir(parents=True, exist_ok=True)
                os.replace(dest, q)
            dest.parent.mkdir(parents=True, exist_ok=True)
            os.replace(src, dest)
        shutil.rmtree(stage, ignore_errors=True)
        shutil.rmtree(quarantine, ignore_errors=True)
        log(f"Restored backup {backup_id} ({info.label})")

    @staticmethod
    def _zip_roots(stage: Path) -> list[str]:
        roots: list[str] = []
        for fw_dirs in DATA_DIRS.values():
            roots += [r for r in fw_dirs if (stage / r).exists()]
        return roots

    def wipe(self, profile: Profile, scope: str, log: Callable[[str], None]) -> list[str]:
        """Remove the files of a wipe plan via a quarantine folder. Returns the removed names."""
        game = get_game(profile.game)
        plan = game.wipe_plan(profile, scope)
        root = Path(profile.install_root)
        check_safe_identity_dir(Path(os.path.realpath(root)), plan.identity_dir)
        quarantine = root / ".hbdeck-quarantine" / f"wipe-{utcnow().strftime('%Y%m%d-%H%M%S')}"
        quarantine.mkdir(parents=True, exist_ok=True)
        moved: list[str] = []
        try:
            for f in plan.files:
                if f.parent != plan.identity_dir:
                    raise OpError(f"unexpected file outside the identity folder: {f}", "unsafe_wipe")
                os.replace(f, quarantine / f.name)
                moved.append(f.name)
        except Exception:
            for name in moved:                       # put everything back exactly as it was
                os.replace(quarantine / name, plan.identity_dir / name)
            shutil.rmtree(quarantine, ignore_errors=True)
            raise
        shutil.rmtree(quarantine, ignore_errors=True)
        log(f"Wiped ({scope}): {len(moved)} items removed: {', '.join(moved) if moved else 'nothing to remove'}")
        return moved
