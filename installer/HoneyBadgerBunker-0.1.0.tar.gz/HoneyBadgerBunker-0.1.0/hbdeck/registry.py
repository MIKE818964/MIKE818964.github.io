"""Ownership registry: every process the Bunker starts, written down so "Stop everything" can find it later.

Lives in <data>/ownership.db (SQLite, separate from state.db so the offline tools - `hbdeck kill-all`,
`hbdeck status` - can read it without touching the engine's own database). One row per process:

    kind          engine | game | steamcmd | helper | shell (the Deck window, written by `hbdeck shell`)
    pid           process id
    create_time   process creation time (seconds since 1970). pid + create_time = THIS process, never a re-used pid
    exe           the program that was started (argv[0])
    cmdline       the full argument list (JSON). Passwords are masked before they are stored.
    install_root  normalised server folder (game / steamcmd rows)
    data_dir      normalised data folder of the engine that started it
    instance      the engine instance id (one per engine start)
    run_id        the server run id (game rows)
    profile_id, identity
    containment   job-at-creation | job-per-child | systemd-cgroup | process-group | none
    started_at    ISO time

A row is removed only after the process is verified dead (pid gone, or the pid now belongs to a different process).
"""
from __future__ import annotations

import json
import sqlite3
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .profiles import canonical_path

SCHEMA = """
CREATE TABLE IF NOT EXISTS owned (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    kind TEXT NOT NULL,
    pid INTEGER NOT NULL,
    create_time REAL,
    exe TEXT,
    cmdline TEXT,
    install_root TEXT,
    data_dir TEXT,
    instance TEXT,
    run_id TEXT,
    profile_id TEXT,
    identity TEXT,
    containment TEXT,
    started_at TEXT
);
CREATE INDEX IF NOT EXISTS owned_pid ON owned(pid);
"""


def mask_cmdline(argv: list[str]) -> list[str]:
    out = list(argv)
    for i, a in enumerate(out[:-1]):
        if a == "+rcon.password":
            out[i + 1] = "******"
    return out


@dataclass
class Owned:
    id: int
    kind: str
    pid: int
    create_time: float | None
    exe: str | None
    cmdline: list[str]
    install_root: str | None
    data_dir: str | None
    instance: str | None
    run_id: str | None
    profile_id: str | None
    identity: str | None
    containment: str | None
    started_at: str | None

    def as_dict(self) -> dict[str, Any]:
        return {k: getattr(self, k) for k in ("kind", "pid", "create_time", "exe", "install_root", "data_dir",
                                              "instance", "run_id", "profile_id", "identity", "containment",
                                              "started_at")}


class OwnershipRegistry:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()
        self._db: sqlite3.Connection | None = sqlite3.connect(str(self.path), check_same_thread=False,
                                                              isolation_level=None, timeout=10)
        self._db.row_factory = sqlite3.Row
        try:
            self._db.execute("PRAGMA journal_mode=WAL")
        except sqlite3.DatabaseError:
            pass
        self._db.executescript(SCHEMA)

    def close(self) -> None:
        with self._lock:
            if self._db is not None:
                self._db.close()
                self._db = None

    @property
    def closed(self) -> bool:
        return self._db is None

    def add(self, kind: str, pid: int, create_time: float | None, argv: list[str] | None = None, *,
            install_root: str | Path | None = None, data_dir: str | Path | None = None, instance: str | None = None,
            run_id: str | None = None, profile_id: str | None = None, identity: str | None = None,
            containment: str | None = None, started_at: str | None = None) -> int:
        argv = mask_cmdline(argv or [])
        with self._lock:
            if self._db is None:
                return 0
            cur = self._db.execute(
                "INSERT INTO owned(kind,pid,create_time,exe,cmdline,install_root,data_dir,instance,run_id,profile_id,"
                "identity,containment,started_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (kind, int(pid), create_time, argv[0] if argv else None, json.dumps(argv),
                 canonical_path(install_root) if install_root else None,
                 canonical_path(data_dir) if data_dir else None, instance, run_id, profile_id, identity, containment,
                 started_at))
            return int(cur.lastrowid or 0)

    def remove(self, pid: int, create_time: float | None = None) -> None:
        """Forget one process (only call after its death was verified)."""
        with self._lock:
            if self._db is None:
                return
            rows = self._db.execute("SELECT id, create_time FROM owned WHERE pid=?", (int(pid),)).fetchall()
            for r in rows:
                if create_time is None or r["create_time"] is None or abs(r["create_time"] - create_time) < 1.0:
                    self._db.execute("DELETE FROM owned WHERE id=?", (r["id"],))

    def remove_row(self, row_id: int) -> None:
        with self._lock:
            if self._db is not None:
                self._db.execute("DELETE FROM owned WHERE id=?", (int(row_id),))

    def list(self, kind: str | None = None) -> list[Owned]:
        with self._lock:
            if self._db is None:
                return []
            if kind:
                rows = self._db.execute("SELECT * FROM owned WHERE kind=? ORDER BY id", (kind,)).fetchall()
            else:
                rows = self._db.execute("SELECT * FROM owned ORDER BY id").fetchall()
        out = []
        for r in rows:
            try:
                cmd = json.loads(r["cmdline"] or "[]")
            except ValueError:
                cmd = []
            out.append(Owned(id=r["id"], kind=r["kind"], pid=r["pid"], create_time=r["create_time"], exe=r["exe"],
                             cmdline=cmd, install_root=r["install_root"], data_dir=r["data_dir"],
                             instance=r["instance"], run_id=r["run_id"], profile_id=r["profile_id"],
                             identity=r["identity"], containment=r["containment"], started_at=r["started_at"]))
        return out


def open_registry(data_dir: Path) -> OwnershipRegistry:
    return OwnershipRegistry(Path(data_dir) / "ownership.db")
