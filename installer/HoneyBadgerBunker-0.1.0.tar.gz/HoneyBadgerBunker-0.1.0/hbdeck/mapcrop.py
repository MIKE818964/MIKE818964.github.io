"""mapcrop.py - crop Rust's own map render down to the island.

`world.rendermap` draws the whole world square: on a 1,000 m map the island is a small blob in a sea of flat teal
(docs/research/evidence/world_rendermap_seed1_1000m.png). The Deck's map window is small, so we find the island's
bounding box (every pixel that is not ocean), pad it, and save `<name>_island.png` next to the original. Pure function,
Pillow only (permissive licence), no game knowledge beyond "ocean is one flat colour taken from the corners".
"""
from __future__ import annotations

from pathlib import Path

from PIL import Image

PAD_FRACTION = 0.08      # breathing room around the island
MIN_SIDE = 256           # never crop smaller than this (a tiny island still gets a readable picture)
OCEAN_TOLERANCE = 18     # per-channel distance from the corner colour that still counts as ocean


def island_bbox(im: Image.Image) -> tuple[int, int, int, int] | None:
    """Bounding box of everything that is not the ocean colour, or None when the picture is all ocean."""
    rgb = im.convert("RGB")
    w, h = rgb.size
    corners = [rgb.getpixel((0, 0)), rgb.getpixel((w - 1, 0)), rgb.getpixel((0, h - 1)), rgb.getpixel((w - 1, h - 1))]
    ocean = tuple(sum(c[i] for c in corners) // 4 for i in range(3))
    # Build a mask of "not ocean" with Pillow's point tables (fast, no numpy): a pixel is land if any channel is
    # further than OCEAN_TOLERANCE from the ocean colour.
    masks = []
    for i in range(3):
        band = rgb.getchannel(i)
        lo, hi = ocean[i] - OCEAN_TOLERANCE, ocean[i] + OCEAN_TOLERANCE
        masks.append(band.point(lambda v, lo=lo, hi=hi: 255 if (v < lo or v > hi) else 0))
    from PIL import ImageChops
    land = ImageChops.lighter(ImageChops.lighter(masks[0], masks[1]), masks[2])
    return land.getbbox()


def crop_island(src: Path, dst: Path | None = None) -> Path:
    """Write the island crop (square, padded) and return its path. Returns `src` unchanged if there is no island."""
    dst = dst or src.with_name(src.stem + "_island.png")
    if dst.exists() and dst.stat().st_mtime >= src.stat().st_mtime:
        return dst
    try:
        im_ctx = Image.open(src)
    except (OSError, ValueError):                 # not a picture Pillow understands: serve the file as it is
        return src
    with im_ctx as im:
        box = island_bbox(im)
        if box is None:
            return src
        l, t, r, b = box
        side = max(r - l, b - t, MIN_SIDE)
        side = int(side * (1 + 2 * PAD_FRACTION))
        cx, cy = (l + r) // 2, (t + b) // 2
        w, h = im.size
        x0 = max(0, min(w - side, cx - side // 2))
        y0 = max(0, min(h - side, cy - side // 2))
        im.crop((x0, y0, min(w, x0 + side), min(h, y0 + side))).save(dst)
    return dst
