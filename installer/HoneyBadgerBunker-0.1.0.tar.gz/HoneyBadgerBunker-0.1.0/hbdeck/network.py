"""Network facts for the Connection page: addresses, public IP, port probes, the server query, the firewall helper.

Plain-English map of this file (docs/team/basics/BASICS_PLAN_2026-10-28.md, section A):

- lan_addresses()        which IPv4 addresses this PC has on its network cards. Loopback (127.x) and link-local
                         (169.254.x, "Windows could not get an address") are skipped. Adapters that look like a VPN
                         or a virtual switch are FLAGGED, never silently picked, so the page can ask the owner.
- public_ip()            this PC's internet address as the outside world sees it, asked from ipify.org (fallback
                         icanhazip.com). Cached 15 minutes. If a lookup fails we keep the previous answer and mark
                         it stale instead of pretending we know.
- probe_port()           can we bind this port right now? A real bind, no sharing flags: "free" or "in_use".
- a2s_info()             the Source-engine "A2S_INFO" query every Rust server answers on its query port (the same
                         packet the in-game server browser sends). Pure Python, about 60 lines, challenge aware.
- firewall_helper_text() the text of a small self-elevating .bat that adds ONE Windows Firewall rule for the game
                         and query UDP ports (never the RCON port). write_firewall_helper() saves it.
- firewall_rule_state()  asks `netsh advfirewall firewall show rule` (no admin needed) whether that rule exists.
- connect_info()         builds the GET /profiles/{pid}/connect answer. It NEVER contains the RCON password.

Honesty rules this file keeps: unknown is None (never 0, never an empty list that looks like "none found"),
a rule that exists is not "reachable", and a local query answer is not "friends can join".
"""
from __future__ import annotations

import datetime as dt
import ipaddress
import json
import os
import re
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Literal

from . import __version__

USER_AGENT = f"HoneyBadgerBunker/{__version__}"
IPIFY_URL = "https://api.ipify.org?format=json"      # documented, keyless: {"ip": "203.0.113.7"}
ICANHAZIP_URL = "https://icanhazip.com"               # plain text fallback: "203.0.113.7\n"
PUBLIC_IP_TTL_S = 15 * 60                             # how long a good answer counts as fresh
PUBLIC_IP_MIN_FORCE_S = 10.0                          # a Refresh button cannot hammer the services
HTTP_TIMEOUT_S = 5.0
FIREWALL_RULE_PREFIX = "HoneyBadger Bunker"
FIREWALL_HELPER_NAME = "Add firewall rule.bat"
IDENTITY_SAFE_RE = re.compile(r"^[A-Za-z0-9_\-]{1,40}$")   # same rule as models.IDENTITY_RE (it goes into a .bat)
HOSTNAME_RE = re.compile(r"^(?=.{1,253}$)([A-Za-z0-9]([A-Za-z0-9\-]{0,61}[A-Za-z0-9])?)(\.[A-Za-z0-9]([A-Za-z0-9\-]{0,61}[A-Za-z0-9])?)*$")

# Adapter names that usually mean "VPN" or "virtual switch", not the home network. Matching is a hint only:
# the owner still sees every address and can pick. Names come from what these products call their adapters.
VPN_NAME_RE = re.compile(
    r"vpn|wireguard|\bwg\d|tailscale|zerotier|hamachi|nordlynx|openvpn|proton|mullvad|radmin|forti|anyconnect|"
    r"cisco|globalprotect|pangp|\btap\b|tap-|\btun\b|tun\d|utun|ppp|ipsec|wintun", re.I)
VIRTUAL_NAME_RE = re.compile(r"vethernet|hyper-v|wsl|virtualbox|vmware|vboxnet|docker|\bveth|\bbr-|virbr|loopback", re.I)
CGNAT_NET = ipaddress.ip_network("100.64.0.0/10")   # Tailscale and carrier NAT live here: never a home LAN


def utc_iso(ts: float | None = None) -> str:
    """A wall-clock time as ISO-8601 UTC text like 2026-10-28T14:00:00Z (the API's time format)."""
    t = dt.datetime.fromtimestamp(time.time() if ts is None else ts, dt.timezone.utc)
    return t.isoformat(timespec="seconds").replace("+00:00", "Z")


# =================================================================================================================
# LAN addresses
# =================================================================================================================

@dataclass
class LanAddress:
    ip: str
    interface: str
    kind: Literal["lan", "vpn", "virtual"]     # "lan" = plausible home network; the others need the owner's choice

    def as_dict(self) -> dict[str, Any]:
        return {"ip": self.ip, "interface": self.interface, "kind": self.kind}


def classify_adapter(name: str, ip: str) -> Literal["lan", "vpn", "virtual"]:
    """Guess what kind of adapter this is from its name (and the 100.64/10 range used by Tailscale/carrier NAT)."""
    if VPN_NAME_RE.search(name) or ipaddress.ip_address(ip) in CGNAT_NET:
        return "vpn"
    if VIRTUAL_NAME_RE.search(name):
        return "virtual"
    return "lan"


def lan_addresses(if_addrs: dict[str, list[Any]] | None = None,
                  if_stats: dict[str, Any] | None = None) -> list[LanAddress] | None:
    """Every usable IPv4 address on this PC's network cards, LAN-looking ones first.

    Returns None (unknown) if the interface list cannot be read at all; an empty list means "read fine, none found".
    Tests pass fake if_addrs/if_stats in the same shape psutil returns.
    """
    try:
        if if_addrs is None:
            import psutil
            if_addrs = psutil.net_if_addrs()
            if if_stats is None:
                if_stats = psutil.net_if_stats()
    except Exception:  # noqa: BLE001 - any failure here just means "we do not know"
        return None
    out: list[LanAddress] = []
    for name, addrs in if_addrs.items():
        st = (if_stats or {}).get(name)
        if st is not None and not getattr(st, "isup", True):
            continue                                   # a disconnected adapter is not a way in
        for a in addrs:
            if getattr(a, "family", None) != socket.AF_INET:
                continue                               # IPv4 only for beginners (IPv6 is cut from v1)
            try:
                ip = ipaddress.IPv4Address(str(a.address))
            except ValueError:
                continue
            if ip.is_loopback or ip.is_link_local or ip.is_unspecified or ip.is_multicast:
                continue
            out.append(LanAddress(str(ip), name, classify_adapter(name, str(ip))))
    order = {"lan": 0, "vpn": 1, "virtual": 2}
    out.sort(key=lambda x: (order[x.kind], x.interface, x.ip))
    return out


def os_route_ip() -> str | None:
    """Which local address the OS would use to reach the internet. Sends no packet (UDP connect only)."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("192.0.2.1", 9))                # TEST-NET-1: never routed, nothing is sent
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return None


def pick_lan(addrs: list[LanAddress] | None, chosen: str | None = None, route_ip: str | None = None) -> str | None:
    """The LAN address to show in the LAN connect command, or None when the owner has to choose.

    1. The owner's own choice wins while that address still exists.
    2. Exactly one LAN-looking address: that one.
    3. Several: the one the OS routes through, if it is LAN-looking. Otherwise None (the page asks).
    A VPN or virtual adapter is never picked automatically.
    """
    if not addrs:
        return None
    ips = {a.ip for a in addrs}
    if chosen and chosen in ips:
        return chosen
    lan = [a.ip for a in addrs if a.kind == "lan"]
    if len(lan) == 1:
        return lan[0]
    if len(lan) > 1 and route_ip in lan:
        return route_ip
    return None


# =================================================================================================================
# Public IP (ipify, icanhazip fallback)
# =================================================================================================================

Fetcher = Callable[[str, float], bytes]     # (url, timeout_s) -> body bytes; raises on any failure


def default_fetch(url: str, timeout: float) -> bytes:
    """One HTTPS GET with our User-Agent. Raises OSError/urllib errors on failure (the caller handles them)."""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json, text/plain"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 - fixed https URLs only
        return resp.read(256)                  # an IPv4 answer is tiny; never read an unbounded body


def global_ipv4(text: str) -> str:
    """Return the address if it is a real public IPv4 address, else raise ValueError (private, CGNAT, junk...)."""
    ip = ipaddress.IPv4Address(text.strip())
    if not ip.is_global:
        raise ValueError(f"{ip} is not a public internet address")
    return str(ip)


def _parse_ipify(body: bytes) -> str:
    data = json.loads(body.decode("utf-8"))
    if not isinstance(data, dict) or not isinstance(data.get("ip"), str):
        raise ValueError("ipify answered without an ip field")
    return global_ipv4(data["ip"])


def _parse_plain(body: bytes) -> str:
    return global_ipv4(body.decode("ascii", "strict"))


class PublicIpCache:
    """The engine's one memory of its public address (the same for every server on this PC).

    detected_ip  last good answer (kept when a later lookup fails, then stale=True)
    source       "ipify" or "icanhazip" (who answered), None before the first good answer
    checked_at   when the last good answer arrived (UTC ISO)
    error        why the LAST attempt failed, None if it worked
    """

    def __init__(self, fetch: Fetcher | None = None, ttl_s: float = PUBLIC_IP_TTL_S,
                 clock: Callable[[], float] = time.monotonic, wall: Callable[[], float] = time.time,
                 timeout: float = HTTP_TIMEOUT_S) -> None:
        self.fetch = fetch or default_fetch
        self.ttl_s = ttl_s
        self.clock = clock
        self.wall = wall
        self.timeout = timeout
        self.detected_ip: str | None = None
        self.source: str | None = None
        self.checked_at: str | None = None
        self.error: str | None = None
        self.failed_at: str | None = None
        self._good_mono: float | None = None
        self._try_mono: float | None = None
        self._lock = threading.Lock()

    # ----- persistence (so a restart does not forget the last answer) -------------------------------------
    def dump(self) -> dict[str, Any]:
        return {"detected_ip": self.detected_ip, "source": self.source, "checked_at": self.checked_at}

    def load(self, data: dict[str, Any] | None) -> None:
        if not data or not data.get("detected_ip"):
            return
        try:
            self.detected_ip = global_ipv4(str(data["detected_ip"]))
        except ValueError:
            return
        self.source = data.get("source")
        self.checked_at = data.get("checked_at")
        self._good_mono = None          # loaded from disk: we cannot know how old it is in monotonic time -> stale

    # ----- reading ----------------------------------------------------------------------------------------
    @property
    def fresh(self) -> bool:
        return self._good_mono is not None and (self.clock() - self._good_mono) < self.ttl_s and self.error is None

    def snapshot(self) -> dict[str, Any]:
        """What GET /connect shows. No network traffic."""
        return {"detected_ip": self.detected_ip, "source": self.source, "checked_at": self.checked_at,
                "stale": self.detected_ip is not None and not self.fresh, "error": self.error}

    def get(self, force: bool = False) -> dict[str, Any]:
        """Look the address up if the cached one is older than 15 minutes (or force), then return snapshot()."""
        with self._lock:
            now = self.clock()
            if self.fresh and not force:
                return self.snapshot()
            if force and self._try_mono is not None and now - self._try_mono < PUBLIC_IP_MIN_FORCE_S:
                return self.snapshot()          # pressed twice in a row: answer from memory
            self._try_mono = now
            errors: list[str] = []
            for url, source, parse in ((IPIFY_URL, "ipify", _parse_ipify), (ICANHAZIP_URL, "icanhazip", _parse_plain)):
                try:
                    ip = parse(self.fetch(url, self.timeout))
                except Exception as exc:  # noqa: BLE001 - timeouts, HTTP errors, junk: all "this source failed"
                    errors.append(f"{source}: {_short_error(exc)}")
                    continue
                self.detected_ip, self.source, self.error = ip, source, None
                self.checked_at = utc_iso(self.wall())
                self._good_mono = self.clock()
                self.failed_at = None
                return self.snapshot()
            self.error = "Could not look up the public address (" + "; ".join(errors) + ")"
            self.failed_at = utc_iso(self.wall())
            return self.snapshot()          # previous detected_ip (if any) is kept and shows stale=True


def _short_error(exc: BaseException) -> str:
    if isinstance(exc, (TimeoutError, socket.timeout)):
        return "timed out"
    text = str(exc) or exc.__class__.__name__
    return text[:160]


_DEFAULT_PUBLIC = PublicIpCache()


def public_ip(fetch: Fetcher | None = None, force: bool = False, cache: PublicIpCache | None = None) -> dict[str, Any]:
    """Convenience wrapper: the engine-wide cached lookup (or a given cache / fetcher for tests)."""
    c = cache or (PublicIpCache(fetch=fetch) if fetch is not None else _DEFAULT_PUBLIC)
    return c.get(force=force)


# =================================================================================================================
# Port probe
# =================================================================================================================

PortProbe = Callable[[int, str, str], str]      # (port, proto, bind_ip) -> "free" | "in_use" | "bad_address"


def probe_port(port: int, proto: str, bind_ip: str = "0.0.0.0") -> str:
    """Really try to bind the port (and let go at once). "free", "in_use", or "bad_address".

    No sharing flags: SO_REUSEADDR stays off, and on Windows we ask for EXCLUSIVE use, because without it Windows
    lets a wildcard bind succeed while another program holds the same port on 127.0.0.1 (checked on this PC
    2026-10-28: plain bind said free, exclusive bind said in use). "bad_address" = the bind address is not on this PC.
    A probe cannot reserve the port: another program may still grab it before the server starts.
    """
    kind = socket.SOCK_DGRAM if proto == "udp" else socket.SOCK_STREAM
    family = socket.AF_INET6 if ":" in bind_ip else socket.AF_INET
    s = socket.socket(family, kind)
    try:
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        else:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 0)
        s.bind((bind_ip, port))
        return "free"
    except OSError as exc:
        if exc.errno in (99, 10049) or getattr(exc, "winerror", None) == 10049:   # EADDRNOTAVAIL
            return "bad_address"
        return "in_use"            # in use, or forbidden (Windows reserves some port ranges): either way not usable
    finally:
        s.close()


# =================================================================================================================
# A2S_INFO (Source engine server query)
# =================================================================================================================
# Packet layout from Valve's "Server queries" page, and the same steps as our own working tool
# C:\PythonProjects\honeybadger_github_profile\tools\a2s_info.py, which read "Honey Badger | Custom Map | Rust"
# from the live server (work/evidence/rust_a2s.txt):
#   request   FF FF FF FF 'T' "Source Engine Query\0"  [+ 4-byte challenge when the server asked for one]
#   challenge FF FF FF FF 'A' <4 bytes>                 -> send the request again with those 4 bytes appended
#   info      FF FF FF FF 'I' protocol(byte) name\0 map\0 folder\0 game\0 appid(short) players(byte)
#             max_players(byte) bots(byte) server_type(byte) environment(byte) visibility(byte) vac(byte)
#             version\0 [extra data flag byte + optional fields]

A2S_REQUEST = b"\xFF\xFF\xFF\xFFTSource Engine Query\x00"
A2SState = Literal["answered", "timeout", "malformed", "refused", "error"]


@dataclass
class A2SReply:
    state: A2SState
    name: str | None = None
    map: str | None = None
    folder: str | None = None
    game: str | None = None
    protocol: int | None = None
    app_id: int | None = None
    players: int | None = None
    max_players: int | None = None
    bots: int | None = None
    version: str | None = None
    error: str | None = None
    elapsed_ms: int | None = None

    def as_dict(self) -> dict[str, Any]:
        return dict(self.__dict__)


class A2SMalformed(ValueError):
    """The answer did not follow the A2S_INFO layout."""


def parse_a2s_info(data: bytes) -> A2SReply:
    """Read an 'I' info packet. Raises A2SMalformed on anything that does not fit the layout."""
    if len(data) < 6 or data[:4] != b"\xFF\xFF\xFF\xFF" or data[4] != 0x49:
        raise A2SMalformed("not an A2S_INFO answer")
    pos = 6

    def cstr() -> str:
        nonlocal pos
        end = data.find(b"\x00", pos)
        if end < 0:
            raise A2SMalformed("text field is not terminated")
        value = data[pos:end].decode("utf-8", "replace")
        pos = end + 1
        return value

    name, mapname, folder, game = cstr(), cstr(), cstr(), cstr()
    if len(data) < pos + 9:
        raise A2SMalformed("answer ends early")
    app_id = struct.unpack_from("<h", data, pos)[0]
    players, max_players, bots = data[pos + 2], data[pos + 3], data[pos + 4]
    pos += 9                                   # appid(2) players max bots type env visibility vac
    version = cstr() if pos < len(data) else None
    return A2SReply("answered", name=name, map=mapname, folder=folder, game=game, protocol=data[5], app_id=app_id,
                    players=players, max_players=max_players, bots=bots, version=version)


def a2s_info(host: str, port: int, timeout: float = 2.0, max_challenges: int = 2) -> A2SReply:
    """Send A2S_INFO to host:port and wait (bounded) for the answer. Never raises: failures come back typed.

    "timeout"   nothing answered in time (closed port, firewall, router that does not loop back...)
    "refused"   the PC answered "nothing is listening on that port" (Windows reports this as a reset)
    "malformed" something answered, but not with an A2S_INFO packet
    "error"     we could not even send (bad address, no network)
    """
    started = time.monotonic()
    deadline = started + timeout
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def done(reply: A2SReply) -> A2SReply:
        reply.elapsed_ms = int((time.monotonic() - started) * 1000)
        return reply

    try:
        s.connect((host, port))                # a connected UDP socket only accepts replies from that host:port
        request = A2S_REQUEST
        challenges = 0
        s.send(request)
        while True:
            left = deadline - time.monotonic()
            if left <= 0:
                return done(A2SReply("timeout", error=f"no answer within {timeout:g} s"))
            s.settimeout(left)
            try:
                data = s.recv(1400)
            except (TimeoutError, socket.timeout):
                return done(A2SReply("timeout", error=f"no answer within {timeout:g} s"))
            except ConnectionResetError:
                return done(A2SReply("refused", error="nothing is listening on that port"))
            if len(data) >= 9 and data[:4] == b"\xFF\xFF\xFF\xFF" and data[4] == 0x41:   # 'A' = challenge
                challenges += 1
                if challenges > max_challenges:
                    return done(A2SReply("malformed", error="the server kept asking for a new challenge"))
                s.send(A2S_REQUEST + data[5:9])
                continue
            if data[:4] == b"\xFF\xFF\xFF\xFE":
                return done(A2SReply("malformed", error="split answer (not used by Rust info replies)"))
            try:
                return done(parse_a2s_info(data))
            except A2SMalformed as exc:
                return done(A2SReply("malformed", error=str(exc)))
    except OSError as exc:
        return done(A2SReply("error", error=_short_error(exc)))
    finally:
        s.close()


def names_match(expected: str, answered: str | None) -> bool:
    """Does the answered server name belong to this profile? Exact after trimming; a long name may come back cut."""
    if answered is None:
        return False
    a, e = answered.strip(), expected.strip()
    return a == e or (len(a) >= 60 and e.startswith(a))


# =================================================================================================================
# Windows Firewall helper (.bat) and rule check
# =================================================================================================================

def firewall_rule_name(identity: str) -> str:
    if not IDENTITY_SAFE_RE.match(identity or ""):
        raise ValueError("server identity may only use letters, digits, - and _")
    return f"{FIREWALL_RULE_PREFIX} {identity}"


def _bat_ps_literal(path: str) -> str:
    """A path written inside a PowerShell '...' string inside a .bat: double ' for PowerShell and % for cmd."""
    return path.replace("'", "''").replace("%", "%%")


def firewall_helper_text(identity: str, game_port: int, query_port: int, bat_path: str | None = None) -> str:
    """The self-elevating .bat that adds the inbound UDP rule for the game and query ports.

    The RCON port is never named: RCON is a remote admin console and must not be opened to the internet.
    The rule is deleted first (only our own exactly-named rule) so running the helper again after a port change
    replaces the old ports instead of leaving them open.
    """
    rule = firewall_rule_name(identity)
    for p in (game_port, query_port):
        if not isinstance(p, int) or not 1 <= p <= 65535:
            raise ValueError("ports must be whole numbers between 1 and 65535")
    self_path = f"'{_bat_ps_literal(bat_path)}'" if bat_path else "'%~f0'"
    lines = [
        "@echo off",
        f"title {rule} - Windows Firewall rule",
        "rem Written by HoneyBadger Bunker. It lets friends reach this Rust server through Windows Firewall.",
        f"rem It opens UDP {game_port} (game) and UDP {query_port} (server query) for incoming traffic. Nothing else.",
        "rem It never opens the RCON port: RCON is the remote admin console and must stay closed to the internet.",
        "",
        "rem Adding a firewall rule needs administrator rights. 'net session' only works as administrator,",
        "rem so it tells us whether we already are.",
        "net session >nul 2>&1",
        "if %errorlevel% neq 0 (",
        "    echo Windows will now ask for administrator permission to add a firewall rule.",
        f"    powershell -NoProfile -ExecutionPolicy Bypass -Command \"Start-Process -FilePath {self_path} -Verb RunAs\"",
        "    if errorlevel 1 (",
        "        echo.",
        "        echo The permission request was cancelled or failed. No rule was added.",
        "        pause",
        "    )",
        "    exit /b",
        ")",
        "",
        "rem An elevated window starts in C:\\Windows\\System32, so go back to the folder this file is in.",
        "cd /d %~dp0",
        "",
        "echo Removing an older copy of this rule (if there is one)...",
        f"netsh advfirewall firewall delete rule name=\"{rule}\" >nul 2>&1",
        "echo Adding the rule...",
        f"netsh advfirewall firewall add rule name=\"{rule}\" dir=in action=allow protocol=UDP "
        f"localport={game_port},{query_port}",
        "echo.",
        "echo This is the rule Windows now has:",
        f"netsh advfirewall firewall show rule name=\"{rule}\"",
        "echo.",
        "echo A firewall rule alone does not prove friends can connect: your router must forward the same ports.",
        "pause",
        "",
    ]
    return "\r\n".join(lines)


def write_firewall_helper(install_root: str | Path, identity: str, game_port: int, query_port: int) -> Path:
    """Save the helper as '<install_root>/Add firewall rule.bat' (atomically) and return its path."""
    root = Path(install_root)
    root.mkdir(parents=True, exist_ok=True)
    path = root / FIREWALL_HELPER_NAME
    text = firewall_helper_text(identity, game_port, query_port, bat_path=str(path))
    tmp = path.with_suffix(".bat.tmp")
    tmp.write_bytes(text.encode("ascii"))       # cmd.exe reads .bat files in the console code page: keep it ASCII
    os.replace(tmp, path)
    return path


Runner = Callable[[list[str]], tuple[int, str]]     # argv -> (exit code, combined text output)


def default_runner(argv: list[str]) -> tuple[int, str]:
    """Run a short command with no console window, bounded to 10 s."""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    r = subprocess.run(argv, capture_output=True, text=True, timeout=10, creationflags=flags)  # noqa: S603
    return r.returncode, (r.stdout or "") + (r.stderr or "")


def parse_netsh_rules(text: str) -> list[dict[str, str]]:
    """Turn `netsh advfirewall firewall show rule` text into one {label: value} dict per rule (English labels)."""
    rules: list[dict[str, str]] = []
    cur: dict[str, str] | None = None
    for raw in text.splitlines():
        line = raw.strip()
        if not line or set(line) == {"-"}:
            continue
        if ":" not in line:
            continue
        label, _, value = line.partition(":")
        label, value = label.strip().lower(), value.strip()
        if label == "rule name":
            cur = {"rule name": value}
            rules.append(cur)
        elif cur is not None:
            cur[label] = value
    return rules


def firewall_rule_state(identity: str, expected_ports: Iterable[int] | None = None, run: Runner | None = None,
                        os_name: str | None = None) -> dict[str, Any]:
    """Does our firewall rule exist? {state, checked_at, error, ports}. Runs netsh WITHOUT admin rights.

    configured  the rule exists, is on, allows inbound UDP, and covers exactly the expected ports
    stale       our rule exists but is off, or lists different ports (re-run the helper)
    missing     netsh says no rule has that name
    unknown     netsh could not be run or its text was not understood (for example a non-English Windows)
    unsupported this is not Windows
    A rule is a setting, not proof: it says nothing about the router or whether friends can connect.
    """
    checked_at = utc_iso()
    os_name = os_name or ("windows" if sys.platform == "win32" else sys.platform)
    if os_name != "windows":
        return {"state": "unsupported", "checked_at": checked_at, "error": None, "ports": None}
    rule = firewall_rule_name(identity)
    runner = run or default_runner
    try:
        code, out = runner(["netsh", "advfirewall", "firewall", "show", "rule", f"name={rule}"])
    except Exception as exc:  # noqa: BLE001 - netsh missing, timeout...: we simply do not know
        return {"state": "unknown", "checked_at": checked_at, "error": f"netsh could not run: {_short_error(exc)}",
                "ports": None}
    if "no rules match" in out.lower():
        return {"state": "missing", "checked_at": checked_at, "error": None, "ports": None}
    rules = [r for r in parse_netsh_rules(out) if r.get("rule name") == rule]
    if code != 0 or not rules:
        return {"state": "unknown", "checked_at": checked_at,
                "error": "netsh answered in a way the Bunker does not understand", "ports": None}
    want = sorted(set(int(p) for p in expected_ports)) if expected_ports is not None else None
    found_ports: list[int] = []
    good = False
    problems: list[str] = []
    for r in rules:
        ports = sorted({int(x) for x in re.findall(r"\d+", r.get("localport", ""))})
        found_ports = sorted(set(found_ports) | set(ports))
        ok_on = r.get("enabled", "").lower() == "yes"
        ok_dir = r.get("direction", "").lower() == "in"
        ok_act = r.get("action", "").lower() == "allow"
        ok_proto = r.get("protocol", "").upper() == "UDP"
        ok_ports = want is None or ports == want
        if ok_on and ok_dir and ok_act and ok_proto and ok_ports:
            good = True
        else:
            if not ok_on:
                problems.append("the rule is turned off")
            if not ok_ports:
                problems.append(f"the rule opens {', '.join(map(str, ports)) or 'no ports'}, "
                                f"this server uses {', '.join(map(str, want or []))}")
            if not (ok_dir and ok_act and ok_proto):
                problems.append("the rule is not an inbound UDP allow rule")
    if good:
        return {"state": "configured", "checked_at": checked_at, "error": None, "ports": found_ports}
    return {"state": "stale", "checked_at": checked_at, "error": "; ".join(dict.fromkeys(problems)) or None,
            "ports": found_ports}


# =================================================================================================================
# The GET /connect answer
# =================================================================================================================

QUERY_SCOPES = ("local", "hairpin")


def blank_query(scope: str) -> dict[str, Any]:
    return {"scope": scope, "state": "not_checked", "hostname": None, "checked_at": None, "error": None,
            "target": None}


@dataclass
class NetCache:
    """Per-profile network memory the engine keeps between requests (persisted as JSON by the router).

    public_address_override  owner-typed address or DNS name for the public command (VPN/odd routing), or None
    selected_lan_ip          owner's choice when the PC has several LAN addresses, or None
    query                    last local / hairpin query result
    firewall                 last firewall rule check (+ the helper path once written)
    public                   snapshot of the engine-wide public IP cache (filled in by the caller)
    """
    public_address_override: str | None = None
    selected_lan_ip: str | None = None
    query: dict[str, dict[str, Any]] = field(default_factory=lambda: {s: blank_query(s) for s in QUERY_SCOPES})
    firewall: dict[str, Any] = field(default_factory=lambda: {"state": "unknown", "helper_path": None,
                                                              "checked_at": None, "error": None})
    public: dict[str, Any] = field(default_factory=lambda: {"detected_ip": None, "source": None, "checked_at": None,
                                                            "stale": False, "error": None})

    def dump(self) -> dict[str, Any]:
        return {"public_address_override": self.public_address_override, "selected_lan_ip": self.selected_lan_ip,
                "query": self.query, "firewall": self.firewall}

    @classmethod
    def load(cls, data: dict[str, Any] | None) -> "NetCache":
        c = cls()
        if not isinstance(data, dict):
            return c
        c.public_address_override = data.get("public_address_override") or None
        c.selected_lan_ip = data.get("selected_lan_ip") or None
        q = data.get("query")
        if isinstance(q, dict):
            for s in QUERY_SCOPES:
                if isinstance(q.get(s), dict):
                    c.query[s] = {**blank_query(s), **q[s], "scope": s}
        fw = data.get("firewall")
        if isinstance(fw, dict):
            c.firewall.update({k: fw.get(k) for k in ("state", "helper_path", "checked_at", "error") if k in fw})
        return c

    def invalidate_queries(self) -> None:
        self.query = {s: blank_query(s) for s in QUERY_SCOPES}

    def mark_firewall_stale(self, reason: str) -> None:
        if self.firewall.get("state") in ("configured", "missing", "unknown", "stale"):
            self.firewall.update({"state": "stale", "error": reason})


def validate_public_override(value: str | None) -> str | None:
    """An address friends type: a public IPv4 address or a DNS name (e.g. a dynamic-DNS name). No port, no URL."""
    if value is None:
        return None
    v = value.strip()
    if not v:
        return None
    try:
        ip = ipaddress.ip_address(v)
    except ValueError:
        if HOSTNAME_RE.match(v) and "." in v:
            return v.lower()
        raise ValueError("type a public IPv4 address (like 203.0.113.7) or a DNS name (like myserver.example.net), "
                         "without a port") from None
    if ip.version != 4:
        raise ValueError("only IPv4 addresses are supported for now")
    return str(ip)


def connect_info(profile: Any, status: dict[str, Any], cache: NetCache, *,
                 lan: list[LanAddress] | None = None, route_ip: str | None = None,
                 rcon_password_set: bool = False, os_name: str = "windows") -> dict[str, Any]:
    """Build the GET /profiles/{pid}/connect answer (field names: BASICS_PLAN 'Shared seams').

    status: {"running": bool, "busy": bool, "reason": str | None} from the engine (running = process alive).
    The RCON password is deliberately NOT a parameter: this answer can never contain it.
    """
    ports = profile.ports
    game, query = ports.game_udp, ports.query_udp
    selected = pick_lan(lan, cache.selected_lan_ip, route_ip)
    override = getattr(profile, "public_address_override", None) or cache.public_address_override
    pub = dict(cache.public)
    pub["configured_address"] = override
    public_addr = override or pub.get("detected_ip")
    hairpin = cache.query.get("hairpin", blank_query("hairpin"))
    running = bool(status.get("running"))
    busy = bool(status.get("busy"))
    firewall = dict(cache.firewall)
    if os_name != "windows":
        firewall.update({"state": "unsupported", "helper_path": None})
    return {
        # --- settings (what the owner chose) ---
        "hostname": profile.hostname,
        "name": profile.name,
        "bind_ip": profile.bind_ip,
        "game_port": game,
        "query_port": query,
        "rcon_port": ports.rcon_tcp,
        "app_port": ports.app_tcp,
        # --- detected (what this PC reports) ---
        "lan_addresses": [a.ip for a in lan] if lan is not None else None,
        "lan_interfaces": [a.as_dict() for a in lan] if lan is not None else None,
        "selected_lan_ip": selected,
        "public_address": {k: pub.get(k) for k in ("detected_ip", "configured_address", "source", "checked_at",
                                                   "stale", "error")},
        "local_connect_command": f"client.connect 127.0.0.1:{game}",
        "lan_connect_command": f"client.connect {selected}:{game}" if selected else None,
        "public_connect_command": f"client.connect {public_addr}:{game}" if public_addr else None,
        "forwarding": [{"role": "game", "protocol": "udp", "port": game},
                       {"role": "query", "protocol": "udp", "port": query}],
        # --- checked (what we actually tested, and what we never test) ---
        "query_check": [dict(cache.query.get(s, blank_query(s))) for s in QUERY_SCOPES],
        "external_reachability": "hairpin_answered" if hairpin.get("state") == "answered" else "not_tested",
        "browser_listing": "not_tested",
        "firewall": {k: firewall.get(k) for k in ("state", "helper_path", "checked_at", "error")},
        "rcon_password_set": bool(rcon_password_set),
        # --- what the page may offer right now ---
        "server_running": running,
        "can_change_ports": not running and not busy,
        "blocked_reason": status.get("reason") if (running or busy) else None,
        # --- kept for older screens (same meaning as before, minus the password) ---
        "lan_ip": selected,
        "wan_ip": public_addr,
        "connect_command": f"client.connect {selected or '127.0.0.1'}:{game}",
    }
