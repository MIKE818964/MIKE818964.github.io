"""HoneyBadger Bunker engine.

The engine is a long-running background program. It installs game servers with SteamCMD, starts and stops them
without ever showing a console window, watches their logs, talks to them over WebRCON, runs schedules and backups,
and offers all of that to the desktop window / web UI through a small local web API (see docs/API_CONTRACT.md).
"""

__version__ = "0.1.0"
APP_NAME = "HoneyBadger Bunker"
