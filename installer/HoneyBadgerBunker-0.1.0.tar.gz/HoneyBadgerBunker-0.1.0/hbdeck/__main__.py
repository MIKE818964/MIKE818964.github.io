"""Command line for the engine (what the desktop launcher, the .bat file and systemd call).

    python -m hbdeck serve     --data <dir> [--port N] [--bind 127.0.0.1]  run the engine in the foreground
    python -m hbdeck shell     --data <dir>                                start/attach the engine + open the window
    python -m hbdeck status    --data <dir>          engine + profiles; with no engine: what is still running (orphans)
    python -m hbdeck stop      --data <dir>          save+stop every server, then exit the engine (systemd ExecStop)
    python -m hbdeck kill-all  --data <dir> [--list] Stop everything this folder started (--list: only show it)
    python -m hbdeck preflight --data <dir>          exit 3 if this folder's engine holds its lock but does not answer
    python -m hbdeck selftest                        offline checks for support tickets

Exit codes: 0 ok, 1 failed / something still running, 3 = HoneyBadger Bunker is already running from this folder.

Defaults also come from environment variables (used by the Linux service file /etc/honeybadger/engine.env):
HB_DATA (data folder), HB_PORT, HB_BIND, HB_SERVERS_DIR (parent folder for new servers).
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path


def _out(text: str) -> None:
    if sys.stdout is not None:     # pythonw.exe has no stdout
        print(text, flush=True)


def default_data_dir() -> Path:
    env = os.environ.get("HB_DATA")
    if env:
        return Path(env)
    from .platform import current_platform
    return current_platform().default_data_dir()


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="hbdeck", description="HoneyBadger Bunker engine")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("serve", "shell", "status", "stop", "kill-all", "preflight"):
        p = sub.add_parser(name)
        p.add_argument("--data", type=Path, default=None, help="data folder (default: HB_DATA or the OS default)")
        if name == "serve":
            p.add_argument("--port", type=int, default=int(os.environ.get("HB_PORT", "27800")))
            p.add_argument("--bind", default=os.environ.get("HB_BIND", "127.0.0.1"))
        if name == "kill-all":
            p.add_argument("--list", action="store_true", help="only show what would be stopped; change nothing")
            p.add_argument("--deadline", type=float, default=None, help="seconds for the whole stop (default 360)")
    sub.add_parser("selftest")
    return ap


def already_running_text(data: Path) -> str:
    """The exact sentence the CLI, the launcher and the .bat show (pid and port from the lock owner record)."""
    from . import guards
    from .server import read_engine_json
    info = guards.read_owner(data) or {}
    port = info.get("port") or (read_engine_json(data) or {}).get("port")
    return guards.already_running_message(info.get("pid"), port)


def cmd_status(data: Path) -> int:
    from .server import engine_request, read_engine_json
    info = read_engine_json(data)
    if info:
        try:
            eng = engine_request(info, "GET", "/engine")
            profiles = engine_request(info, "GET", "/profiles")
        except Exception as exc:  # noqa: BLE001
            _out(f"engine.json found (port {info.get('port')}, pid {info.get('pid')}) but the engine does not answer: "
                 f"{exc}")
        else:
            _out(json.dumps({k: v for k, v in info.items() if k != "token"}, indent=1))
            _out(f"engine {eng.get('version')} on {eng.get('os')}, up {eng.get('uptime_s')} s")
            for p in profiles:
                st = engine_request(info, "GET", f"/profiles/{p['id']}/status")
                _out(f"  {p['name']} [{p['identity']}] {st['state']} rcon={st['rcon']} ports "
                     f"{p['ports']['game_udp']}/{p['ports']['rcon_tcp']}/{p['ports']['query_udp']}")
            return 0
    else:
        _out(f"no engine.json in {data}: the engine is not running")
    # No answering engine: look at what is still running anyway (works offline, from the registry + processes).
    from . import guards
    from .killall import offline_status
    from .platform import current_platform
    if guards.engine_lock_held(current_platform(), data):
        _out(already_running_text(data))
    rep = offline_status(data)
    if rep.targets or rep.conflicting or rep.unverifiable:
        _out("Still running from this folder (ORPHANS - nothing is managing them):")
        for t in rep.targets:
            _out(f"  [{t.kind}] pid {t.pid} {t.label}")
        for c in rep.conflicting:
            _out(f"  [not ours] pid {c.get('pid')} {c.get('why')}")
        for u in rep.unverifiable:
            _out(f"  [cannot check] pid {u.get('pid')} {u.get('why')}")
        _out("Run `hbdeck kill-all --data <folder>` (or the launcher's 'Stop everything') to end them.")
    else:
        _out("Nothing from this folder is running.")
    return 1


def cmd_stop(data: Path) -> int:
    """Ask the engine to save + stop every server and exit; wait (bounded) until its process is really gone."""
    from . import guards
    from .platform import current_platform
    from .server import engine_request, read_engine_json
    plat = current_platform()
    info = read_engine_json(data)
    if not info:
        if guards.engine_lock_held(plat, data):
            _out(already_running_text(data) + " It does not answer; use `hbdeck kill-all` to end it.")
            return 1
        _out("the engine is not running")
        return 0
    try:
        engine_request(info, "POST", "/engine/shutdown")
    except Exception as exc:  # noqa: BLE001
        if not guards.engine_lock_held(plat, data):
            _out("the engine is not running")
            return 0
        _out(f"could not reach the engine: {exc}")
        return 1
    _out("Asked the engine to save and stop every server, then exit...")
    pid, ct = int(info["pid"]), info.get("create_time")
    if plat.wait_dead(pid, ct, guards.ENGINE_SHUTDOWN_BUDGET_S + 30):
        _out("engine stopped")
        return 0
    _out("the engine is still running after its whole shutdown budget; use `hbdeck kill-all`")
    return 1


def cmd_preflight(data: Path) -> int:
    """For the launcher: 0 = go ahead (nothing running, or a healthy engine to attach to); 3 = held but silent."""
    from . import guards
    from .platform import current_platform
    from .server import engine_alive
    if engine_alive(data):
        return 0
    if guards.engine_lock_held(current_platform(), data):
        _out(already_running_text(data))
        return guards.EXIT_ALREADY_RUNNING
    return 0


def cmd_shell(data: Path) -> int:
    from . import guards
    from .platform import current_platform
    from .server import engine_alive, spawn_engine_detached
    info = engine_alive(data)
    if not info:
        if guards.engine_lock_held(current_platform(), data):
            # An engine owns this folder but its window cannot reach it. Never start a second one.
            _out(already_running_text(data))
            _message_box(already_running_text(data))
            return guards.EXIT_ALREADY_RUNNING
        spawn_engine_detached(data)
        for _ in range(120):
            time.sleep(0.5)
            info = engine_alive(data)
            if info:
                break
    if not info:
        _out(f"the engine did not start; see {data / 'logs' / 'engine.log'}")
        return 1
    from .shell_win import open_window
    row = register_shell(data)
    try:
        open_window(f"http://127.0.0.1:{info['port']}/")
    finally:
        unregister_shell(data, row)
    return 0


def register_shell(data: Path, pid: int | None = None) -> tuple[int, float | None] | None:
    """Write this window process into the ownership registry (kind "shell") so Stop everything can close it.

    Under the launcher this process IS hb_launch.pyw (it runs hbdeck in-process), so the pid is the window's.
    Never fatal: a window that cannot register still opens; Stop everything then just leaves it open."""
    import psutil

    from .registry import open_registry
    pid = pid or os.getpid()
    try:
        ct = psutil.Process(pid).create_time()
        reg = open_registry(data)
        try:
            reg.add("shell", pid, ct, [sys.executable, *sys.argv], data_dir=data)
        finally:
            reg.close()
        return pid, ct
    except Exception:  # noqa: BLE001
        return None


def unregister_shell(data: Path, row: tuple[int, float | None] | None) -> None:
    """The window closed normally: forget its registry row (this process is about to exit)."""
    if row is None:
        return
    from .registry import open_registry
    try:
        reg = open_registry(data)
        try:
            reg.remove(row[0], row[1])
        finally:
            reg.close()
    except Exception:  # noqa: BLE001
        pass


def cmd_kill_all(data: Path, list_only: bool, deadline: float | None) -> int:
    from .killall import DEFAULT_DEADLINE_S, kill_all
    rep = kill_all(data, list_only=list_only, deadline_s=deadline or DEFAULT_DEADLINE_S)
    _out(rep.text())
    return rep.exit_code


def _message_box(text: str) -> None:
    """Windows: show the sentence in a box too, but ONLY when we run windowless (pythonw: nobody sees stdout)."""
    if os.name != "nt" or not Path(sys.executable).name.lower().startswith("pythonw"):
        return
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, "HoneyBadger Bunker", 0x40)
    except Exception:  # noqa: BLE001
        pass


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.cmd == "selftest":
        from .selftest import run
        return run()
    data = (args.data or default_data_dir()).resolve()
    if args.cmd == "serve":
        from .server import run_server
        return run_server(data, args.port, args.bind)
    if args.cmd == "status":
        return cmd_status(data)
    if args.cmd == "stop":
        return cmd_stop(data)
    if args.cmd == "shell":
        return cmd_shell(data)
    if args.cmd == "kill-all":
        return cmd_kill_all(data, args.list, args.deadline)
    if args.cmd == "preflight":
        return cmd_preflight(data)
    return 2


if __name__ == "__main__":
    sys.exit(main())
