"""Safe archive extraction (zip and tar.gz) and safe downloads.

Archives from the internet can be hostile: an entry named "../../Windows/evil.dll" or "/etc/passwd" would write
outside the folder we meant; a symlink entry can point anywhere; a tiny file can "unzip" to 100 GB (a zip bomb).
Every extraction here refuses all of those BEFORE writing anything.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import tarfile
import tempfile
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath
from typing import Callable

USER_AGENT = "HoneyBadgerBunker/0.1"


class UnsafeArchive(ValueError):
    pass


def _safe_relpath(name: str) -> PurePosixPath:
    """Validate one archive entry name and return it as a clean relative path."""
    norm = name.replace("\\", "/")
    p = PurePosixPath(norm)
    if not norm or norm.startswith("/") or p.is_absolute():
        raise UnsafeArchive(f"absolute path in archive: {name!r}")
    if ":" in p.parts[0]:
        raise UnsafeArchive(f"drive letter in archive: {name!r}")
    if any(part == ".." for part in p.parts):
        raise UnsafeArchive(f"path escapes the target folder: {name!r}")
    return PurePosixPath(*[x for x in p.parts if x not in ("", ".")])


def _inside(dest: Path, rel: PurePosixPath) -> Path:
    target = (dest / Path(*rel.parts)).resolve()
    root = dest.resolve()
    if target != root and root not in target.parents:
        raise UnsafeArchive(f"path escapes the target folder: {rel}")
    return target


def plan_zip(zip_path: Path, max_bytes: int = 2 << 30, max_files: int = 20000) -> list[tuple[str, PurePosixPath]]:
    """Inspect a zip without extracting. Returns [(original name, safe relative path)] for files only."""
    out: list[tuple[str, PurePosixPath]] = []
    total = 0
    with zipfile.ZipFile(zip_path) as zf:
        infos = zf.infolist()
        if len(infos) > max_files:
            raise UnsafeArchive(f"archive has too many entries ({len(infos)})")
        for info in infos:
            rel = _safe_relpath(info.filename)
            mode = (info.external_attr >> 16) & 0o170000
            if mode == 0o120000:
                raise UnsafeArchive(f"symlink in archive: {info.filename!r}")
            if info.is_dir():
                continue
            total += info.file_size
            if total > max_bytes:
                raise UnsafeArchive("archive expands to more than the allowed size")
            out.append((info.filename, rel))
    return out


def extract_zip(zip_path: Path, dest: Path, max_bytes: int = 2 << 30, max_files: int = 20000) -> list[str]:
    """Extract a zip into dest after validating every entry. Returns the relative file paths written."""
    plan = plan_zip(zip_path, max_bytes, max_files)
    dest.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    with zipfile.ZipFile(zip_path) as zf:
        for name, rel in plan:
            target = _inside(dest, rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(name) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, 1 << 20)
            written.append(rel.as_posix())
    return written


def plan_tar(tar_path: Path, max_bytes: int = 2 << 30, max_files: int = 20000) -> list[tuple[tarfile.TarInfo, PurePosixPath]]:
    out: list[tuple[tarfile.TarInfo, PurePosixPath]] = []
    total = 0
    with tarfile.open(tar_path, "r:*") as tf:
        members = tf.getmembers()
        if len(members) > max_files:
            raise UnsafeArchive(f"archive has too many entries ({len(members)})")
        for m in members:
            rel = _safe_relpath(m.name)
            if m.issym() or m.islnk():
                raise UnsafeArchive(f"link in archive: {m.name!r}")
            if m.isdir():
                continue
            if not m.isfile():
                raise UnsafeArchive(f"special file in archive: {m.name!r}")
            total += m.size
            if total > max_bytes:
                raise UnsafeArchive("archive expands to more than the allowed size")
            out.append((m, rel))
    return out


def extract_tar(tar_path: Path, dest: Path, max_bytes: int = 2 << 30, max_files: int = 20000) -> list[str]:
    plan = plan_tar(tar_path, max_bytes, max_files)
    dest.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    with tarfile.open(tar_path, "r:*") as tf:
        for member, rel in plan:
            target = _inside(dest, rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            src = tf.extractfile(member)
            if src is None:
                continue
            with src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst, 1 << 20)
            if member.mode & 0o111:                 # keep the "executable" bit (RustDedicated, steamcmd.sh)
                try:
                    os.chmod(target, 0o755)
                except OSError:
                    pass
            written.append(rel.as_posix())
    return written


def extract_any(path: Path, dest: Path, **kw: int) -> list[str]:
    name = path.name.lower()
    if name.endswith(".zip"):
        return extract_zip(path, dest, **kw)
    if name.endswith((".tar.gz", ".tgz", ".tar")):
        return extract_tar(path, dest, **kw)
    raise UnsafeArchive(f"unknown archive type: {path.name}")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class DownloadError(RuntimeError):
    pass


def download(url: str, dest: Path, *, max_bytes: int = 1 << 30, expected_size: int | None = None,
             expected_sha256: str | None = None, timeout: float = 60.0,
             progress: Callable[[int, int | None], None] | None = None) -> Path:
    """Download url to dest through a temporary file; verify size/sha256 before the file appears at dest.

    Runs synchronously (call it from a worker thread). A partial or wrong download never lands at dest.
    """
    if not url.startswith(("https://", "http://", "file:")):
        raise DownloadError(f"refusing to download from {url!r}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    fd, tmp_name = tempfile.mkstemp(prefix=".dl-", dir=str(dest.parent))
    tmp = Path(tmp_name)
    h = hashlib.sha256()
    got = 0
    try:
        with os.fdopen(fd, "wb") as out, urllib.request.urlopen(req, timeout=timeout) as resp:
            total_hdr = resp.headers.get("Content-Length")
            total = int(total_hdr) if total_hdr and total_hdr.isdigit() else None
            first = True
            while True:
                chunk = resp.read(1 << 16)
                if not chunk:
                    break
                if first:
                    head = chunk[:64].lstrip().lower()
                    if head.startswith((b"<!doctype html", b"<html")) and not url.lower().endswith((".html", ".htm")):
                        raise DownloadError("the server sent a web page instead of the file")
                    first = False
                got += len(chunk)
                if got > max_bytes:
                    raise DownloadError("download is larger than allowed")
                h.update(chunk)
                out.write(chunk)
                if progress:
                    progress(got, total)
        if expected_size is not None and got != expected_size:
            raise DownloadError(f"size mismatch: expected {expected_size} bytes, got {got}")
        if expected_sha256 and h.hexdigest() != expected_sha256.lower():
            raise DownloadError("sha256 mismatch: the file is not the one the manifest describes")
        os.replace(tmp, dest)
        return dest
    except Exception:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
