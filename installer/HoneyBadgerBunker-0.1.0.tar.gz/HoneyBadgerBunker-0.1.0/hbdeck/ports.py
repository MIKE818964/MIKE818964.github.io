"""Port picking and collision checks.

Every server needs: game (UDP), query (UDP, must differ from game), RCON (TCP), and optionally Rust+ (TCP).
The Deck's pattern (same as the recipe): game = 28015, rcon = game + 1, query = game + 2; the next server gets the
next block of ten (28025, 28026, 28027...).

A port is only offered if (1) no other profile uses it with the same protocol, and (2) nothing on this machine is
bound to it right now (we briefly try to bind it ourselves). The bind test can race with another program, so the
supervisor still watches the server log for bind errors after launch.
"""
from __future__ import annotations

import socket
from dataclasses import dataclass
from typing import Callable, Iterable

import psutil

from .models import Ports, Profile

BLOCK_START = 28015
BLOCK_STEP = 10
BLOCK_END = 29000


@dataclass
class Collision:
    port: int
    protocol: str
    owner: str          # profile name, "process <name> (pid N)", or "another program"


def probe_free(protocol: str, port: int, bind_ip: str = "0.0.0.0") -> bool:
    """True if we can bind this port right now (so nobody else holds it)."""
    kind = socket.SOCK_DGRAM if protocol == "udp" else socket.SOCK_STREAM
    family = socket.AF_INET6 if ":" in bind_ip else socket.AF_INET
    s = socket.socket(family, kind)
    try:
        if protocol == "tcp" and hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            s.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)   # Windows: no sharing tricks
        s.bind((bind_ip, port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def port_owner(protocol: str, port: int) -> str:
    """Best effort: which local process holds a port (may need admin rights to see other users' processes)."""
    kind = "udp" if protocol == "udp" else "tcp"
    try:
        for c in psutil.net_connections(kind=kind):
            if c.laddr and c.laddr.port == port and c.pid:
                try:
                    return f"process {psutil.Process(c.pid).name()} (pid {c.pid})"
                except psutil.Error:
                    return f"process pid {c.pid}"
    except (psutil.AccessDenied, OSError):
        pass
    return "another program"


def profile_binds(profiles: Iterable[Profile], exclude_id: str | None = None) -> dict[tuple[str, int], str]:
    used: dict[tuple[str, int], str] = {}
    for p in profiles:
        if p.id == exclude_id:
            continue
        for proto, port, _role in p.ports.binds():
            used[(proto, port)] = p.name
    return used


def find_collisions(ports: Ports, profiles: Iterable[Profile], exclude_id: str | None = None,
                    probe: Callable[[str, int], bool] | None = None) -> list[Collision]:
    """All conflicts for a proposed port set: with other profiles, and (if probe given) with live sockets."""
    used = profile_binds(profiles, exclude_id)
    out: list[Collision] = []
    for proto, port, _role in ports.binds():
        if (proto, port) in used:
            out.append(Collision(port, proto, f"profile '{used[(proto, port)]}'"))
        elif probe is not None and not probe(proto, port):
            out.append(Collision(port, proto, port_owner(proto, port)))
    return out


def pick_ports(profiles: Iterable[Profile], probe: Callable[[str, int], bool] = probe_free,
               start: int = BLOCK_START) -> Ports:
    """First block of free ports: game, rcon = game+1, query = game+2. Rust+ off (None) by default."""
    plist = list(profiles)
    for game in range(start, BLOCK_END, BLOCK_STEP):
        cand = Ports(game_udp=game, query_udp=game + 2, rcon_tcp=game + 1, app_tcp=None)
        if not find_collisions(cand, plist, probe=probe):
            return cand
    raise RuntimeError("no free port block between 28015 and 29000")
